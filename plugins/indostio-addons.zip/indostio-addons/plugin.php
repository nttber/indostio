<?php
/**
 * Indostio Addons init
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Indostio
 */

namespace Indostio;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Indostio Addons init
 *
 * @since 1.0.0
 */
class Addons {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'load_templates' ) );
	}

	/**
	 * Load Templates
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function load_templates() {
		$this->includes();
		spl_autoload_register( '\Indostio\Addons\Auto_Loader::load' );

		$this->add_actions();
	}

	/**
	 * Includes files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function includes() {
		// Auto Loader
		require_once INDOSTIO_ADDONS_DIR . 'autoloader.php';
		\Indostio\Addons\Auto_Loader::register( [
			'Indostio\Addons\Helper'         => INDOSTIO_ADDONS_DIR . 'inc/helper.php',
			'Indostio\Addons\User'       	=> INDOSTIO_ADDONS_DIR . 'inc/backend/user.php',
			'Indostio\Addons\Widgets'        => INDOSTIO_ADDONS_DIR . 'inc/widgets/widgets.php',
			'Indostio\Addons\Theme_Builder'  => INDOSTIO_ADDONS_DIR . 'inc/backend/theme-builder.php',
			'Indostio\Addons\Elementor'      => INDOSTIO_ADDONS_DIR . 'inc/elementor/elementor.php',
			'Indostio\Addons\Modules'        => INDOSTIO_ADDONS_DIR . 'modules/modules.php',
			'Indostio\Addons\Theme_Settings' => INDOSTIO_ADDONS_DIR . 'inc/backend/theme-settings.php',
			'Indostio\Addons\Importer'      => INDOSTIO_ADDONS_DIR . 'inc/backend/importer.php',
		] );
	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	protected function add_actions() {
		// Before init action.
		do_action( 'before_indostio_init' );

		add_action( 'after_setup_theme', array( $this, 'addons_init' ), 20 );

		\Indostio\Addons\User::instance();

		\Indostio\Addons\Widgets::instance();

		\Indostio\Addons\Elementor::instance();

		\Indostio\Addons\Modules::instance();

		\Indostio\Addons\Theme_Settings::instance();

		if( is_admin() ) {
			\Indostio\Addons\Importer::instance();
		}

		if ( defined( 'ELEMENTOR_VERSION' ) ) {
			return \Indostio\Addons\Theme_Builder::instance();
		}

		// Init action.
		do_action( 'after_indostio_init' );
	}

	/**
	 * Get Indostio Addons Language
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function addons_init() {
		load_plugin_textdomain( 'indostio', false, dirname( plugin_basename( __FILE__ ) ) . '/lang' );
	}
}
