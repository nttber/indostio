<?php
/**
 * Indostio Addons Modules functions and definitions.
 *
 * @package Indostio
 */

namespace Indostio\Addons;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Addons Modules
 */
class Modules {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Registered modules.
	 *
	 * Holds the list of all the registered modules.
	 *
	 * @var array
	 */
	private $modules = [];

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		$this->includes();
		$this->add_actions();
	}

	/**
	 * Includes files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function includes() {
		\Indostio\Addons\Auto_Loader::register( [
			//Service
			'Indostio\Addons\Modules\Service\Module' 			    	=> INDOSTIO_ADDONS_DIR . 'modules/service/module.php',
			'Indostio\Addons\Modules\Team\Module' 			    	=> INDOSTIO_ADDONS_DIR . 'modules/team/module.php',
			'Indostio\Addons\Modules\Portfolio\Module' 			    	=> INDOSTIO_ADDONS_DIR . 'modules/portfolio/module.php',
		] );
	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	protected function add_actions() {
		if( empty( get_option('services_disable') )) {
		\Indostio\Addons\Modules\Service\Module::instance();
		}

		if( empty( get_option('team_disable') )) {
			\Indostio\Addons\Modules\Team\Module::instance();
		}

		if( empty( get_option('portfolio_disable') )) {
			\Indostio\Addons\Modules\Portfolio\Module::instance();
		}
	}

	/**
	 * Get module class name
	 *
	 * @param string $module_name
	 * @return string
	 */
	public function get_module_classname( $module_name ) {
		$class_name = str_replace( '-', ' ', $module_name );
		$class_name = str_replace( ' ', '_', ucwords( $class_name ) );
		$class_name = 'Indostio\\Addons\\Modules\\' . $class_name . '\\Module';

		return $class_name;
	}
}
