<?php

namespace Indostio\Addons\Modules\Service;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Main class of plugin for admin
 */
class Post_Type  {

	const POST_TYPE         = 'indostio_service';
	const TAXONOMY_TAB_TYPE = 'indostio_service_cat';

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		// Make sure the post types are loaded for imports.
		add_action( 'import_start', array( $this, 'register_post_type' ) );
		$this->register_post_type();
	}

	/**
	 * Register article post type
     *
	 * @since 1.0.0
     *
     * @return void
	 */
	public function register_post_type() {
		if(post_type_exists(self::POST_TYPE)) {
			return;
		}

		register_post_type( self::POST_TYPE, array(
			'description'         => esc_html__( 'Service', 'indostio' ),
			'labels'              => array(
				'name'                  => esc_html__( 'Service', 'indostio' ),
				'singular_name'         => esc_html__( 'Service', 'indostio' ),
				'menu_name'             => esc_html__( 'Services', 'indostio' ),
				'all_items'             => esc_html__( 'Services', 'indostio' ),
				'add_new'               => esc_html__( 'Add New', 'indostio' ),
				'add_new_item'          => esc_html__( 'Add New Service', 'indostio' ),
				'edit_item'             => esc_html__( 'Edit Service', 'indostio' ),
				'new_item'              => esc_html__( 'New Service', 'indostio' ),
				'view_item'             => esc_html__( 'View Service', 'indostio' ),
				'search_items'          => esc_html__( 'Search Services', 'indostio' ),
				'not_found'             => esc_html__( 'No articles found', 'indostio' ),
				'not_found_in_trash'    => esc_html__( 'No articles found in Trash', 'indostio' ),
				'filter_items_list'     => esc_html__( 'Filter articles list', 'indostio' ),
				'items_list_navigation' => esc_html__( 'Services list navigation', 'indostio' ),
				'items_list'            => esc_html__( 'Services list', 'indostio' ),
			),
			'supports'            => array( 'title', 'editor', 'elementor', 'thumbnail' ),
			'public'              => true,
			'menu_icon'           => 'dashicons-editor-help',
			'rewrite'           => array(
				'slug'         => 'service',
				'with_front'   => false,
			),
		) );

		register_taxonomy(
			self::TAXONOMY_TAB_TYPE,
			array( self::POST_TYPE ),
			array(
				'hierarchical' => true,
				'public'       => true,
				'query_var' => '',
				'label'        => _x( 'Categories', 'Taxonomy name', 'indostio' ),
				'rewrite'           => array(
					'slug'         => 'service-cat',
					'with_front'   => false,
				),
			)
		);
	}
}