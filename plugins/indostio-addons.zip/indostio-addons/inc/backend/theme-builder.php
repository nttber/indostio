<?php
/**
 * Register portfolio support
 */

namespace Indostio\Addons;

class Theme_Builder {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Class constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_admin_menu' ), 50 );

		// Make sure the post types are loaded for imports
		add_action( 'import_start', array( $this, 'register_post_type' ) );

		// Register custom post type and custom taxonomy
		add_action( 'init', array( $this, 'register_post_type' ) );

		add_filter( 'single_template', array( $this, 'load_canvas_template' ) );

	}

	/**
	 * Register portfolio post type
	 */
	public function register_post_type() {
		$this->register_header();
		$this->register_footer();
	}

	/**
	 * Register footer post type
	 */
	public function register_footer() {
		// Footer Builder
		$labels = array(
			'name'               => esc_html__( 'Footer Builder Template', 'indostio' ),
			'singular_name'      => esc_html__( 'Elementor Footer', 'indostio' ),
			'menu_name'          => esc_html__( 'Footer Template', 'indostio' ),
			'name_admin_bar'     => esc_html__( 'Elementor Footer', 'indostio' ),
			'add_new'            => esc_html__( 'Add New', 'indostio' ),
			'add_new_item'       => esc_html__( 'Add New Footer', 'indostio' ),
			'new_item'           => esc_html__( 'New Footer Template', 'indostio' ),
			'edit_item'          => esc_html__( 'Edit Footer Template', 'indostio' ),
			'view_item'          => esc_html__( 'View Footer Template', 'indostio' ),
			'all_items'          => esc_html__( 'All Elementor Footer', 'indostio' ),
			'search_items'       => esc_html__( 'Search Footer Templates', 'indostio' ),
			'parent_item_colon'  => esc_html__( 'Parent Footer Templates:', 'indostio' ),
			'not_found'          => esc_html__( 'No Footer Templates found.', 'indostio' ),
			'not_found_in_trash' => esc_html__( 'No Footer Templates found in Trash.', 'indostio' ),
		);

		$args = array(
			'labels'              => $labels,
			'public'              => true,
			'rewrite'             => false,
			'show_ui'             => true,
			'show_in_menu'        => false,
			'show_in_nav_menus'   => false,
			'exclude_from_search' => true,
			'capability_type'     => 'post',
			'hierarchical'        => false,
			'menu_icon'           => 'dashicons-editor-kitchensink',
			'supports'            => array( 'title', 'editor', 'elementor' ),
		);


		if ( ! post_type_exists( 'indostio_footer' ) ) {
			register_post_type( 'indostio_footer', $args );
		}
	}

	/**
	 * Register header post type
	 */
	public function register_header() {
		// Footer Builder
		$labels = array(
			'name'               => esc_html__( 'Header Builder Template', 'indostio' ),
			'singular_name'      => esc_html__( 'Elementor Header', 'indostio' ),
			'menu_name'          => esc_html__( 'Header Template', 'indostio' ),
			'name_admin_bar'     => esc_html__( 'Elementor Header', 'indostio' ),
			'add_new'            => esc_html__( 'Add New', 'indostio' ),
			'add_new_item'       => esc_html__( 'Add New Header', 'indostio' ),
			'new_item'           => esc_html__( 'New Header Template', 'indostio' ),
			'edit_item'          => esc_html__( 'Edit Header Template', 'indostio' ),
			'view_item'          => esc_html__( 'View Header Template', 'indostio' ),
			'all_items'          => esc_html__( 'All Elementor Header', 'indostio' ),
			'search_items'       => esc_html__( 'Search Header Templates', 'indostio' ),
			'parent_item_colon'  => esc_html__( 'Parent Header Templates:', 'indostio' ),
			'not_found'          => esc_html__( 'No Header Templates found.', 'indostio' ),
			'not_found_in_trash' => esc_html__( 'No Header Templates found in Trash.', 'indostio' ),
		);

		$args = array(
			'labels'              => $labels,
			'public'              => true,
			'rewrite'             => false,
			'show_ui'             => true,
			'show_in_menu'        => false,
			'show_in_nav_menus'   => false,
			'exclude_from_search' => true,
			'capability_type'     => 'post',
			'hierarchical'        => false,
			'menu_icon'           => 'dashicons-editor-kitchensink',
			'supports'            => array( 'title', 'editor', 'elementor' ),
		);


		if ( ! post_type_exists( 'indostio_header' ) ) {
			register_post_type( 'indostio_header', $args );
		}
	}

	public function register_admin_menu() {
		add_submenu_page(
			'edit.php?post_type=elementor_library',
			esc_html__( 'Header Builder', 'indostio' ),
			esc_html__( 'Header Builder', 'indostio' ),
			'edit_pages',
			'edit.php?post_type=indostio_header'
		);
		add_submenu_page(
			'edit.php?post_type=elementor_library',
			esc_html__( 'Footer Builder', 'indostio' ),
			esc_html__( 'Footer Builder', 'indostio' ),
			'edit_pages',
			'edit.php?post_type=indostio_footer'
		);

	}


	function load_canvas_template( $single_template ) {
		global $post;

		if ( 'indostio_footer' == $post->post_type || 'indostio_header' == $post->post_type  ) {

			return ELEMENTOR_PATH . '/modules/page-templates/templates/canvas.php';
		}

		return $single_template;
	}
}