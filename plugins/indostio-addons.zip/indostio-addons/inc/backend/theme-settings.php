<?php
/**
 * Register footer builder
 */

namespace Indostio\Addons;

class Theme_Settings {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Class constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_admin_menu' ), 50 );
		add_action('admin_init', array($this,'register_settings'));
	}

	public function theme_settings_page() {
		echo '<form action="options.php" method="post">';
		settings_fields("theme_settings");
		do_settings_sections( 'theme_settings' );
		submit_button();
		echo '</form>';
	}

	public function register_settings() {
		add_settings_section(
			'services_section',
			esc_html__( 'Services', 'indostio' ),
			'',
			'theme_settings'
		);
		register_setting(
			'theme_settings',
			'services_disable',
			'string'
		);
		add_settings_field(
			'servicess_disable',
			esc_html__( 'Disable Services', 'indostio' ),
			array($this,'services_disable_field_html'),
			'theme_settings',
			'services_section'
		);

		register_setting(
			'theme_settings',
			'service_page_id',
			'string'
		);

		add_settings_field(
			'service_page_id',
			esc_html__( 'Service Page', 'indostio' ),
			array($this,'service_page_field_html'),
			'theme_settings',
			'services_section'
		);

		add_settings_section(
			'team_section',
			esc_html__( 'Team', 'indostio' ),
			'',
			'theme_settings'
		);

		register_setting(
			'theme_settings',
			'team_disable',
			'string'
		);

		add_settings_field(
			'team_disable',
			esc_html__( 'Disable Team', 'indostio' ),
			array($this,'team_disable_field_html'),
			'theme_settings',
			'team_section'
		);

		register_setting(
			'theme_settings',
			'team_page_id',
			'string'
		);

		add_settings_field(
			'team_page_id',
			esc_html__( 'Team Page', 'indostio' ),
			array($this,'team_page_field_html'),
			'theme_settings',
			'team_section'
		);

		add_settings_section(
			'portfolio_section',
			esc_html__( 'Portfolio', 'indostio' ),
			'',
			'theme_settings'
		);

		register_setting(
			'theme_settings',
			'portfolio_disable',
			'string'
		);

		add_settings_field(
			'portfolio_disable',
			esc_html__( 'Disable Portfolio', 'indostio' ),
			array($this,'portfolio_disable_field_html'),
			'theme_settings',
			'portfolio_section'
		);

		register_setting(
			'theme_settings',
			'portfolio_page_id',
			'string'
		);

		add_settings_field(
			'portfolio_page_id',
			esc_html__( 'Portfolio Page', 'indostio' ),
			array($this,'portfolio_page_field_html'),
			'theme_settings',
			'portfolio_section'
		);


	}

	public function register_admin_menu() {
		add_submenu_page(
			'themes.php',
			esc_html__( 'Theme Settings', 'indostio' ),
			esc_html__( 'Theme Settings', 'indostio' ),
			'manage_options',
			'theme_settings',
			array($this, 'theme_settings_page')
		);

	 }

	public function services_disable_field_html() {
		$service_default = 1;
		$service_disable = get_option( 'services_disable' );
		?>
		<input type="checkbox" name="services_disable" <?php checked( $service_default, $service_disable ); ?> value="<?php echo $service_default; ?>">
		<label><?php esc_html_e('Yes', 'indostio'); ?></label>
		<?php

	}

	public function service_page_field_html() {
		$page_id = get_option( 'service_page_id' );
		$page_id = ! empty ( $page_id ) ? $page_id : '';
		wp_dropdown_pages( array(
			'selected'          => $page_id,
			'name'              => 'service_page_id',
			'show_option_none'  => esc_html__( '&mdash; Select &mdash;', 'indostio' ),
			'option_none_value' => 0,
		) );
	}

	public function team_disable_field_html() {
		$team_default = 1;
		$team_disable = get_option( 'team_disable' );
		?>
		<input type="checkbox" name="team_disable" <?php checked( $team_default, $team_disable ); ?> value="<?php echo $team_default; ?>">
		<label><?php esc_html_e('Yes', 'indostio'); ?></label>
		<?php

	}

	public function team_page_field_html() {
		$page_id = get_option( 'team_page_id' );
		$page_id = ! empty ( $page_id ) ? $page_id : '';
		wp_dropdown_pages( array(
			'selected'          => $page_id,
			'name'              => 'team_page_id',
			'show_option_none'  => esc_html__( '&mdash; Select &mdash;', 'indostio' ),
			'option_none_value' => 0,
		) );
	}

	public function portfolio_disable_field_html() {
		$portfolio_default = 1;
		$portfolio_disable = get_option( 'portfolio_disable' );
		?>
		<input type="checkbox" name="portfolio_disable" <?php checked( $portfolio_default, $portfolio_disable ); ?> value="<?php echo $portfolio_default; ?>">
		<label><?php esc_html_e('Yes', 'indostio'); ?></label>
		<?php

	}

	public function portfolio_page_field_html() {
		$page_id = get_option( 'portfolio_page_id' );
		$page_id = ! empty ( $page_id ) ? $page_id : '';
		wp_dropdown_pages( array(
			'selected'          => $page_id,
			'name'              => 'portfolio_page_id',
			'show_option_none'  => esc_html__( '&mdash; Select &mdash;', 'indostio' ),
			'option_none_value' => 0,
		) );
	}
}