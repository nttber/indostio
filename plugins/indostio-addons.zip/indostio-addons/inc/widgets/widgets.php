<?php
/**
 * Load and register widgets
 *
 * @package Indostio
 */

namespace Indostio\Addons;
/**
 * Indostio theme init
 */
class Widgets {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		// Include plugin files
		add_action( 'widgets_init', array( $this, 'register_widgets' ) );
	}


	/**
	 * Register widgets
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function register_widgets() {
		$this->includes();
		$this->add_actions();
	}

	/**
	 * Include Files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function includes() {
		\Indostio\Addons\Auto_Loader::register( [
			'Indostio\Addons\Widgets\Newsletter_Widget'    => INDOSTIO_ADDONS_DIR . 'inc/widgets/newsletter.php',
			'Indostio\Addons\Widgets\Popular_Posts_Widget'    => INDOSTIO_ADDONS_DIR . 'inc/widgets/popular-posts.php',
			'Indostio\Addons\Widgets\Banner_Widget'    => INDOSTIO_ADDONS_DIR . 'inc/widgets/banner.php',
			'Indostio\Addons\Widgets\Services_Menu_Widget'    => INDOSTIO_ADDONS_DIR . 'inc/widgets/service-menu.php',
		] );
	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function add_actions() {
		register_widget( new \Indostio\Addons\Widgets\Newsletter_Widget() );
		register_widget( new \Indostio\Addons\Widgets\Popular_Posts_Widget() );
		register_widget( new \Indostio\Addons\Widgets\Banner_Widget() );
		register_widget( new \Indostio\Addons\Widgets\Services_Menu_Widget() );
	}
}