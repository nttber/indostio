<?php
/**
 * Popular posts widget
 *
 * @package Indostio
 */

namespace Indostio\Addons\Widgets;

/**
 * Class Popular_Posts_Widget
 */
class Popular_Posts_Widget extends \WP_Widget {
	/**
	 * Holds widget settings defaults, populated in constructor.
	 *
	 * @var array
	 */
	protected $defaults;

	/**
	 * Class constructor
	 * Set up the widget
	 */
	public function __construct() {
		$this->defaults = array(
			'title'    => false,
			'limit' => 5,
		);

		parent::__construct(
			'indostio-popular-posts-widget',
			esc_html__( 'Indostio - Popular Posts', 'indostio' ),
			array(
				'classname'                   => 'indostio-popular-posts-widget',
				'description'                 => esc_html__( 'Displays popular posts', 'indostio' ),
				'customize_selective_refresh' => true,
			)
		);
	}

	/**
	 * Outputs the content for the current Archives widget instance.
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Archives widget instance.
	 */
	public function widget( $args, $instance ) {
		$instance = wp_parse_args( $instance, $this->defaults );

		$popular_posts = new \WP_Query( array(
			'post_type'              => 'post',
			'post_status'            => 'publish',
			'posts_per_page'         => $instance['limit'],
			'orderby'                => 'comment_count',
			'order'                  => 'DESC',
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'cache_results'          => false,
			'ignore_sticky_posts'    => true,
		) );

		if ( ! $popular_posts->have_posts() ) {
			return;
		}

		echo $args['before_widget'];
		?>

		<ul>

			<?php while ( $popular_posts->have_posts() ) : $popular_posts->the_post(); ?>
				<li>
					<?php $this->entry_thumbnail(); ?>
					<div class="post-summary">
						<span class="post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute() ?>"><?php the_title(); ?></a></span>
						<div class="post-meta__date">
						<span class="indostio-svg-icon"><svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.498 2H11.998V0.375C11.998 0.1875 11.8105 0 11.623 0H11.373C11.1543 0 10.998 0.1875 10.998 0.375V2H4.99805V0.375C4.99805 0.1875 4.81055 0 4.62305 0H4.37305C4.1543 0 3.99805 0.1875 3.99805 0.375V2H2.49805C1.6543 2 0.998047 2.6875 0.998047 3.5V14.5C0.998047 15.3438 1.6543 16 2.49805 16H13.498C14.3105 16 14.998 15.3438 14.998 14.5V3.5C14.998 2.6875 14.3105 2 13.498 2ZM2.49805 3H13.498C13.748 3 13.998 3.25 13.998 3.5V5H1.99805V3.5C1.99805 3.25 2.2168 3 2.49805 3ZM13.498 15H2.49805C2.2168 15 1.99805 14.7812 1.99805 14.5V6H13.998V14.5C13.998 14.7812 13.748 15 13.498 15ZM5.62305 10C5.81055 10 5.99805 9.84375 5.99805 9.625V8.375C5.99805 8.1875 5.81055 8 5.62305 8H4.37305C4.1543 8 3.99805 8.1875 3.99805 8.375V9.625C3.99805 9.84375 4.1543 10 4.37305 10H5.62305ZM8.62305 10C8.81055 10 8.99805 9.84375 8.99805 9.625V8.375C8.99805 8.1875 8.81055 8 8.62305 8H7.37305C7.1543 8 6.99805 8.1875 6.99805 8.375V9.625C6.99805 9.84375 7.1543 10 7.37305 10H8.62305ZM11.623 10C11.8105 10 11.998 9.84375 11.998 9.625V8.375C11.998 8.1875 11.8105 8 11.623 8H10.373C10.1543 8 9.99805 8.1875 9.99805 8.375V9.625C9.99805 9.84375 10.1543 10 10.373 10H11.623ZM8.62305 13C8.81055 13 8.99805 12.8438 8.99805 12.625V11.375C8.99805 11.1875 8.81055 11 8.62305 11H7.37305C7.1543 11 6.99805 11.1875 6.99805 11.375V12.625C6.99805 12.8438 7.1543 13 7.37305 13H8.62305ZM5.62305 13C5.81055 13 5.99805 12.8438 5.99805 12.625V11.375C5.99805 11.1875 5.81055 11 5.62305 11H4.37305C4.1543 11 3.99805 11.1875 3.99805 11.375V12.625C3.99805 12.8438 4.1543 13 4.37305 13H5.62305ZM11.623 13C11.8105 13 11.998 12.8438 11.998 12.625V11.375C11.998 11.1875 11.8105 11 11.623 11H10.373C10.1543 11 9.99805 11.1875 9.99805 11.375V12.625C9.99805 12.8438 10.1543 13 10.373 13H11.623Z" fill="currentColor"/></svg></span>
						<?php echo esc_html( get_the_date() ); ?>
					</div>
					</div>

				</li>
			<?php endwhile; ?>

		</ul>

		<?php
		wp_reset_postdata();

		echo $args['after_widget'];
	}

	/**
	 * Update widget
	 *
	 * @param array $new_instance New widget settings
	 * @param array $old_instance Old widget settings
	 *
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		$new_instance['limit'] = intval( $new_instance['limit'] );

		return $new_instance;
	}

	/**
	 * Outputs the settings form for the Archives widget.
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( $instance, $this->defaults );
		?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php esc_html_e( 'Title:', 'indostio' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'limit' ); ?>"><?php esc_html_e( 'Number of posts:', 'indostio' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'limit' ); ?>" name="<?php echo $this->get_field_name( 'limit' ); ?>" type="text" value="<?php echo intval( $instance['limit'] ); ?>" />
		</p>

		<?php
	}

	public function entry_thumbnail() {
		if ( ! has_post_thumbnail() ) {
			return;
		}

		$post_thumbnail_id = get_post_thumbnail_id( get_the_ID() );
		$get_image         = wp_get_attachment_image( $post_thumbnail_id, 'indostio-post-thumbnail-small' );
		$icon			   = '';

		switch ( get_post_format() ) {
			case 'video':
				$icon = \Indostio\Addons\Helper::get_svg( 'video', 'post-format-icon icon-video' );
				break;

			case 'gallery':
				$icon = \Indostio\Addons\Helper::get_svg( 'gallery', 'post-format-icon icon-gallery' );
				break;
		}

		if ( empty( $get_image ) ) {
			return;
		}

		echo sprintf(
			'<a class="post-thumbnail" href="%s" aria-hidden="true" tabindex="-1">%s%s</a>',
			esc_url( get_permalink() ),
			$get_image,
			$icon
		);
	}
}