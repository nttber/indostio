<?php
/**
 * Banner widget
 *
 * @package Indostio
 */

namespace Indostio\Addons\Widgets;

/**
 * Class Banner Widget
 */
class Banner_Widget extends \WP_Widget {
	/**
	 * Holds widget settings defaults, populated in constructor.
	 *
	 * @var array
	 */
	protected $defaults;

	/**
	 * Class constructor
	 * Set up the widget
	 */
	public function __construct() {
		parent::__construct(
			'indostio-Banner-widget',
			esc_html__( 'Indostio - Banner', 'indostio' ),
			array(
				'classname'                   => 'indostio-banner-widget',
				'description'                 => esc_html__( 'Displays Banner', 'indostio' ),
				'customize_selective_refresh' => true,
			)
		);
	}

	/**
	 * Outputs the content for the current Archives widget instance.
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Archives widget instance.
	 */
	public function widget( $args, $instance ) {
		echo $args['before_widget'];

		if( $instance['image_url'] ) {
			echo '<div class="indostio-banner-widget__image"><image src="' . esc_url( $instance['image_url'] ) . '" alt=""></div>';
		}

		if( $instance['title'] ) {
			echo '<div class="indostio-banner-widget__title">' . $instance['title'] . '</div>';
		}

		if( $instance['desc'] ) {
			echo '<div class="indostio-banner-widget__description">' . $instance['desc'] . '</div>';
		}

		if( $instance['button_text'] ) {
			$icon = '<span class="indostio-svg-icon"><svg width="11" height="10" viewBox="0 0 11 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.92383 4.99609C10.0605 4.85938 10.0605 4.66797 9.92383 4.53125L5.93164 0.484375C5.79492 0.347656 5.57617 0.347656 5.4668 0.484375L4.91992 1.03125C4.7832 1.14062 4.7832 1.35938 4.91992 1.49609L8.14648 4.75L4.91992 8.03125C4.7832 8.16797 4.7832 8.35938 4.91992 8.49609L5.4668 9.04297C5.57617 9.17969 5.79492 9.17969 5.93164 9.04297L9.92383 4.99609ZM5.54883 4.53125L1.55664 0.484375C1.41992 0.347656 1.20117 0.347656 1.0918 0.484375L0.544922 1.03125C0.408203 1.14062 0.408203 1.35938 0.544922 1.49609L3.77148 4.75L0.544922 8.03125C0.408203 8.16797 0.408203 8.35938 0.544922 8.49609L1.0918 9.04297C1.20117 9.17969 1.41992 9.17969 1.55664 9.04297L5.54883 4.99609C5.68555 4.85938 5.68555 4.66797 5.54883 4.53125Z" fill="white"/></svg></span>';
			echo '<div class="indostio-banner-widget__button"><a href="' . esc_url($instance['button_link']) . '">' . $instance['button_text'] . $icon . '</a></div>';
		}

		echo $args['after_widget'];
	}

	/**
	 * Update widget
	 *
	 * @param array $new_instance New widget settings
	 * @param array $old_instance Old widget settings
	 *
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		$new_instance['title']   = strip_tags( $new_instance['title'] );
		$new_instance['image_url']   = strip_tags( $new_instance['image_url'] );
		$new_instance['desc']    = wp_kses_post( $new_instance['desc'] );
		$new_instance['button_text']   = strip_tags( $new_instance['button_text'] );
		$new_instance['button_link']   = strip_tags( $new_instance['button_link'] );

		return $new_instance;
	}

	/**
	 * Outputs the settings form for the Archives widget.
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( $instance, $this->defaults );
		?>

<p>
			<label for="<?php echo $this->get_field_id( 'image_url' ); ?>"><?php esc_html_e( 'Image URL:', 'indostio' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'image_url' ); ?>" name="<?php echo $this->get_field_name( 'image_url' ); ?>" type="text" value="<?php echo esc_attr( $instance['image_url'] ); ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php esc_html_e( 'Title:', 'indostio' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'desc' ) ); ?>"><?php esc_html_e( 'Description', 'indostio' ); ?></label>
			<textarea id="<?php echo esc_attr( $this->get_field_id( 'desc' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'desc' ) ); ?>" class="widefat" rows="5"><?php echo esc_textarea( $instance['desc'] ); ?></textarea>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'button_text' ); ?>"><?php esc_html_e( 'Button Text:', 'indostio' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'button_text' ); ?>" name="<?php echo $this->get_field_name( 'button_text' ); ?>" type="text" value="<?php echo esc_attr( $instance['button_text'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'button_link' ); ?>"><?php esc_html_e( 'Button Link:', 'indostio' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'button_link' ); ?>" name="<?php echo $this->get_field_name( 'button_link' ); ?>" type="text" value="<?php echo esc_attr( $instance['button_link'] ); ?>" />
		</p>
		<?php
	}

}
