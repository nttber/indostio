<?php
/**
 * Integrate with Elementor.
 */

namespace Indostio\Addons;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Elementor {
	/**
	 * Instance
	 *
	 * @access private
	 */
	private static $_instance = null;

	/**
	 * Elementor modules
	 *
	 * @var array
	 */
	public $module = [];

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @return Indostio_Addons_Elementor An instance of the class.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		spl_autoload_register( [ $this, 'autoload' ] );

		$this->setup_hooks();
		$this->_includes();

		\Indostio\Addons\Elementor\Controls\AutoComplete_AjaxLoader::instance();
	}

	/**
	 * Auto load widgets
	 */
	public function autoload( $class ) {
		if ( 0 !== strpos( $class, __NAMESPACE__ ) ) {
			return;
		}

		$path = explode( '\\', $class );
		$filename = strtolower( array_pop( $path ) );
		$filename = str_replace( '_', '-', $filename );

		$module = array_pop( $path );

		if ( 'Modules' == $module ) {
			$filename = INDOSTIO_ADDONS_DIR . 'inc/elementor/modules/' . $filename . '.php';
		} elseif ( 'Widgets' == $module ) {
			$filename = INDOSTIO_ADDONS_DIR . 'inc/elementor/widgets/' . $filename . '.php';
		}  elseif ( 'Controls' == $module ) {
			$filename = INDOSTIO_ADDONS_DIR . 'inc/elementor/controls/' . $filename . '.php';
		}

		if ( is_readable( $filename ) ) {
			include( $filename );
		}
	}

	/**
	 * Includes files which are not widgets
	 */
	private function _includes() {
		require INDOSTIO_ADDONS_DIR . 'inc/elementor/utils.php';
		\Indostio\Addons\Auto_Loader::register( [
			'Indostio\Addons\Elementor\Controls\AjaxLoader'  => INDOSTIO_ADDONS_DIR . 'inc/elementor/controls/autocomplete-ajaxloader.php'
		] );
	}

	/**
	 * Hooks to init
	 */
	protected function setup_hooks() {
		add_action( 'elementor/init', [ $this, 'init_modules' ] );
		// Widgets
		add_action( 'elementor/frontend/after_register_scripts', [ $this, 'register_scripts' ] );
		add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
		add_action( 'elementor/widgets/register', [ $this, 'init_widgets' ] );
		add_action( 'elementor/elements/categories_registered', [ $this, 'add_category' ] );
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'register_styles' ] );
		

		// Register controls
		add_action( 'elementor/controls/register', [ $this, 'register_controls' ] );
	}

	/**
	 * Init modules
	 */
	public function init_modules() {
		$this->modules['progress-settings'] = \Indostio\Addons\Elementor\Modules\Progress_Settings::instance();
	}


	/**
	 * Register autocomplete control
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function register_controls( $controls_manager ) {
		$controls_manager->register( new \Indostio\Addons\Elementor\Controls\AutoComplete() );
	}

	/**
	 * Register styles
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function register_styles() {
		wp_register_style( 'magnific',  INDOSTIO_ADDONS_URL . 'assets/css/magnific-popup.css', array(), '1.0' );
	}


	/**
	 * Register styles
	 */
	public function register_scripts() {
		wp_register_script( 'magnific', INDOSTIO_ADDONS_URL . '/assets/js/plugins/jquery.magnific-popup.js', array(), '1.0', true );
		wp_enqueue_script( 'isotope', INDOSTIO_ADDONS_URL . '/assets/js/plugins/isotope.pkgd.min.js', array(), '1.0', true );
		wp_register_script( 'indostio-elementor-widgets', INDOSTIO_ADDONS_URL . 'assets/js/elementor-widgets.js', ['jquery', 'underscore', 'elementor-frontend', 'regenerator-runtime'], INDOSTIO_ADDONS_VER, true );

	}

	/**
	 * Enqueue scripts
	 */
	public function enqueue_scripts() {
		wp_enqueue_script( 'indostio-elementor-widgets' );
	}

	/**
	 * Init Widgets
	 */
	public function init_widgets() {
		$widgets_manager = \Elementor\Plugin::instance()->widgets_manager;

		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Icon_Box() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Social_Links() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Navigation_Menu() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Heading() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Subscribe_Box() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Info_Box() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Pricing_Table() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Posts_Carousel() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Testimonial_Carousel() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Special_Text() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Section_Title() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Counter() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Accordion() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Info_List() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Image() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Client_Logo() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Icon_List() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Post_Navigation() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\CTA() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Team_Member_Grid() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Banner_Video() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Portfolio_Grid() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Portfolio_List() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Search() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Sidebar() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Sidebar_Menu() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Tabs() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Team_Member_Carousel() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Team_Member_Carousel_V2() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Member_Info() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Image_Box() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Portfolio_Grid_V2() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Banner() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Posts_Grid() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Procress() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Team_Member_Grid_v2() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Portfolio_Carousel() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Portfolio_Carousel_V2() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Back_To_Top() );
		$widgets_manager->register( new \Indostio\Addons\Elementor\Widgets\Site_Logo() );
	}
	

	/**
	 * Add Indostio category
	 */
	public function add_category( $elements_manager ) {
		$elements_manager->add_category(
			'indostio',
			[
				'title' => __( 'Indostio', 'indostio' )
			]
		);
	}
}

Elementor::instance();