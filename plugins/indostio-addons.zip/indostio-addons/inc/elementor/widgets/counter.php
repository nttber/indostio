<?php

namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;
use Elementor\Widget_Base;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Icon Box widget
 */
class Counter extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-counter';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( '[Indostio] Counter', 'indostio' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-counter-circle';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'indostio' ];
	}

	public function get_script_depends() {
		return [
			'jquery-numerator',
		];
	}

		/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->section_content();
		$this->section_style();
	}

	// Tab Content
	protected function section_content() {
		$this->section_content_counter();
	}

	// Tab Style
	protected function section_style() {
		$this->section_style_counter();
	}

	protected function section_content_counter() {
		$this->start_controls_section(
			'section_content',
			[ 'label' => esc_html__( 'Counter', 'indostio' ) ]
		);

		$this->add_control(
			'icon',
			[
				'label' => __( 'Icon', 'indostio' ),
				'type' => Controls_Manager::ICONS,
				'default' => [],
			]
		);

		$this->add_control(
			'starting_number',
			[
				'label' => esc_html__( 'Starting Number', 'indostio' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 0,
			]
		);

		$this->add_control(
			'ending_number',
			[
				'label' => esc_html__( 'Ending Number', 'indostio' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 100,
			]
		);

		$this->add_control(
			'suffix',
			[
				'label' => esc_html__( 'Number Suffix', 'indostio' ),
				'type' => Controls_Manager::TEXT,
				'default' => '',
				'placeholder' => esc_html__( 'Plus', 'indostio' ),
			]
		);

		$this->add_control(
			'duration',
			[
				'label' => esc_html__( 'Animation Duration', 'indostio' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 2000,
				'min' => 100,
				'step' => 100,
			]
		);

		$this->add_control(
			'title', [
				'label'       => esc_html__( 'Title', 'indostio' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
			]
		);

		$this->end_controls_section();
	}


	protected function section_style_counter(){
		// Number
		$this->start_controls_section(
			'section_style_number',
			[
				'label' => esc_html__( 'Counter', 'indostio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'icon_spacing',
			[
				'label'     => esc_html__( 'Icon Spacing', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-counter__icon' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'number_width',
			[
				'label'     => esc_html__( 'Number Width', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 500,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-counter__number' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'number_color',
			[
				'label'     => esc_html__( 'Number Color', 'indostio' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .indostio-counter__number-wrapper' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'number_bg_image',
			[
				'label' => __( 'Number Background Image', 'indostio' ),
				'type' => Controls_Manager::MEDIA,
				'selectors'  => [
					'{{WRAPPER}} .indostio-counter__number-content' => 'background-image: url("{{URL}}");',
				],
			]
		);

		$this->add_responsive_control(
			'number_background_position',
			[
				'label'     => esc_html__( 'Number Background Position', 'indostio' ),
				'type'      => Controls_Manager::SELECT,
				'responsive' => true,
				'options'   => [
					''              => esc_html__( 'Default', 'indostio' ),
					'left top'      => esc_html__( 'Left Top', 'indostio' ),
					'left center'   => esc_html__( 'Left Center', 'indostio' ),
					'left bottom'   => esc_html__( 'Left Bottom', 'indostio' ),
					'right top'     => esc_html__( 'Right Top', 'indostio' ),
					'right center'  => esc_html__( 'Right Center', 'indostio' ),
					'right bottom'  => esc_html__( 'Right Bottom', 'indostio' ),
					'center top'    => esc_html__( 'Center Top', 'indostio' ),
					'center center' => esc_html__( 'Center Center', 'indostio' ),
					'center bottom' => esc_html__( 'Center Bottom', 'indostio' ),
					'initial' 		=> esc_html__( 'Custom', 'indostio' ),
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .indostio-counter__number-content' => 'background-position: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label'     => esc_html__( 'Number Typography', 'indostio' ),
				'name'     => 'value_typography',
				'selector' => '{{WRAPPER}} .indostio-counter__number-content',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label'     => esc_html__( 'Suffix Typography', 'indostio' ),
				'name'     => 'suffix_typography',
				'selector' => '{{WRAPPER}} .indostio-counter__number-suffix',
			]
		);

		
		$this->add_responsive_control(
			'number_suffix_spacing',
			[
				'label'     => esc_html__( 'Suffix Spacing', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 200,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-counter__number-suffix' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Title
		$this->start_controls_section(
			'section_style_title',
			[
				'label' => esc_html__( 'Title', 'indostio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'indostio' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .indostio-counter__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .indostio-counter__title',
			]
		);

		$this->add_responsive_control(
			'title_spacing',
			[
				'label'     => esc_html__( 'Spacing', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-counter__title' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render icon box widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute(
			'wrapper', 'class', [
				'indostio-counter',
			]
		);
		$number_class= ! empty($settings['number_bg_image'] ) && !empty($settings['number_bg_image']['url']) ? 'has-bg-image' : '';
		$this->add_render_attribute( 'counter', [
			'class' => 'indostio-counter__number',
			'data-duration' => $settings['duration'],
			'data-to-value' => $settings['ending_number'],
			'data-from-value' => $settings['starting_number'],
		] );

		$this->add_render_attribute( 'counter-title', 'class', 'indostio-counter__title' );

		$this->add_inline_editing_attributes( 'counter-title' );
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<div class="indostio-counter__number-wrapper">
				<?php if ( ! empty($settings['icon'] ) && ! empty($settings['icon']['value']) ) : ?>
					<span class="indostio-counter__icon indostio-svg-icon">
						<?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
					</span>
				<?php endif; ?>
				<div class="indostio-counter__number-content <?php echo esc_attr($number_class); ?>">
					<span <?php $this->print_render_attribute_string( 'counter' ); ?>><?php $this->print_unescaped_setting( 'starting_number' ); ?></span>
					<?php if ( $settings['suffix'] ) : ?>
						<span class="indostio-counter__number-suffix"><?php $this->print_unescaped_setting( 'suffix' ); ?></span>
					<?php endif; ?>
				</div>
			</div>
			<?php if ( $settings['title'] ) : ?>
				<div <?php $this->print_render_attribute_string( 'counter-title' ); ?>><?php $this->print_unescaped_setting( 'title' ); ?></div>
			<?php endif; ?>
		</div>
		<?php
	}

}