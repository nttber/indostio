<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Indostio\Addons\Helper;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor heading widget.
 *
 * Elementor widget that displays an eye-catching headlines.
 *
 * @since 1.0.0
 */
class Section_Title extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve heading widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-section-title';
	}

	/**
	 * Get widget title
	 *
	 * Retrieve heading widget title
	 *
	 * @return string Widget title
	 */
	public function get_title() {
		return __( '[Indostio] Section Title', 'indostio' );
	}

	/**
	 * Get widget icon
	 *
	 * Retrieve heading widget icon
	 *
	 * @return string Widget icon
	 */
	public function get_icon() {
		return 'eicon-t-letter';
	}

	/**
	 * Get widget categories
	 *
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return string Widget categories
	 */
	public function get_categories() {
		return [ 'indostio' ];
	}

	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'heading', 'title', 'text', 'indostio' ];
	}

	/**
	 * Register heading widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'indostio' ),
			]
		);

		$this->add_control(
			'subtitle',
			[
				'label' => __( 'Sub Title', 'indostio' ),
				'type' => Controls_Manager::TEXTAREA,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your subtitle', 'indostio' ),
			]
		);

		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'indostio' ),
				'type' => Controls_Manager::TEXTAREA,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title', 'indostio' ),
			]
		);

		$this->add_control(
			'text_effect',
			[
				'label' => __( 'Text Effect', 'indostio' ),
				'type' => Controls_Manager::TEXTAREA,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'title_size',
			[
				'label' => __( 'HTML Tag', 'indostio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'h2',
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => __( 'Alignment', 'indostio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => __( 'Left', 'indostio' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'indostio' ),
						'icon' => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'indostio' ),
						'icon' => 'eicon-text-align-right',
					],
					'space-between' => [
						'title' => __( 'Between', 'indostio' ),
						'icon' => 'eicon-justify-space-between-h',
					],
				],
				'default' => 'flex-start',
				'selectors' => [
					'{{WRAPPER}} .indostio-section-title' => 'justify-content:{{VALUE}}',
				],
			]
		);

		$this->add_control(
			'button_icon',
			[
				'label' => __( 'Button Icon', 'indostio' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
				],
			]
		);

		$this->add_control(
			'button_text',
			[
				'label' => __( 'Button Text', 'indostio' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => '',
				'label_block' => true,
			]
		);

		$this->add_control(
			'button_url',
			[
				'label' => esc_html__( 'Button URL', 'indostio' ),
				'type' => Controls_Manager::URL,
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		// Style before Title
		$this->start_controls_section(
			'section_style_content',
			[
				'label'     => __( 'Content', 'indostio' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'text_align',
			[
				'label' => __( 'Text Align', 'indostio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'indostio' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'indostio' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'indostio' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}} .indostio-section-title' => 'text-align:{{VALUE}}',
				],
			]
		);

		$this->add_control(
			'heading_subtitle',
			[
				'label'     => esc_html__( 'SubTitle', 'indostio' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-section-title_subheading' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_typography',
				'selector' => '{{WRAPPER}} .indostio-section-title_subheading',
			]
		);

		$this->add_responsive_control(
			'subtitle_spacing',
			[
				'label' => __( 'Spacing', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-section-title_subheading' => 'padding-bottom: {{size}}{{UNIT}} ;',
				],
			]
		);


		$this->add_control(
			'heading_title',
			[
				'label'     => esc_html__( 'Title', 'indostio' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-section-title_heading' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .indostio-section-title_heading',
			]
		);

		$this->add_responsive_control(
			'title_spacing',
			[
				'label' => __( 'Spacing', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-section-title_heading' => 'padding-bottom: {{size}}{{UNIT}} ;',
				],
			]
		);

		$this->add_control(
			'text_effect_title',
			[
				'label'     => esc_html__( 'Text Effect', 'indostio' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$this->add_responsive_control(
			'text_effect_top',
			[
				'label'     => __( 'Top', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'vw' ],
				'range'     => [
					'px' => [
						'max' => 1000,
						'min' => -500,
					],
					'vw' => [
						'max' => 100,
						'min' => -100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-section-title_text-effect' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'text_effect_left',
			[
				'label'     => __( 'Left', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'vw'],
				'range'     => [
					'px' => [
						'max' => 1000,
						'min' => -500,
					],
					'vw' => [
						'max' => 100,
						'min' => -100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-section-title_text-effect' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'text_effect_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-section-title_text-effect' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_effect_typography',
				'selector' => '{{WRAPPER}} .indostio-section-title_text-effect',
			]
		);

		$this->add_control(
			'title_stroke',
			[
				'label'        => __( 'Stroke', 'indostio' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'indostio' ),
				'label_on'  => __( 'On', 'indostio' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'stroke_stype',
			[
				'label' => __( 'Stroke Style', 'indostio' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'boxshadow',
				'options' => [
					'boxshadow' => __( 'Use Boxshadow CSS', 'indostio' ),
					'stroke' => __( 'Use Stroke CSS', 'indostio' ),
				],
			]
		);


		$this->add_control(
			'text_effect_stroke_color',
			[
				'label' => __( 'Text Effect Stroke Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-section-title_text-effect' => '--id-heading-stroke-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_style_heading',
			[
				'label' => __( 'Button', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'button_bg_color',
			[
				'label' => __( 'Background Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-section-title__button' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'button_border_color',
			[
				'label' => __( 'Border Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-section-title__button' => 'border-color: {{VALUE}}',
				],
			]
		);


		$this->add_control(
			'button_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-section-title__button' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'button_typography',
				'selector' => '{{WRAPPER}} .indostio-section-title__button',
			]
		);

		$this->add_responsive_control(
			'button_icon_size',
			[
				'label' => __( 'Icon Size', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					]
				],
				'default' => [],
				'selectors' => [
					'{{WRAPPER}} .indostio-section-title__button-icon' => 'font-size: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render heading widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'wrapper', 'class', [ 'indostio-section-title' ] );

		$this->add_render_attribute( 'title', 'class', [ 'indostio-section-title_heading' ] );

		$this->add_inline_editing_attributes( 'title' );

		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
				<div class="indostio-section-title__content">
					<?php if( $settings['subtitle'] ) { ?>
						<span class="indostio-section-title_subheading"><?php echo $settings['subtitle'] ?></span>
					<?php } ?>
					<<?php echo esc_attr( $settings['title_size'] ); ?> <?php echo $this->get_render_attribute_string( 'title' ); ?>>
						<?php echo wp_kses_post( do_shortcode($settings['title']) ); ?>
					</<?php echo esc_attr( $settings['title_size'] ); ?>>
					<?php if( $settings['text_effect'] ) { ?>
						<span class="indostio-section-title_text-effect <?php echo 'indostio-section-title_text-effect--' . $settings['stroke_stype']; ?>"><?php echo $settings['text_effect'] ?></span>
					<?php } ?>
				</div>
				<?php
				if ( ! empty($settings['button_text'] ) ) {
					echo Helper::render_control_link_open( 'btn_full', $settings['button_url'],  [ 'class' => 'indostio-section-title__button indostio-button' ] );
					echo '<span class="indostio-section-title__button-text">' . $settings['button_text'] . '</span>';
					echo '<span class="indostio-svg-icon indostio-section-title__button-icon">';
						\Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] );
					echo '</span>';
					echo '</a>';
				}
				?>
			</div>
		<?php
	}
}