<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Controls_Stack ;
use Elementor\Group_Control_Border ;
use Indostio\Addons\Helper;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Member Info widget
 */
class Member_Info extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-member-info';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Indostio] Member Info', 'indostio' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-info-box';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return ['indostio'];
	}

	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
   	public function get_keywords() {
	   return [ 'icon box', 'icon', 'box', 'indostio' ];
   	}

	/**
	 * Register the widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->content_sections();
		$this->style_sections();
	}

	protected function content_sections() {
		$this->start_controls_section(
			'section_icon',
			[ 'label' => __( 'Member Info', 'indostio' ) ]
		);

		
		$this->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'indostio' ),
				'type'    => Controls_Manager::MEDIA,
			]
		);


		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'indostio' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'This is the heading', 'indostio' ),
				'placeholder' => __( 'Enter your title', 'indostio' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'description',
			[
				'label' => __( 'Description', 'indostio' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'indostio' ),
				'placeholder' => __( 'Enter your description', 'indostio' ),
				'rows' => 10,
				'separator' => 'none',
			]
		);

		// Socials
		$this->add_control(
			'socials_toggle',
			[
				'label' => __( 'Socials', 'indostio' ),
				'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
				'label_off' => __( 'Default', 'indostio' ),
				'label_on' => __( 'Custom', 'indostio' ),
				'return_value' => 'yes',
				'separator' => 'before',
			]
		);

		$this->start_popover();

		$socials = $this->get_social_icons();

		foreach( $socials as $key => $social ) {
			$this->add_control(
				$key,
				[
					'label'       => $social['label'],
					'type'        => Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'indostio' ),
					'default'     => [
						'url' => '',
					],
				]
			);
		}

		$this->end_popover();


		$this->end_controls_section();
	}

	/**
	 * Get Team Member Socials
	 */
	protected function get_social_icons() {
		$socials = [
			'twitter' => [
				'name'  => 'twitter',
				'label' => __( 'Twitter', 'indostio' )
			],
			'facebook' => [
				'name'  => 'facebook',
				'label' => __( 'Facebook', 'indostio' )
			],
			'youtube' => [
				'name'  => 'youtube',
				'label' => __( 'Youtube', 'indostio' )
			],
			'dribbble' => [
				'name'  => 'dribbble',
				'label' => __( 'Dribbble', 'indostio' )
			],
			'linkedin' => [
				'name'  => 'linkedin',
				'label' => __( 'Linkedin', 'indostio' )
			],
			'pinterest' => [
				'name' 	=> 'pinterest',
				'label' => __( 'Pinterest', 'indostio' )
			],
			'instagram' => [
				'name' 	=> 'instagram',
				'label' => __( 'Instagram', 'indostio' )
			],
		];

		return apply_filters( 'indostio_addons_team_member_social_icons' , $socials );
	}

	protected function style_sections() {
		$this->content_style_sections();
	}

	protected function content_style_sections() {
		// Content style
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => __( 'Content', 'indostio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_style_heading',
			[
				'label' => __( 'Title', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-member-info__title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .indostio-member-info__title',
			]
		);

		$this->add_responsive_control(
			'title_spacing',
			[
				'label' => __( 'Spacing', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					]
				],
				'default' => [],
				'selectors' => [
					'{{WRAPPER}} .indostio-member-info__title' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'description_style_heading',
			[
				'label' => __( 'Description', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-member-info__description' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .indostio-member-info__description',
			]
		);

		$this->add_control(
			'socials_style_heading',
			[
				'label' => __( 'Socials', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'social_typography',
				'selector' => '{{WRAPPER}} .indostio-member-info__socials a',
			]
		);
		
		$this->add_control(
			'social_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-member-info__socials a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'social_hover_color',
			[
				'label' => __( 'Hover Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-member-info__socials a:hover' => 'color: {{VALUE}}',
				],
			]
		);


		$this->end_controls_section();
	}

	/**
	 * Render icon box widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'wrapper', 'class', ['indostio-member-info'] );
		$this->add_render_attribute( 'title', 'class', 'indostio-member-info__title' );
		$this->add_render_attribute( 'description', 'class', 'indostio-member-info__description' );

		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<div class="indostio-member-info__image">
				<?php echo Group_Control_Image_Size::get_attachment_image_html( $settings ); ?>
			</div>
			<div class="indostio-member-info__content">
				<?php if( ! empty( $settings['title'] ) ) : ?>
					<div <?php echo $this->get_render_attribute_string( 'title' ); ?>>
					<?php echo esc_html( $settings['title'] ) ?>
					</div>
				<?php endif; ?>
				<?php if( ! empty( $settings['description'] ) ) : ?>
					<div <?php echo $this->get_render_attribute_string( 'description' ); ?>><?php echo wp_kses_post( $settings['description'] ) ?></div>
				<?php endif; ?>
				<?php
				$socials = $this->get_social_icons();
				$socials_html = '';
	
				foreach( $socials as $key => $social ) {
					if ( empty( $settings[ $key ]['url'] ) ) {
						continue;
					}
	
					$link_key = $this->get_repeater_setting_key( 'link', 'social', $key );
					$this->add_link_attributes( $link_key, $settings[ $key ] );
					$this->add_render_attribute( $link_key, 'title', $social['name'] );
	
					$socials_html .= sprintf(
						'<a %s>%s</a>',
						$this->get_render_attribute_string( $link_key ),
						\Indostio\Addons\Helper::get_svg( $social['name'], '', 'social' )
					);
				}

				if( ! empty( $socials_html ) ) {
					echo sprintf('<div class="indostio-member-info__socials">%s</div>', $socials_html);
				}
				?>
			</div>
		</div>
		<?php
	}
}