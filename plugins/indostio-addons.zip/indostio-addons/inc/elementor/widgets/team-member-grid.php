<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Indostio\Addons\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor TeamMemberGrid widget.
 *
 * Elementor widget that displays an eye-catching headlines.
 *
 * @since 1.0.0
 */
class Team_Member_Grid extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve TeamMemberGrid widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-team-member-grid';
	}

	/**
	 * Get widget title
	 *
	 * Retrieve TeamMemberGrid widget title
	 *
	 * @return string Widget title
	 */
	public function get_title() {
		return __( '[Indostio] Team Member Grid', 'indostio' );
	}

	/**
	 * Get widget icon
	 *
	 * Retrieve TeamMemberGrid widget icon
	 *
	 * @return string Widget icon
	 */
	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	/**
	 * Get widget categories
	 *
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return string Widget categories
	 */
	public function get_categories() {
		return [ 'indostio' ];
	}

	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'team', 'member', 'grid', 'indostio' ];
	}

	/**
	 * Get Team Member Socials
	 */
	protected function get_social_icons() {
		$socials = [
			'twitter' => [
				'name'  => 'twitter',
				'label' => __( 'Twitter', 'indostio' )
			],
			'facebook' => [
				'name'  => 'facebook',
				'label' => __( 'Facebook', 'indostio' )
			],
			'youtube' => [
				'name'  => 'youtube',
				'label' => __( 'Youtube', 'indostio' )
			],
			'dribbble' => [
				'name'  => 'dribbble',
				'label' => __( 'Dribbble', 'indostio' )
			],
			'linkedin' => [
				'name'  => 'linkedin',
				'label' => __( 'Linkedin', 'indostio' )
			],
			'pinterest' => [
				'name' 	=> 'pinterest',
				'label' => __( 'Pinterest', 'indostio' )
			],
			'instagram' => [
				'name' 	=> 'instagram',
				'label' => __( 'Instagram', 'indostio' )
			],
		];

		return apply_filters( 'indostio_addons_team_member_social_icons' , $socials );
	}

	/**
	 * Register heading widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'indostio' ),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'indostio' ),
				'type'    => Controls_Manager::MEDIA,
			]
		);

		$repeater->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'indostio' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter title text', 'indostio' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'description', [
				'label' => esc_html__( 'Description', 'indostio' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
			]
		);


		$repeater->add_control(
			'link',
			[
				'label' => __( 'Link', 'indostio' ),
				'type' => Controls_Manager::URL,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => '#',
				],
			]
		);

		// Socials
		$repeater->add_control(
			'socials_toggle',
			[
				'label' => __( 'Socials', 'indostio' ),
				'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
				'label_off' => __( 'Default', 'indostio' ),
				'label_on' => __( 'Custom', 'indostio' ),
				'return_value' => 'yes',
				'separator' => 'before',
			]
		);

		$repeater->start_popover();

		$socials = $this->get_social_icons();

		foreach( $socials as $key => $social ) {
			$repeater->add_control(
				$key,
				[
					'label'       => $social['label'],
					'type'        => Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'indostio' ),
					'default'     => [
						'url' => '',
					],
				]
			);
		}

		$repeater->end_popover();

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Items', 'indostio' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
				'default' => [
					[
						'title'   		=> esc_html__( 'Item #1', 'indostio' ),
						'description'   => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
						'image'   		=> ['url' => INDOSTIO_ADDONS_URL . '/assets/images/person.jpg'],
						'link'    		=> ['url' => '#'],
					],
					[
						'title'   		=> esc_html__( 'Item #2', 'indostio' ),
						'description'   => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
						'image'   		=> ['url' => INDOSTIO_ADDONS_URL . '/assets/images/person.jpg'],
						'link'    		=> ['url' => '#'],
					],
					[
						'title'   		=> esc_html__( 'Item #3', 'indostio' ),
						'description'   => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
						'image'   		=> ['url' => INDOSTIO_ADDONS_URL . '/assets/images/person.jpg'],
						'link'    		=> ['url' => '#'],
					],
					[
						'title'   		=> esc_html__( 'Item #4', 'indostio' ),
						'description'   => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
						'image'   		=> ['url' => INDOSTIO_ADDONS_URL . '/assets/images/person.jpg'],
						'link'    		=> ['url' => '#'],
					],
				],
			]
		);

		$this->add_responsive_control(
			'columns',
			[
				'label'              => esc_html__( 'Columns', 'indostio' ),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 1,
				'max'                => 6,
				'default'            => 3,
				'tablet_default' => 2,
				'mobile_default' => 1,
				'separator'          => 'after',
				'selectors' => [
					'{{WRAPPER}} .indostio-team-member-grid__item' => 'max-width: calc( 100% / {{VALUE}} ); flex: 0 0 calc( 100% / {{VALUE}} );',
				],
			]
		);

		$this->end_controls_section();

		// Style
		$this->start_controls_section(
			'section_style',
			[
				'label'     => __( 'Content', 'indostio' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_control(
			'item_style_heading',
			[
				'label' => __( 'Item', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'column_gap',
			[
				'label' => esc_html__( 'Columns Gap', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 300,
					],
				],
				'default' => [],
				'selectors' => [
					'{{WRAPPER}} .indostio-team-member-grid__item' => 'padding-left: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .indostio-team-member-grid__wrapper' => 'margin-left: -{{SIZE}}{{UNIT}}; margin-right: -{{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'row_gap',
			[
				'label' => esc_html__( 'Rows Gap', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [],
				'selectors' => [
					'{{WRAPPER}} .indostio-team-member-grid__item' => 'padding-top: {{SIZE}}{{UNIT}}; padding-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .indostio-team-member-grid__wrapper' => 'margin-top: -{{SIZE}}{{UNIT}}; margin-bottom: -{{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'image_heading',
			[
				'label' => __( 'Image', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'image',
				'default'   => 'full',
			]
		);

		$this->add_responsive_control(
			'image_max_width',
			[
				'label' => __( 'Max-width', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-team-member-grid__item img' => 'max-width: {{size}}{{UNIT}} ;',
				],
			]
		);

		$this->add_responsive_control(
			'image_spacing',
			[
				'label' => __( 'Spacing', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-team-member-grid__item img' => 'margin-bottom: {{size}}{{UNIT}} ;',
				],
			]
		);

		$this->add_responsive_control(
			'img_border_radius',
			[
				'label'     => esc_html__( 'Border Radius', '' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .indostio-team-member-grid__item img' => 'border-radius: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'title_heading',
			[
				'label' => __( 'Title', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .indostio-team-member-grid__title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-team-member-grid__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_spacing',
			[
				'label' => __( 'Spacing', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-team-member-grid__title' => 'margin-bottom: {{size}}{{UNIT}} ;',
				],
			]
		);

		$this->add_control(
			'description_heading',
			[
				'label' => __( 'Description', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'selector' => '{{WRAPPER}} .indostio-team-member-grid__description',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-team-member-grid__description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'socials_heading',
			[
				'label' => __( 'Socials', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


		$this->add_control(
			'socials_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-team-member-grid__socials a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render heading widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$content_html = [];
		$count = 1;
		foreach( $settings['items'] as $items ) {
			$settings['image'] = $items['image'];
			
			$class = $count == count($settings['items'] ) ? 'last' : '';
			$icon = '<span class="indostio-svg-icon"><svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.6869 11.8052V12.4819C10.6869 12.9653 11.0253 13.3036 11.5086 13.3036H28.7168L10.5902 31.4301C10.2519 31.7685 10.3002 32.3002 10.5902 32.5902L11.0736 33.0736C11.412 33.412 11.8953 33.412 12.2337 33.0736L30.3602 14.9471L30.4086 32.2035C30.4086 32.6869 30.7469 33.0253 31.2303 33.0253H31.907C32.3904 33.0253 32.7288 32.6869 32.7288 32.2035V11.8052C32.7288 11.3218 32.3904 10.9834 31.907 10.9834H11.5086C11.0253 10.9834 10.6869 11.3218 10.6869 11.8052Z" fill="currentColor"/></svg></span>';
			if ( ! empty( $items['link']['url'] ) ) {
				$title = '<a href=' . $items['link']['url'] . '>' . $items['title'] . '</a>';
				$image = '<a href=' . $items['link']['url'] . ' class="indostio-team-member-grid__image">' . Group_Control_Image_Size::get_attachment_image_html( $settings ) . '</a>';
				$icon = '<a href=' . $items['link']['url'] . ' class="indostio-team-member-grid__icon">' . $icon . '</a>';
			} else{
				$title = $items['title'];
				$image = Group_Control_Image_Size::get_attachment_image_html( $settings );
			}

			$socials = $this->get_social_icons();
			$socials_html = array();

			foreach( $socials as $key => $social ) {
				if ( empty( $items[ $key ]['url'] ) ) {
					continue;
				}

				$link_key = $this->get_repeater_setting_key( 'link', 'social', $key );
				$this->add_link_attributes( $link_key, $items[ $key ] );
				$this->add_render_attribute( $link_key, 'title', $social['name'] );

				$socials_html[] = sprintf(
					'<a %s>%s</a>',
					$this->get_render_attribute_string( $link_key ),
					Helper::get_svg( $social['name'], '', 'social' )
				);
			}

			$content_html[] = '<div class="indostio-team-member-grid__item indostio-team-member-grid__item--' . $items['_id'] . '' . esc_attr( $class ) . '">';
			$content_html[] = '<div class="indostio-team-member-grid__inner">';
			$content_html[] = $image;
			$content_html[] = '<div class="indostio-team-member-grid__content">';
			$content_html[] = '<span class="indostio-line-icon"><svg width="65" height="6" viewBox="0 0 65 6" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M56.1621 5.5878C53.8215 5.5878 52.6293 4.49669 51.5774 3.53399C50.6277 2.6646 49.8774 1.97789 48.2742 1.97789C46.671 1.97789 45.9207 2.6646 44.9708 3.53399C43.919 4.49669 42.7269 5.5878 40.3861 5.5878C38.0454 5.5878 36.8534 4.49669 35.8015 3.53399C34.8518 2.6646 34.1017 1.97789 32.4984 1.97789C30.8953 1.97789 30.1452 2.6646 29.1955 3.53399C28.1437 4.49669 26.9516 5.5878 24.6109 5.5878C22.2705 5.5878 21.0786 4.49669 20.0269 3.53399C19.0773 2.6646 18.3271 1.97789 16.7242 1.97789C15.1212 1.97789 14.371 2.6646 13.4213 3.53399C12.3696 4.49669 11.1774 5.5878 8.83682 5.5878C6.49611 5.5878 5.30393 4.49669 4.25203 3.53399C3.3023 2.6646 2.55217 1.97789 0.948937 1.97789C0.424966 1.97789 0 1.55308 0 1.02895C0 0.504983 0.424966 0.0800171 0.948937 0.0800171C3.28949 0.0800171 4.48167 1.17114 5.53357 2.13383C6.4833 3.00322 7.23359 3.68993 8.83682 3.68993C10.4399 3.68993 11.19 3.00322 12.1398 2.13399C13.1915 1.17114 14.3837 0.0800171 16.7242 0.0800171C19.0646 0.0800171 20.2567 1.17129 21.3084 2.13399C22.258 3.00338 23.0079 3.68993 24.6109 3.68993C26.2141 3.68993 26.9642 3.00322 27.9139 2.13399C28.9657 1.17114 30.1579 0.0800171 32.4984 0.0800171C34.8391 0.0800171 36.0312 1.17114 37.0831 2.13399C38.0328 3.00322 38.7831 3.68993 40.3861 3.68993C41.9895 3.68993 42.7397 3.00322 43.6894 2.13399C44.7413 1.17114 45.9335 0.0800171 48.2742 0.0800171C50.6149 0.0800171 51.8071 1.17114 52.859 2.13399C53.8087 3.00322 54.5588 3.68993 56.1621 3.68993C57.7656 3.68993 58.5159 3.00322 59.466 2.13383C60.5179 1.17114 61.7102 0.0800171 64.0511 0.0800171C64.575 0.0800171 65 0.504983 65 1.02895C65 1.55308 64.575 1.97789 64.0511 1.97789C62.4475 1.97789 61.6972 2.6646 60.7472 3.53399C59.6953 4.49669 58.5031 5.5878 56.1621 5.5878Z" fill="currentColor"/></svg></span>';
			$content_html[] = ! empty( $items['title'] ) ? '<div class="indostio-team-member-grid__title">' . $title . '</div>' : '';
			$content_html[] = ! empty( $items['description'] ) ? '<div class="indostio-team-member-grid__description">' . $items['description'] . '</div>' : '';
			$content_html[] = $items['socials_toggle'] ? '<div class="indostio-team-member-grid__socials">' . implode( '', $socials_html ) . '</div>' : '';
			$content_html[] = '</div>';
			$content_html[] = $icon;
			$content_html[] = '</div>';
			$content_html[] = '</div>';

			$count++;
		}

		echo sprintf( '<div class="indostio-team-member-grid__wrapper">%s</div>',
			implode( '', $content_html ),
		);
	}
}