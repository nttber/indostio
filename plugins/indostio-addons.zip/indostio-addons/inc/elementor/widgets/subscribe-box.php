<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor heading widget.
 *
 * Elementor widget that displays an eye-catching headlines.
 *
 * @since 1.0.0
 */
class Subscribe_Box extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-subscribe-box';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Indostio] Subscribe Box', 'indostio' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return ['indostio'];
	}

	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'subscribe box', 'form', 'indostio' ];
	}

	/**
	 * Register the widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		// Content
		$this->start_controls_section(
			'section_subscribe_box',
			[ 'label' => __( 'Subscribe Box', 'indostio' ) ]
		);

		$this->add_control(
			'type',
			[
				'label' => esc_html__( 'Type', 'indostio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'mailchimp'  => esc_html__( 'Mailchimp', 'indostio' ),
					'shortcode' => esc_html__( 'Use Shortcode', 'indostio' ),
				],
				'default' => 'mailchimp',
			]
		);

		$this->add_control(
			'form',
			[
				'label'   => esc_html__( 'Mailchimp Form', 'indostio' ),
				'type'    => Controls_Manager::SELECT,
				'options' => $this->get_contact_form(),
				'conditions' => [
					'terms' => [
						[
							'name' => 'type',
							'operator' => '==',
							'value' => 'mailchimp'
						],
					],
				],
			]
		);

		$this->add_control(
			'form_shortcode',
			[
				'label' => __( 'Enter your shortcode', 'indostio' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => '',
				'placeholder' => '[gallery id="123" size="medium"]',
				'conditions' => [
					'terms' => [
						[
							'name' => 'type',
							'operator' => '==',
							'value' => 'shortcode'
						],
					],
				],
			]
		);


		$this->end_controls_section();

		// Style Section
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => __( 'Subscribe Box', 'indostio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'form_height',
			[
				'label' => __( 'Form Height', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} input[type="submit"]' => 'line-height: {{size}}{{UNIT}} ;',
					'{{WRAPPER}} input[type="email"]' => 'line-height: {{size}}{{UNIT}} ;',
					'{{WRAPPER}} input[type="email"]' => 'height: {{size}}{{UNIT}} ;',
					'{{WRAPPER}} input[type="text"]' => 'line-height: {{size}}{{UNIT}} ;',
					'{{WRAPPER}} input[type="text"]' => 'height: {{size}}{{UNIT}} ;',
				],
			]
		);

		$this->add_control(
			'style_button',
			[
				'label' => __( 'Button', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'button_possition',
			[
				'label'      => esc_html__( 'Position', 'indostio' ),
				'type'       => Controls_Manager::SELECT,
				'options'    => [
					'outside'       => esc_html__( 'Outside', 'indostio' ),
					'inside' => esc_html__( 'Inside', 'indostio' ),
				],
				'default'    => 'outside',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'button_typography',
				'selector' => '{{WRAPPER}} input[type="submit"], {{WRAPPER}} button[type="submit"]',
			]
		);

		$this->start_controls_tabs(
			'button_style_tabs'
		);

		$this->start_controls_tab(
			'button_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'indostio' ),
			]
		);

		$this->add_control(
			'button_background_color',
			[
				'label'      => esc_html__( 'Background Color', 'indostio' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} input[type="submit"], {{WRAPPER}} button[type="submit"]' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'button_color',
			[
				'label'      => esc_html__( 'Color', 'indostio' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} input[type="submit"], {{WRAPPER}} button[type="submit"]' => 'color: {{VALUE}}',
				],
			]
		);
	
		$this->end_controls_tab();

		$this->start_controls_tab(
			'button_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'indostio' ),
			]
		);

			$this->add_control(
				'button_hover_background_color',
				[
					'label' => __( 'Background Color', 'indostio' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} input[type="submit"]:hover, {{WRAPPER}} button[type="submit"]:hover' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_hover_color',
				[
					'label' => __( 'Color', 'indostio' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} input[type="submit"]:hover, {{WRAPPER}} button[type="submit"]:hover' => 'color: {{VALUE}};',
					],
				]
			);


		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'style_field',
			[
				'label' => __( 'Field', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'field_spacing',
			[
				'label'      => esc_html__( 'Padding', 'indostio' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .indostio-subscribe-box input[type="email"]' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .indostio-subscribe-box input[type="text"]' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'field_background',
			[
				'label' => __( 'Background Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-subscribe-box input[type="email"]' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .indostio-subscribe-box input[type="text"]' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'field_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-subscribe-box input[type="email"]' => 'color: {{VALUE}};',
					'{{WRAPPER}} .indostio-subscribe-box input[type="email"]::placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .indostio-subscribe-box input[type="text"]' => 'color: {{VALUE}};',
					'{{WRAPPER}} .indostio-subscribe-box input[type="text"]::placeholder' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'field_align',
			[
				'label' => __( 'Alignment', 'indostio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'indostio' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'indostio' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'indostio' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .indostio-subscribe-box .mc4wp-form-fields input' => 'text-align:{{VALUE}}',
				],
			]
		);


		$this->end_controls_section();

	}

	/**
	 * Render widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$classes = [
			'indostio-subscribe-box',
			'indostio-subscribe-box--button-' . $settings['button_possition']
		];

		if( empty( $settings['form'] ) ) {
			return;
		}

		$this->add_render_attribute( 'wrapper', 'class', $classes );

		$output = sprintf(
			'<div class="indostio-subscribe-box__content">%s</div>',
			do_shortcode( '[mc4wp_form id="' . esc_attr( $settings['form'] ) . '"]' ),
		);
		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<?php
			if( $settings['type'] == 'mailchimp' ) {
				echo $output;
			} else {
				echo do_shortcode(  $settings['form_shortcode']  );
			}
			?>
		</div>
		<?php
	}

	/**
	 * Get Contact Form
	 */
	protected function get_contact_form() {
		$mail_forms    = get_posts( 'post_type=mc4wp-form&posts_per_page=-1' );
		$mail_form_ids = array(
			'' => esc_html__( 'Select Form', 'indostio' ),
		);
		foreach ( $mail_forms as $form ) {
			$mail_form_ids[$form->ID] = $form->post_title;
		}

		return $mail_form_ids;
	}
}