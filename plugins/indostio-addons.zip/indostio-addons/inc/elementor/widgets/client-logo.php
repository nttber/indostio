<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Icons_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Clients widget.
 */
class Client_Logo extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-clients';
	}

	/**
	 * Get widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Indostio] Client List', 'indostio' );
	}

	/**
	 * Get widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-image-box';
	}

	/**
	 * Get widget categories
	 *
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return string Widget categories
	 */
	public function get_categories() {
		return [ 'indostio' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'client', 'indostio' ];
	}

	/**
	 * Register accordion widget controls.
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Clients', 'indostio' ),
			]
		);

		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'indostio' ),
				'type' => Controls_Manager::TEXT,
				'default' => '',
			]
		);

		$repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'indostio' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => 'https://via.placeholder.com/100x100/f5f5f5?text=Image',
				],
			]
		);

		$repeater->add_control(
			'image_url',
			[
				'label' => esc_html__( 'URL', 'indostio' ),
				'type' => Controls_Manager::URL,
				'label_block' => true,
			]
		);

		$this->add_control(
			'list',
			[
				'label' => __( 'List', 'indostio' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [],
			]
		);

		$this->add_control(
			'more_url',
			[
				'label' => esc_html__( 'More Link', 'indostio' ),
				'type' => Controls_Manager::URL,
				'label_block' => true,
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_accordion',
			[
				'label' => __( 'Clients', 'indostio' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => __( 'Alignment', 'indostio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => __( 'Left', 'indostio' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'indostio' ),
						'icon' => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'indostio' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .indostio-client__list' => 'justify-content: {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'heading_title',
			[
				'label' => __( 'Title', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'title_align',
			[
				'label' => __( 'Alignment', 'indostio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'indostio' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'indostio' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'indostio' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .indostio-client__title' => 'text-align: {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-accordion__title, {{WRAPPER}} .indostio-accordion__title a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .indostio-accordion__title',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render accordion widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<div class="indostio-client">
			<?php
			if ( ! empty( $settings['title'] ) ) {
				echo '<div class="indostio-client__title">';
				echo $settings['title'];
				echo '</div>';
			}
			if ( ! empty( $settings['list'] ) ) {
				echo '<div class="indostio-client__list">';
				foreach ( $settings['list'] as $index => $item ) :
					echo '<div class="indostio-client__item">';
					if ( ! empty($item['image_url']['url'] ) ) {
						echo \Indostio\Addons\Helper::render_control_link_open( 'btn_full', $item['image_url'],  [] );
					} 
					$item['image_size'] = 'thumbnail';
					echo \Elementor\Group_Control_Image_Size::get_attachment_image_html( $item );
					if ( ! empty($item['image_url']['url'] ) ) {
						echo \Indostio\Addons\Helper::render_control_link_close(  $settings['image_url'] );
					} 
					echo '</div>';
				endforeach;
				if( ! empty($settings['more_url'] ) && ! empty($settings['more_url']['url'] ) ) {
					echo \Indostio\Addons\Helper::render_control_link_open( 'btn_full', $settings['more_url'],  ['class' => 'indostio-client__item indostio-client__more-url'] );
					echo '<span class="indostion-svg-icon"><svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14.375 6.25H8.75V0.625C8.75 0.3125 8.4375 0 8.125 0H6.875C6.52344 0 6.25 0.3125 6.25 0.625V6.25H0.625C0.273438 6.25 0 6.5625 0 6.875V8.125C0 8.47656 0.273438 8.75 0.625 8.75H6.25V14.375C6.25 14.7266 6.52344 15 6.875 15H8.125C8.4375 15 8.75 14.7266 8.75 14.375V8.75H14.375C14.6875 8.75 15 8.47656 15 8.125V6.875C15 6.5625 14.6875 6.25 14.375 6.25Z" fill="currentColor"/></svg></span>';
					echo \Indostio\Addons\Helper::render_control_link_close( $settings['more_url'] );
				}
				echo '</div>';
			}
			?>
		</div>
		<?php
	}
}
