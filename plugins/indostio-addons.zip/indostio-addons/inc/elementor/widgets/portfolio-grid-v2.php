<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Stack;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Indostio\Addons\Helper;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Icon Box widget
 */
class Portfolio_Grid_V2 extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-portfolio-grid-v2';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Indostio] Portfolio Grid V2', 'indostio' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return ['indostio'];
	}

	public function get_script_depends() {
		return [
			'indostio-frontend'
		];
	}

	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'portfolio grid', 'portfolio', 'grid', 'indostio' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_portfolio_grid',
			[ 'label' => __( 'Portfolio Grid', 'indostio' ) ]
		);

		$this->add_control(
			'limit',
			[
				'label'     => __( 'Total', 'indostio' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => -1,
				'max'       => 100,
				'step'      => 1,
				'default'   => 12,
			]
		);

		$this->add_responsive_control(
			'columns',
			[
				'label'              => esc_html__( 'Columns', 'indostio' ),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 1,
				'max'                => 6,
				'step'				 => 1,
				'default'            => 3,
				'tablet_default' => 2,
				'mobile_default' => 1,
				'separator'          => 'after',
				'selectors' => [
					'{{WRAPPER}} .indostio-portfolio-grid-v2__item' => 'max-width: calc( 100% / {{VALUE}} ); flex: 0 0 calc( 100% / {{VALUE}} );',
				],
			]
		);

		$this->add_control(
			'category',
			[
				'label'    => __( 'Category', 'indostio' ),
				'type'     => Controls_Manager::SELECT2,
				'options'  => \Indostio\Addons\Elementor\Utils::get_terms_options('indostio_portfolio_cat'),
				'default'  => '',
				'multiple' => true,
			]
		);

		$this->add_control(
			'orderby',
			[
				'label'      => esc_html__( 'Order By', 'indostio' ),
				'type'       => Controls_Manager::SELECT,
				'options'    => [
					'date'       => esc_html__( 'Date', 'indostio' ),
					'name'       => esc_html__( 'Name', 'indostio' ),
					'id'         => esc_html__( 'Ids', 'indostio' ),
					'rand' 		=> esc_html__( 'Random', 'indostio' ),
				],
				'default'    => 'date',
			]
		);

		$this->add_control(
			'order',
			[
				'label'      => esc_html__( 'Order', 'indostio' ),
				'type'       => Controls_Manager::SELECT,
				'options'    => [
					''     => esc_html__( 'Default', 'indostio' ),
					'ASC'  => esc_html__( 'Ascending', 'indostio' ),
					'DESC' => esc_html__( 'Descending', 'indostio' ),
				],
				'default'    => '',
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'image',
				'default'   => 'full',
				'separator' => 'before',
			]
		);


		$this->end_controls_section();

		// Style before Title
		$this->start_controls_section(
			'section_style_content',
			[
				'label'     => __( 'Content', 'indostio' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_control(
			'number_heading',
			[
				'label'     => esc_html__( 'Number', 'indostio' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'number_typography',
				'selector' => '{{WRAPPER}} .indostio-portfolio-grid-v2__number',
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$classes = [
			'indostio-portfolio-grid-v2'
		];

		$this->add_render_attribute( 'wrapper', 'class', $classes );

		$output = array();
		$cate_filter = '';

		$args = array(
			'post_type'              => 'indostio_portfolio',
			'posts_per_page'         => $settings['limit'],
			'orderby'     			 => $settings['orderby'],
			'ignore_sticky_post'    => 1,
			'suppress_filters'       => false,
		
		);

		if ($settings['order'] != ''){
			$args['order'] = $settings['order'];
		}
		if ( $settings['category'] ) {
			$args['tax_query'] = array( 
				array(
				'taxonomy' => 'indostio_portfolio_cat',
				'field' => 'slug',
				'terms' => $settings['category'],
				'include_children' => false,
				) 
			);
		}

		$portfolio = new \WP_Query( $args );

		if ( ! $portfolio->have_posts() ) {
			return '';
		}

		$index = 1;
		$cats = array();
		echo sprintf('<div %s>', $this->get_render_attribute_string( 'wrapper' ));
		while ( $portfolio->have_posts() ) : $portfolio->the_post();
			$portfolio_url = array();

			$image = '';

			$portfolio_url['url'] = esc_url(get_permalink());
			$portfolio_url['is_external'] = $portfolio_url['nofollow'] = '';

			$key_img = 'img_'.$index;

			$portfolio_thumbnail_id = get_post_thumbnail_id( get_the_ID() );

			if ( $portfolio_thumbnail_id ) {

				$image_src = wp_get_attachment_image_src( $portfolio_thumbnail_id );

				$settings['image'] = array(
					'url' => $image_src ? $image_src[0] : '',
					'id'  => $portfolio_thumbnail_id
				);

				$image = Group_Control_Image_Size::get_attachment_image_html( $settings );
			}
			$post_categories = wp_get_post_terms(get_the_ID(), 'indostio_portfolio_cat');
			$number = '0' . $index;
			?>
			<div  class="indostio-portfolio-grid-v2__item">
				<div class="indostio-portfolio-grid-v2__image"><?php echo $image;?></div>
				<div class="indostio-portfolio-grid-v2__number"><?php echo $number; ?></div>
				<div class="indostio-portfolio-grid-v2__content">
					<?php
					if ( ! is_wp_error( $post_categories ) &&  $post_categories ) {
						echo sprintf('<a href="%s" class="indostio-portfolio-grid-v2__cat">%s</a>', esc_url(get_term_link($post_categories[0]->term_id, 'indostio_portfolio_cat')), $post_categories[0]->name);
					}
					?>
					<a href="<?php echo esc_url( get_permalink() );?>" class="indostio-portfolio-grid-v2__title"><?php echo get_the_title(); ?></a>
					<a href="<?php echo esc_url( get_permalink() );?>" class="indostio-portfolio-grid-v2__button">
						<?php esc_html_e( 'Read More', 'indostio' ); ?>
						<?php echo \Indostio\Addons\Helper::get_svg( 'arrow' ); ?>
					</a>
				</div>
				<a href="<?php echo esc_url( get_permalink() );?>" class="indostio-portfolio-grid-v2__link"></a>
			</div>
		<?php
		$index ++;
		endwhile;

		wp_reset_postdata();
		echo '</div>';
	}
	
}