<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Stack;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Indostio\Addons\Helper;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Icon Box widget
 */
class Portfolio_Carousel_V2 extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-portfolio_carousel_v2';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Indostio] Portfolio Carousel V2', 'indostio' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-carousel';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return ['indostio'];
	}

	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'portfolio carousel', 'portfolio', 'carousel', 'indostio' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_portfolio_carousel',
			[ 'label' => __( 'Portfolio Carousel', 'indostio' ) ]
		);

		$this->add_control(
			'limit',
			[
				'label'     => __( 'Total', 'indostio' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => -1,
				'max'       => 100,
				'step'      => 1,
				'default'   => 12,
			]
		);

		$this->add_control(
			'category',
			[
				'label'    => __( 'Category', 'indostio' ),
				'type'     => Controls_Manager::SELECT2,
				'options'  => \Indostio\Addons\Elementor\Utils::get_terms_options('indostio_portfolio_cat'),
				'default'  => '',
				'multiple' => true,
			]
		);

		$this->add_control(
			'orderby',
			[
				'label'      => esc_html__( 'Order By', 'indostio' ),
				'type'       => Controls_Manager::SELECT,
				'options'    => [
					'date'       => esc_html__( 'Date', 'indostio' ),
					'name'       => esc_html__( 'Name', 'indostio' ),
					'id'         => esc_html__( 'Ids', 'indostio' ),
					'rand' 		=> esc_html__( 'Random', 'indostio' ),
				],
				'default'    => 'date',
			]
		);

		$this->add_control(
			'order',
			[
				'label'      => esc_html__( 'Order', 'indostio' ),
				'type'       => Controls_Manager::SELECT,
				'options'    => [
					''     => esc_html__( 'Default', 'indostio' ),
					'ASC'  => esc_html__( 'Ascending', 'indostio' ),
					'DESC' => esc_html__( 'Descending', 'indostio' ),
				],
				'default'    => '',
			]
		);


		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'image',
				'default'   => 'full',
				'separator' => 'before',
			]
		);


		$this->end_controls_section();

		$this->section_carousel();

	}

	protected function section_carousel() {
		$this->start_controls_section(
			'section_products_carousel',
			[
				'label' => __( 'Carousel Settings', 'indostio' ),
			]
		);

		$this->add_responsive_control(
			'slides_to_show',
			[
				'label'              => esc_html__( 'Slides to show', 'indostio' ),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 1,
				'max'                => 10,
				'default'            => 1,
				'frontend_available' => true,
				'separator'          => 'before',
			]
		);

		$this->add_responsive_control(
			'slides_to_scroll',
			[
				'label'              => esc_html__( 'Slides to scroll', 'indostio' ),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 1,
				'max'                => 10,
				'default'            => 1,
				'frontend_available' => true,
			]
		);

		$this->add_responsive_control(
			'navigation',
			[
				'label'   => esc_html__( 'Navigation', 'indostio' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'dots'             => esc_html__( 'Dots', 'indostio' ),
					'none'             => esc_html__( 'None', 'indostio' ),
				],
				'default'            => 'dots',
				'toggle'             => false,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'     => __( 'Autoplay', 'indostio' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'indostio' ),
				'label_on'  => __( 'On', 'indostio' ),
				'default'   => 'yes',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'autoplay_speed',
			[
				'label'   => __( 'Autoplay Speed', 'indostio' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3000,
				'min'     => 100,
				'step'    => 100,
				'frontend_available' => true,
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'pause_on_hover',
			[
				'label'   => __( 'Pause on Hover', 'indostio' ),
				'type'    => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'indostio' ),
				'label_on'  => __( 'On', 'indostio' ),
				'default'   => 'yes',
				'frontend_available' => true,
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'speed',
			[
				'label'       => __( 'Animation Speed', 'indostio' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 800,
				'min'         => 100,
				'step'        => 50,
				'frontend_available' => true,
			]
		);

		$this->end_controls_section();
		$this->section_style_carousel();
	}

	protected function section_style_carousel() {
		$this->start_controls_section(
			'section_style_carousel',
			[
				'label'     => __( 'Portfolo Carousel', 'indostio' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);



		// Dots
		$this->add_control(
			'dots_style_heading',
			[
				'label' => esc_html__( 'Dots', 'indostio' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'sliders_dots_style',
			[
				'label'        => __( 'Option', 'indostio' ),
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'label_off'    => __( 'Default', 'indostio' ),
				'label_on'     => __( 'Custom', 'indostio' ),
				'return_value' => 'yes',
			]
		);

		$this->start_popover();

		$this->add_responsive_control(
			'sliders_dots_gap',
			[
				'label'     => __( 'Gap', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 50,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-portfolio_carousel_v2 .swiper-pagination-bullet' => 'margin: 0 {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'sliders_dots_size',
			[
				'label'     => __( 'Size', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-portfolio_carousel_v2 .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'sliders_dot_item_color',
			[
				'label'     => esc_html__( 'Color', 'indostio' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullet' => 'background-color : {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'sliders_dot_item_active_color',
			[
				'label'     => esc_html__( 'Color Active', 'indostio' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullet-active' => 'background-color : {{VALUE}};',
					'{{WRAPPER}}  .swiper-pagination-bullet:hover' => 'background-color : {{VALUE}};',
				],
			]
		);

		$this->end_popover();

		$this->add_responsive_control(
			'sliders_dots_vertical_spacing',
			[
				'label'     => esc_html__( 'Spacing', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 1000,
						'min' => 0,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination' => 'margin-top: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->end_controls_section();
	}


	/**
	 * Render widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$nav        = $settings['navigation'];
		$nav_tablet = empty( $settings['navigation_tablet'] ) ? $nav : $settings['navigation_tablet'];
		$nav_mobile = empty( $settings['navigation_mobile'] ) ? $nav : $settings['navigation_mobile'];

		$classes = [
			'indostio-portfolio_carousel_v2',
			'indostio-carousel--elementor',
			'indostio-swiper-carousel-elementor',
			'indostio-carousel--swiper',
			'navigation-' . $nav,
			'navigation-tablet-' . $nav_tablet,
			'navigation-mobile-' . $nav_mobile
		];

		$this->add_render_attribute( 'wrapper', 'class', $classes );

		$output = array();
		$cate_filter = '';

		$args = array(
			'post_type'              => 'indostio_portfolio',
			'posts_per_page'         => $settings['limit'],
			'orderby'     			 => $settings['orderby'],
			'ignore_sticky_post'    => 1,
			'suppress_filters'       => false,
		
		);

		if ($settings['order'] != ''){
			$args['order'] = $settings['order'];
		}
		if ( $settings['category'] ) {
			$args['tax_query'] = array( 
				array(
				'taxonomy' => 'indostio_portfolio_cat',
				'field' => 'slug',
				'terms' => $settings['category'],
				'include_children' => false,
				) 
			);
		}

		$portfolio = new \WP_Query( $args );

		if ( ! $portfolio->have_posts() ) {
			return '';
		}

		$index = 0;
		while ( $portfolio->have_posts() ) : $portfolio->the_post();
			$portfolio_url = array();

			$image = '';

			$portfolio_url['url'] = esc_url(get_permalink());
			$portfolio_url['is_external'] = $portfolio_url['nofollow'] = '';

			$key_img = 'img_'.$index;

			$portfolio_thumbnail_id = get_post_thumbnail_id( get_the_ID() );

			if ( $portfolio_thumbnail_id ) {

				$image_src = wp_get_attachment_image_src( $portfolio_thumbnail_id );

				$settings['image'] = array(
					'url' => $image_src ? $image_src[0] : '',
					'id'  => $portfolio_thumbnail_id
				);

				$image = Group_Control_Image_Size::get_attachment_image_html( $settings );
			}

			$post_categories = wp_get_post_terms(get_the_ID(), 'indostio_portfolio_cat');
			$cat_html = '';
			if ( ! is_wp_error( $post_categories ) &&  $post_categories ) {
				$cat_html .= sprintf('<a href="%s" class="indostio-portfolio_carousel_v2__cat">%s</a>', esc_url(get_term_link($post_categories[0]->term_id, 'indostio_portfolio_cat')), $post_categories[0]->name);
			}

			$output[] = sprintf(
				'<div class="indostio-portfolio_carousel_v2__item swiper-slide">
					<a href="%s" class="indostio-portfolio_carousel_v2__image">%s</a>
					<div class="indostio-portfolio_carousel_v2__item-content">
						%s
						<a href="%s" class="indostio-portfolio_carousel_v2__title">%s</a>
						<span class="indostio-portfolio_carousel_v2__desc">%s</span>
					</div>
				</div>',
				esc_url( get_permalink() ),
				$image,
				$cat_html,
				esc_url( get_permalink() ),
				get_the_title(),
				get_the_excerpt()
			);

		$index ++;
		endwhile;

		wp_reset_postdata();
		echo sprintf(
			'<div %s>
				<div class="indostio-portfolio_carousel_v2__list swiper-container">
					<div class="indostio-portfolio_carousel_v2__wrapper swiper-wrapper">
					%s
					</div>
					<div class="swiper-pagination"></div>
				</div>
			</div>',
			$this->get_render_attribute_string( 'wrapper' ),
			implode( '', $output )
		);

	}
}