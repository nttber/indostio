<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Indostio\Addons\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Icon Box widget
 */
class Posts_Grid extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-posts-grid';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Indostio] Posts Grid', 'indostio' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return ['indostio'];
	}

	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'post grid', 'post', 'grid', 'indostio' ];
	}

	/**
	 * Register heading widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->section_content();
		$this->section_style();
	}

	// Tab Content
	protected function section_content() {
		$this->start_controls_section(
			'section_posts_Grid',
			[ 'label' => __( 'Posts Grid', 'indostio' ) ]
		);


		$this->add_control(
			'limit',
			[
				'label'     => __( 'Total', 'indostio' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => -1,
				'max'       => 100,
				'step'      => 1,
				'default'   => 6,
			]
		);

		$this->add_responsive_control(
			'columns',
			[
				'label'              => esc_html__( 'Columns', 'indostio' ),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 1,
				'max'                => 6,
				'step'				 => 1,
				'default'            => 3,
				'tablet_default' => 2,
				'mobile_default' => 1,
				'separator'          => 'after',
				'selectors' => [
					'{{WRAPPER}} .indostio-post-grid__item' => 'max-width: calc( 100% / {{VALUE}} ); flex: 0 0 calc( 100% / {{VALUE}} );',
				],
			]
		);

		$this->add_control(
			'category',
			[
				'label'    => __( 'Category', 'indostio' ),
				'type'     => Controls_Manager::SELECT2,
				'options'  => \Indostio\Addons\Elementor\Utils::get_terms_options(),
				'default'  => '',
				'multiple' => true,
			]
		);

		$this->add_control(
			'orderby',
			[
				'label'      => esc_html__( 'Order By', 'indostio' ),
				'type'       => Controls_Manager::SELECT,
				'options'    => [
					'date'       => esc_html__( 'Date', 'indostio' ),
					'name'       => esc_html__( 'Name', 'indostio' ),
					'id'         => esc_html__( 'Ids', 'indostio' ),
					'rand' 		=> esc_html__( 'Random', 'indostio' ),
				],
				'default'    => 'date',
			]
		);

		$this->add_control(
			'order',
			[
				'label'      => esc_html__( 'Order', 'indostio' ),
				'type'       => Controls_Manager::SELECT,
				'options'    => [
					''     => esc_html__( 'Default', 'indostio' ),
					'ASC'  => esc_html__( 'Ascending', 'indostio' ),
					'DESC' => esc_html__( 'Descending', 'indostio' ),
				],
				'default'    => '',
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'image',
				'default'   => 'full',
				'separator' => 'before',
			]
		);


		$this->end_controls_section();

	}

	// Tab Style
	protected function section_style() {
		// Style
		$this->start_controls_section(
			'section_style_posts_grid',
			[
				'label' => __( 'Posts Grid', 'indostio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'title_height',
			[
				'label' => __( 'Title Height', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'default' => [],
				'selectors' => [
					'{{WRAPPER}} .indostio-post-grid .entry-title' => 'height: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->end_controls_section();


	}

	/**
	 * Render widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$classes = [
			'indostio-post-grid',
		];

		$this->add_render_attribute( 'wrapper', 'class', $classes );

		$output = array();

		$args = array(
			'post_type'              => 'post',
			'posts_per_page'         => $settings['limit'],
			'orderby'     			 => $settings['orderby'],
			'ignore_sticky_posts'    => 1,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'suppress_filters'       => false,
		);

		if ($settings['order'] != ''){
			$args['order'] = $settings['order'];
		}

		if ( $settings['category'] ) {
			$args['category_name'] = trim( $settings['category'] );
		}

		$posts = new \WP_Query( $args );

		if ( ! $posts->have_posts() ) {
			return '';
		}

		$index = 0;

		while ( $posts->have_posts() ) : $posts->the_post();
			$post_url = array();

			$image = '';

			$post_url['url'] = esc_url(get_permalink());
			$post_url['is_external'] = $post_url['nofollow'] = '';

			$key_img = 'img_'.$index;

			$post_thumbnail_id = get_post_thumbnail_id( get_the_ID() );

			if ( $post_thumbnail_id ) {

				$image_src = wp_get_attachment_image_src( $post_thumbnail_id );

				$settings['image'] = array(
					'url' => $image_src ? $image_src[0] : '',
					'id'  => $post_thumbnail_id
				);

				$image = Helper::control_url( $key_img, $post_url, Group_Control_Image_Size::get_attachment_image_html( $settings ), ['class' => 'post-thumbnail'] );
			}

			$output[] = sprintf(
				'<div class="indostio-post-grid__item">
					%s
					<div class="entry-summary">
						<div class="entry-category">%s</div>
						<div class="entry-title"><a href="%s" rel="bookmark">%s</a></div>
						<div class="entry-meta">
							<div class="entry-meta__date">%s %s</div>
							<a href="%s" class="entry-button">%s%s</a>
						</div>
					</div>
				</div>',
				$image,
				get_the_category_list(', ' ),
				esc_url( get_permalink() ),
				get_the_title(),
				\Indostio\Addons\Helper::get_svg('calendar'),
				get_the_date(),
				esc_url( get_permalink() ),
				esc_html__('Read More', 'indostio'),
				\Indostio\Addons\Helper::get_svg('button-arrow')
			);

		$index ++;
		endwhile;

		wp_reset_postdata();

		echo sprintf(
			'<div %s>
				%s
			</div>',
			$this->get_render_attribute_string( 'wrapper' ),
			implode( '', $output ),
		);
	}
}