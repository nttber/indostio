<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Controls_Stack ;
use Elementor\Group_Control_Border ;
use Indostio\Addons\Helper;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Icon Box widget
 */
class Info_Box extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-info-box';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Indostio] Info Box', 'indostio' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-info-box';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return ['indostio'];
	}

	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
   	public function get_keywords() {
	   return [ 'icon box', 'icon', 'box', 'indostio' ];
   	}

	/**
	 * Register the widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->content_sections();
		$this->style_sections();
	}

	protected function content_sections() {
		$this->start_controls_section(
			'section_icon',
			[ 'label' => __( 'Info Box', 'indostio' ) ]
		);


		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'indostio' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'This is the heading', 'indostio' ),
				'placeholder' => __( 'Enter your title', 'indostio' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'description',
			[
				'label' => __( 'Description', 'indostio' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'indostio' ),
				'placeholder' => __( 'Enter your description', 'indostio' ),
				'rows' => 10,
				'separator' => 'none',
			]
		);

		$this->add_control(
			'email',
			[
				'label' => __( 'Email', 'indostio' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => 'support@gmail.com',
				'rows' => 2,
			]
		);

		$this->add_control(
			'phone',
			[
				'label' => __( 'Phone', 'indostio' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => '+000 (123) 456 88',
				'rows' => 2,
			]
		);

		$this->end_controls_section();
	}

	protected function style_sections() {
		$this->content_style_sections();
	}

	protected function content_style_sections() {
		// Content style
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => __( 'Content', 'indostio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_style_heading',
			[
				'label' => __( 'Title', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-info-box__title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .indostio-info-box__title',
			]
		);

		$this->add_responsive_control(
			'title_spacing',
			[
				'label' => __( 'Spacing', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					]
				],
				'default' => [],
				'selectors' => [
					'{{WRAPPER}} .indostio-info-box__title' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'description_style_heading',
			[
				'label' => __( 'Description', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-info-box__content' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .indostio-info-box__content',
			]
		);

		
		$this->add_control(
			'email_style_heading',
			[
				'label' => __( 'Email', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'email_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-info-box__email' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'email_typography',
				'selector' => '{{WRAPPER}} .indostio-info-box__email',
			]
		);

		$this->add_control(
			'phone_style_heading',
			[
				'label' => __( 'Phone', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'phone_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-info-box__phone' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'phone_typography',
				'selector' => '{{WRAPPER}} .indostio-info-box__phone',
			]
		);


		$this->end_controls_section();
	}

	/**
	 * Render icon box widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'wrapper', 'class', ['indostio-info-box'] );
		$this->add_render_attribute( 'content_wrapper', 'class', 'indostio-info-box__wrapper' );
		$this->add_render_attribute( 'title', 'class', 'indostio-info-box__title' );
		$this->add_render_attribute( 'description', 'class', 'indostio-info-box__content' );
		$this->add_render_attribute( 'email', 'class', 'indostio-info-box__email' );
		$this->add_render_attribute( 'phone', 'class', 'indostio-info-box__phone' );

		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<div <?php echo $this->get_render_attribute_string( 'content_wrapper' ); ?>>
				<?php if( ! empty( $settings['title'] ) ) : ?>
					<div <?php echo $this->get_render_attribute_string( 'title' ); ?>>
					<?php echo esc_html( $settings['title'] ) ?>
					</div>
				<?php endif; ?>
				<?php if( ! empty( $settings['description'] ) ) : ?>
					<div <?php echo $this->get_render_attribute_string( 'description' ); ?>><?php echo wp_kses_post( $settings['description'] ) ?></div>
				<?php endif; ?>
				<?php if( ! empty( $settings['email'] ) ) : ?>
					<div <?php echo $this->get_render_attribute_string( 'email' ); ?>><?php echo wp_kses_post( $settings['email'] ) ?></div>
				<?php endif; ?>
				<?php if( ! empty( $settings['phone'] ) ) : ?>
					<div <?php echo $this->get_render_attribute_string( 'phone' ); ?>>
					<span class="indostio-svg-icon"><svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.0547 1.50293L9.61719 0.94043C9.35938 0.870117 9.07812 1.01074 8.96094 1.26855L7.83594 3.89355C7.74219 4.12793 7.8125 4.38574 8 4.5498L9.42969 5.72168C8.58594 7.50293 7.10938 9.00293 5.28125 9.87012L4.10938 8.44043C3.94531 8.25293 3.6875 8.18262 3.45312 8.27637L0.828125 9.40137C0.570312 9.51855 0.453125 9.7998 0.5 10.0576L1.0625 12.4951C1.13281 12.7529 1.34375 12.917 1.625 12.917C7.625 12.917 12.5 8.06543 12.5 2.04199C12.5 1.78418 12.3125 1.57324 12.0547 1.50293Z" fill="currentColor"/></svg></span>
					<?php echo wp_kses_post( $settings['phone'] ) ?>
				</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}