<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Conditions;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Controls_Stack;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Icon Box widget
 */
class Sidebar_Menu extends Widget_Base {
/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-sidebar-menu';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Indostio] Sidebar Menu', 'indostio' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-nav-menu';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return ['indostio'];
	}

	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
   	public function get_keywords() {
	   return [ 'sidebar-menu', 'menu', 'indostio' ];
   	}

	/**
	 * Register the widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */

	protected function register_controls() {
		$this->content_sections();
		$this->style_sections();
	}

	protected function content_sections() {
		$this->start_controls_section(
			'section_navigation_menu',
			[ 'label' => __( 'Sidebar Menu', 'indostio' ) ]
		);

		$this->add_control(
			'icon',
			[
				'label' => __( 'Icon', 'indostio' ),
				'type' => Controls_Manager::ICONS,
				'default' => [],
			]
		);

		$this->add_control(
			'menu_type',
			[
				'label' => __( 'Type', 'indostio' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'wordpress',
				'options' => [
					'wordpress'  => esc_html__( 'WordPress Menu', 'indostio' ),
					'custom' => esc_html__( 'Custom', 'indostio' ),
				],
			]
		);

		$this->add_control(
			'list_menu',
			[
				'label' => __( 'Select Menu', 'indostio' ),
				'type' => Controls_Manager::SELECT,
				'options' => \Indostio\Addons\Helper::get_navigation_bar_get_menus(),
				'condition' => [
					'menu_type' => 'wordpress',
				],
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title_menu',
			[
				'label'   => esc_html__( 'Text', 'indostio' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Menu item', 'indostio' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'link_menu', [
				'label'         => esc_html__( 'Link', 'indostio' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'indostio' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'menu_items',
			[
				'label'         => esc_html__( 'Menu Items', 'indostio' ),
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'default'       => [
					[
						'title_menu' => esc_html__( 'Menu item 1', 'indostio' ),
						'link_menu' => '#',
					],
					[
						'title_menu' => esc_html__( 'Menu item 2', 'indostio' ),
						'link_menu' => '#',
					],
					[
						'title_menu' => esc_html__( 'Menu item 3', 'indostio' ),
						'link_menu' => '#',
					],
				],
				'prevent_empty' => false,
				'condition' => [
					'menu_type' => 'custom',
				],
				'title_field'   => '{{{ title_menu }}}',
			]
		);


		$this->end_controls_section();
	}

	protected function style_sections(){
		$this->start_controls_section(
			'style_navigation_menu',
			[
				'label'     => __( 'Navigation Menu', 'indostio' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label' => __( 'Size', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					]
				],
				'default' => [],
				'selectors' => [
					'{{WRAPPER}} .indostio-sidebar--icon' => 'font-size: {{SIZE}}{{UNIT}}',
				],
			]
		);


		$this->add_control(
			'icon_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-sidebar--icon' => 'color: {{VALUE}}',
				],
			]
		);


		$this->add_control(
			'style_menu',
			[
				'label' => __( 'Menu Item', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography_menu',
				'selector' => '{{WRAPPER}} .indostio-sidebar__menu li a',
			]
		);
		
		$this->add_control(
			'menu_item_padding',
			[
				'label'      => esc_html__( 'Menu Item Padding', 'indostio' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors'  => [
					'{{WRAPPER}} .indostio-sidebar__menu li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);

		$this->start_controls_tabs('style_button_tabs');

		$this->start_controls_tab(
			'tab_menu_normal',
			[
				'label' => __( 'Normal', 'indostio' ),
			]
		);

		$this->add_control(
			'menu_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-sidebar__menu li a' => 'color: {{VALUE}};'
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_menu_hover',
			[
				'label' => __( 'Hover', 'indostio' ),
			]
		);

		$this->add_control(
			'menu_hover_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-sidebar__menu li a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

	
		$this->end_controls_section();


	}

	/**
	 * Render icon box widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'wrapper', 'class', 'indostio-sidebar indostio-sidebar-menu' );

		$menu_items = $settings['menu_items'];
		$this->add_render_attribute( 'menu', 'class', ['menu', 'indostio-sidebar__menu'] );
		
		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<a href="#" class="indostio-sidebar--icon">
				<?php
					if( ! empty( $settings['icon'] ) && ! empty( $settings['icon']['value'] ) ) {
						echo '<span class="indostio-svg-icon indostio-sidebar-svg-icon">';
						\Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] );
						echo '</span>';
					} else {
						echo \Indostio\Addons\Helper::get_svg('menu', 'indostio-sidebar-svg-icon');
					}
				?>
			</a>
			<div class="indostio-sidebar__backdrop"></div>
			<div class="indostio-sidebar__panel">
				<?php echo \Indostio\Addons\Helper::get_svg('close', 'indostio-close-svg-icon'); ?>
				<?php
					if ( $settings['menu_type'] == "wordpress" ) {
						if ( empty( $settings['list_menu'] ) ) {
							return;
						}

						wp_nav_menu( array(
							'theme_location' 	=> '__no_such_location',
							'menu'           	=> $settings['list_menu'],
							'container'      	=> 'nav',
							'container_class'   => '',
							'menu_class'     	=> 'menu indostio-sidebar__menu',
							'depth'          	=> 2,
						) );
					} else {
						?>
						<ul <?php echo $this->get_render_attribute_string( 'menu' ); ?>>
						<?php if ( ! empty ( $menu_items ) ) {
							foreach ( $menu_items as $item ) {
								if ( !empty( $item['title_menu'] ) ) {
									echo '<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-' . $item['_id'] . '">';
									echo '<a href="' . $item['link_menu']['url'] . '">' . $item['title_menu'] . '</a>';
									echo'</li>';
								}
							}
						}
						?>
						</ul>
						<?php 
					}
				?>
			</div>
		</div>
		<?php

	}
}