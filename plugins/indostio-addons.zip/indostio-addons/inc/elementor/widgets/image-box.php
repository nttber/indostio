<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Controls_Stack ;
use Elementor\Group_Control_Border ;
use Indostio\Addons\Helper;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Image Box widget
 */
class Image_Box extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-image-box';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Indostio] Image Box', 'indostio' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-image-box';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return ['indostio'];
	}

	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
   	public function get_keywords() {
	   return [ 'image box', 'icon', 'box', 'indostio' ];
   	}

	/**
	 * Register the widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->content_sections();
		$this->style_sections();
	}

	protected function content_sections() {
		$this->start_controls_section(
			'section_icon',
			[ 'label' => __( 'Image Box', 'indostio' ) ]
		);

		$this->add_control(
			'image',
			[
				'label' => __( 'Choose Image', 'indostio' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'image',
				'default'   => 'full',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'image_position',
			[
				'label' => esc_html__( 'Image Position', 'indostio' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => 'left',
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'indostio' ),
						'icon' => 'eicon-h-align-left',
					],
					'top' => [
						'title' => esc_html__( 'Top', 'indostio' ),
						'icon' => 'eicon-v-align-top',
					],
				],
				'prefix_class' => 'indostio-image-box__image-position--',
				'toggle' => false,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'icon',
			[
				'label' => __( 'Icon', 'indostio' ),
				'type' => Controls_Manager::ICONS,
				'default' => [],
			]
		);

		$this->add_control(
			'icon_position',
			[
				'label' => esc_html__( 'Icon Position', 'indostio' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => 'top',
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left Title', 'indostio' ),
						'icon' => 'eicon-h-align-left',
					],
					'top' => [
						'title' => esc_html__( 'Top Title', 'indostio' ),
						'icon' => 'eicon-v-align-top',
					],
				],
				'prefix_class' => 'indostio-image-box__icon-position--',
				'toggle' => false,
				'separator' => 'before',
				'conditions' => [
					'terms' => [
						[
							'name' => 'image_position',
							'operator' => '==',
							'value' => 'top'
						],
					]
				]
			]
		);


		$this->add_control(
			'number',
			[
				'label' => __( 'Number', 'indostio' ),
				'type' => Controls_Manager::TEXT,
				'default' => '',
			]
		);

		$this->add_control(
			'title',
			[
				'label' => __( 'Title & Description', 'indostio' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'This is the heading', 'indostio' ),
				'placeholder' => __( 'Title', 'indostio' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'description',
			[
				'label' => '',
				'type' => Controls_Manager::TEXTAREA,
				'default' => '',
				'placeholder' => __( 'Enter your description', 'indostio' ),
				'rows' => 10,
				'separator' => 'none',
				'show_label' => false,
			]
		);

		$this->add_control(
			'title_size',
			[
				'label' => __( 'Title HTML Tag', 'indostio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'h6',
			]
		);

		$this->add_control(
			'button_icon',
			[
				'label' => __( 'Button Icon', 'indostio' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
				],
			]
		);

		$this->add_control(
			'button_text',
			[
				'label' => __( 'Button Text', 'indostio' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => '',
				'label_block' => true,
			]
		);

		$this->add_control(
			'button_url',
			[
				'label' => esc_html__( 'Button URL', 'indostio' ),
				'type' => Controls_Manager::URL,
				'label_block' => true,
			]
		);

		$this->add_control(
			'button_link_type',
			[
				'label'   => esc_html__( 'Apply Button Link On', 'indostio' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'only' => esc_html__( 'Button Only', 'indostio' ),
					'all'  => esc_html__( 'Whole Image Box', 'indostio' ),
				],
				'default' => 'only',
				'toggle'  => false,
			]
		);

		$this->end_controls_section();
	}

	protected function style_sections() {
		$this->content_style_sections();
	}

	protected function content_style_sections() {
		// Content style
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => __( 'Content', 'indostio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => esc_html__( 'Padding', 'indostio' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .indostio-image-box__content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'content_shadow',
				'label' => __( 'Box Shadow', 'indostio' ),
				'selector' => '{{WRAPPER}} .indostio-image-box__content',
			]
		);

		$this->add_control(
			'number_heading',
			[
				'label'     => esc_html__( 'Number', 'indostio' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$this->add_responsive_control(
			'number_top',
			[
				'label'     => __( 'Top', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 1000,
						'min' => -500,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-image-box__number' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'number_left',
			[
				'label'     => __( 'Left', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 1000,
						'min' => -500,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-image-box__number' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'number_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-image-box__number' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'number_typography',
				'selector' => '{{WRAPPER}} .indostio-image-box__number',
			]
		);

		$this->add_control(
			'number_stroke_color',
			[
				'label' => __( 'Number Stroke Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-image-box__number' => '--id-number-stroke-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_style_heading',
			[
				'label' => __( 'Icon', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-image-box__icon' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'icon_typography',
				'selector' => '{{WRAPPER}} .indostio-image-box__icon',
			]
		);

		$this->add_responsive_control(
			'icon_spacing',
			[
				'label' => __( 'Spacing', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					]
				],
				'default' => [],
				'selectors' => [
					'{{WRAPPER}} .indostio-image-box__icon' => 'margin-bottom: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}}.indostio-image-box__icon-position--left .indostio-image-box__icon' => 'margin-right: {{SIZE}}{{UNIT}};margin-bottom:0',
				],
			]
		);

		$this->add_control(
			'title_style_heading',
			[
				'label' => __( 'Title', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-image-box__title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .indostio-image-box__title',
			]
		);

		$this->add_responsive_control(
			'title_spacing',
			[
				'label' => __( 'Spacing', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					]
				],
				'default' => [],
				'selectors' => [
					'{{WRAPPER}} .indostio-image-box__title' => 'margin-bottom: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}}.indostio-image-box__icon-position--left .indostio-image-box__title' => 'margin-bottom: 0',
					'{{WRAPPER}}.indostio-image-box__icon-position--left .indostio-image-box__head' => 'margin-bottom: {{SIZE}}{{UNIT}}',
					
				],
			]
		);

		$this->add_control(
			'description_style_heading',
			[
				'label' => __( 'Description', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-image-box__description' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .indostio-image-box__description',
			]
		);

		$this->add_responsive_control(
			'description_spacing',
			[
				'label' => __( 'Spacing', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					]
				],
				'default' => [],
				'selectors' => [
					'{{WRAPPER}} .indostio-image-box__description' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'button_style_heading',
			[
				'label' => __( 'Button', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'button_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-image-box__button' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'button_typography',
				'selector' => '{{WRAPPER}} .indostio-image-box__button',
			]
		);

		$this->add_responsive_control(
			'button_icon_size',
			[
				'label' => __( 'Icon Size', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					]
				],
				'default' => [],
				'selectors' => [
					'{{WRAPPER}} .indostio-image-box__button-icon' => 'font-size: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render image box widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'wrapper', 'class', ['indostio-image-box'] );
		$this->add_render_attribute( 'icon', 'class', 'indostio-image-box__icon' );
		$this->add_render_attribute( 'title', 'class', 'indostio-image-box__title' );
		$this->add_render_attribute( 'description', 'class', 'indostio-image-box__description' );
		$this->add_render_attribute( 'number', 'class', 'indostio-image-box__number' );

		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<div class="indostio-image-box__thumbnail">
				<?php echo Group_Control_Image_Size::get_attachment_image_html( $settings ); ?>
			</div>
			<div class="indostio-image-box__content">
				<div class="indostio-image-box__wrapper">
					<?php if( ! empty( $settings['number'] ) ) : ?>
						<div <?php echo $this->get_render_attribute_string( 'number' ); ?>><?php echo wp_kses_post( $settings['number'] ) ?></div>
					<?php endif; ?>
					<div class="indostio-image-box__head">
						<?php
						if( isset($settings['icon']) && ! empty($settings['icon']['value'] ) ) {
							echo '<span class="indostio-svg-icon indostio-image-box__icon">';
							Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] );
							echo '</span>';
						}
						?>
						<?php if( ! empty( $settings['title'] ) ) : ?>
							<<?php Utils::print_validated_html_tag( $settings['title_size'] ); ?> <?php echo $this->get_render_attribute_string( 'title' ); ?>><?php echo wp_kses_post( $settings['title'] ) ?></<?php Utils::print_validated_html_tag( $settings['title_size'] ); ?>>
						<?php endif; ?>
					</div>
					<?php if( ! empty( $settings['description'] ) ) : ?>
						<div <?php echo $this->get_render_attribute_string( 'description' ); ?>><?php echo wp_kses_post( $settings['description'] ) ?></div>
					<?php endif; ?>
					<?php
					if ( ! empty($settings['button_text'] ) ) {
						echo Helper::render_control_link_open( 'btn_full', $settings['button_url'],  [ 'class' => 'indostio-image-box__button' ] );
						echo '<span class="indostio-image-box__button-text">' . $settings['button_text'] . '</span>';
						echo '<span class="indostio-svg-icon indostio-image-box__button-icon">';
							\Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] );
						echo '</span>';
						echo '</a>';
					}
					
					?>
				</div>
			</div>
			<?php
			if ( ! empty($settings['button_link_type'] ) && !empty($settings['button_url']) ) {
				echo Helper::render_control_link_open( 'btn_all', $settings['button_url'],  [ 'class' => 'indostio-image-box__button_all' ] );
				echo '</a>';
			}
			?>
		</div>
		<?php
	}
}