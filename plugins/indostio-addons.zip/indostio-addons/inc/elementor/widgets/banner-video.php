<?php

namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Widget_Base;
use Indostio\Addons\Elementor\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Banner Video widget
 */
class Banner_Video extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-banner-video';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Indostio - Banner Video', 'indostio' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-youtube';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'indostio' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'video', 'banner' ];
	}

	public function get_script_depends() {
		return [
			'magnific',
			'indostio-frontend'
		];
	}

	public function get_style_depends() {
		return [
			'magnific'
		];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->section_content();
		$this->section_style();
	}

	/**
	 * Section Content
	 */
	protected function section_content() {

		$this->start_controls_section(
			'section_content',
			[ 'label' => esc_html__( 'Content', 'indostio' ) ]
		);

		$this->add_control(
			'video_type',
			[
				'label' => __( 'Source', 'indostio' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'youtube',
				'options' => [
					'youtube' => __( 'YouTube', 'indostio' ),
					'vimeo' => __( 'Vimeo', 'indostio' ),
					'self_hosted' => __( 'Self Hosted', 'indostio' ),
				],
			]
		);

		$this->add_control(
			'youtube_url',
			[
				'label' => __( 'Link', 'indostio' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your URL', 'indostio' ) . ' (YouTube)',
				'default' => 'https://www.youtube.com/watch?v=XHOmBV4js_E',
				'label_block' => false,
				'condition' => [
					'video_type' => 'youtube',
				],
			]
		);

		$this->add_control(
			'vimeo_url',
			[
				'label' => __( 'Link', 'indostio' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your URL', 'indostio' ) . ' (Vimeo)',
				'default' => 'https://vimeo.com/235215203',
				'label_block' => false,
				'condition' => [
					'video_type' => 'vimeo',
				],
			]
		);

		$this->add_control(
			'insert_url',
			[
				'label' => __( 'External URL', 'indostio' ),
				'type' => Controls_Manager::SWITCHER,
				'condition' => [
					'video_type' => 'self_hosted',
				],
			]
		);

		$this->add_control(
			'external_url',
			[
				'label' => __( 'Link', 'indostio' ),
				'type' => Controls_Manager::URL,
				'placeholder' => __( 'Enter your URL', 'indostio' ),
				'autocomplete' => false,
				'options' => false,
				'label_block' => true,
				'show_label' => false,
				'media_type' => 'video',
				'condition' => [
					'video_type' => 'self_hosted',
					'insert_url' => 'yes'
				],
			]
		);

		$this->add_control(
			'hosted_url',
			[
				'label' => __( 'Choose File', 'indostio' ),
				'type' => Controls_Manager::MEDIA,
				'media_type' => 'video',
				'condition' => [
					'video_type' => 'self_hosted',
					'insert_url' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'banners_background',
				'label'    => __( 'Background', 'indostio' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .indostio-banner-video .banner-featured-image',
				'fields_options'  => [
					'background' => [
						'default' => 'classic',
					],
					'image' => [
						'default'   => [
							'url' => 'https://via.placeholder.com/1170X430/f5f5f5?text=Banner Image',
						],
					],
				],
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label'     => esc_html__( 'Height', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'unit' => 'px',
					'size' => 430,
				],
				'range'     => [
					'px' => [
						'min' => 100,
						'max' => 1000
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-banner-video' => 'height: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'link_type',
			[
				'label'   => esc_html__( 'Link Type', 'indostio' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'only'   => esc_html__( 'Only marker', 'indostio' ),
					'all' 	 => esc_html__( 'All banner', 'indostio' ),
				],
				'default' => 'only',
				'toggle'  => false,
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Section Style
	 */

	protected function section_style() {
		$this->start_controls_section(
			'style_content',
			[
				'label' => __( 'Marker', 'indostio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'marker_alignment',
			[
				'label' => esc_html__( 'Alignment', 'indostio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'left' => esc_html__( 'Left', 'indostio' ),
					'right' => esc_html__( 'Right', 'indostio' ),
					'center' => esc_html__( 'Center Center', 'indostio' ),
				],
				'default' => 'left',
				'prefix_class' => 'indostio-banner-video__marker-',
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label'     => __( 'Font Size', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-banner-video__play'     => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => __( 'Color', 'indostio' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .indostio-banner-video__play' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_bg_color',
			[
				'label'     => __( 'Background Color', 'indostio' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .indostio-banner-video__play' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_radius',
			[
				'label'      => __( 'Border Radius', 'indostio' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .indostio-banner-video__play' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_bg_width',
			[
				'label'     => __( 'Width', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-banner-video__play' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_bg_height',
			[
				'label'     => __( 'Height', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-banner-video__play' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render icon box widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute(
			'wrapper', 'class', [
				'indostio-banner-video'
			]
		);

		$icon =  '<span class="indostio-svg-icon"><svg width="22" height="26" viewBox="0 0 22 26" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M19.875 11.0781L3.375 1.32812C2.01562 0.53125 0 1.32812 0 3.25V22.75C0 24.5312 1.875 25.6094 3.375 24.7188L19.875 14.9688C21.3281 14.0781 21.3281 11.9688 19.875 11.0781ZM2.25 22.2812V3.76562C2.25 3.53125 2.48438 3.39062 2.67188 3.53125L18.3281 12.7656C18.5156 12.9062 18.5156 13.1406 18.3281 13.2812L2.67188 22.5156C2.48438 22.6094 2.25 22.5156 2.25 22.2812Z" fill="currentColor"/></svg></span>';

		$marker_html =  sprintf('<span class="indostio-banner-video__marker">%s</span>', $icon) ;

		$video_url = array();


		if ($settings['video_type'] == 'youtube') {

			$video_url['url'] = $settings['youtube_url'];

		} elseif ($settings['video_type'] == 'vimeo') {

			$video_url['url'] = $settings['vimeo_url'];

		} else {

			if ( ! empty( $settings['insert_url'] ) ) {
				$video_url['url'] = $settings['external_url']['url'];
			} else {
				$video_url['url'] = $settings['hosted_url']['url'];
			}
		}

		$video_url['is_external'] = $video_url['nofollow'] = '';

		$btn_full = '';
		if ( $video_url['url']) :
			if ( $settings['link_type'] == 'only') {
				$marker_html = \Indostio\Addons\Helper::control_url( 'btn_1', $video_url, $marker_html, [ 'class' => 'indostio-banner-video__play' ] );
			} else {
				$btn_full =  \Indostio\Addons\Helper::control_url( 'btn_2', $video_url, '', [ 'class' => 'indostio-banner-video__play full-box-button' ] ) ;
			}
		endif;

		echo sprintf(
			'<div %s>
				<div class="banner-featured-image"></div>
				%s %s
			</div>',
			$this->get_render_attribute_string( 'wrapper' ),
			$marker_html, $btn_full
		);
	}
}