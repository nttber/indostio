<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Conditions;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Controls_Stack;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Icon Box widget
 */
class Navigation_Menu extends Widget_Base {
/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-navigation-menu';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Indostio] Navigation Menu', 'indostio' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-nav-menu';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return ['indostio'];
	}

	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
   	public function get_keywords() {
	   return [ 'navigation-menu', 'menu', 'indostio' ];
   	}

	/**
	 * Register the widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */

	protected function register_controls() {
		$this->content_sections();
		$this->style_sections();
	}

	protected function content_sections() {
		$this->start_controls_section(
			'section_navigation_menu',
			[ 'label' => __( 'Navigation Menu', 'indostio' ) ]
		);

		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'indostio' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => '',
			]
		);

		$this->add_control(
			'menu_type',
			[
				'label' => __( 'Type', 'indostio' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'wordpress',
				'options' => [
					'wordpress'  => esc_html__( 'WordPress Menu', 'indostio' ),
					'custom' => esc_html__( 'Custom', 'indostio' ),
				],
			]
		);

		$this->add_control(
			'list_menu',
			[
				'label' => __( 'Select Menu', 'indostio' ),
				'type' => Controls_Manager::SELECT,
				'options' => \Indostio\Addons\Helper::get_navigation_bar_get_menus(),
				'condition' => [
					'menu_type' => 'wordpress',
				],
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title_menu',
			[
				'label'   => esc_html__( 'Text', 'indostio' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Menu item', 'indostio' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'link_menu', [
				'label'         => esc_html__( 'Link', 'indostio' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'indostio' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'menu_items',
			[
				'label'         => esc_html__( 'Menu Items', 'indostio' ),
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'default'       => [
					[
						'title_menu' => esc_html__( 'Menu item 1', 'indostio' ),
						'link_menu' => '#',
					],
					[
						'title_menu' => esc_html__( 'Menu item 2', 'indostio' ),
						'link_menu' => '#',
					],
					[
						'title_menu' => esc_html__( 'Menu item 3', 'indostio' ),
						'link_menu' => '#',
					],
				],
				'prevent_empty' => false,
				'condition' => [
					'menu_type' => 'custom',
				],
				'title_field'   => '{{{ title_menu }}}',
			]
		);

		$this->add_control(
			'menu_stype',
			[
				'label' => __( 'Style', 'indostio' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'column',
				'options' => [
					'column'  => esc_html__( 'Vertical', 'indostio' ),
					'row' => esc_html__( 'Horizontal', 'indostio' ),
				],
				'selectors' => [
					'{{WRAPPER}} ul.menu' => 'flex-direction: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'style_align',
			[
				'label' => __( 'Alignment', 'indostio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => __( 'Left', 'indostio' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'indostio' ),
						'icon' => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'indostio' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => 'flex-start',
				'tablet_default' => 'flex-start',
				'mobile_default' => 'flex-start',
				'selectors' => [
					'{{WRAPPER}} ul.menu' => 'justify-content: {{VALUE}};',
				],
				'condition' => [
					'menu_stype' => 'row',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function style_sections(){
		$this->start_controls_section(
			'style_navigation_menu',
			[
				'label'     => __( 'Navigation Menu', 'indostio' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_control(
			'style_title',
			[
				'label' => __( 'Title', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-navigation-menu__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_hidden',
			[
				'label'     => __( 'Hidden', 'indostio' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'indostio' ),
				'label_on'  => __( 'On', 'indostio' ),
				'default'   => 'no',
			]
		);


		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'selector' => '{{WRAPPER}} .indostio-navigation-menu__title',
			]
		);

		$this->add_responsive_control(
			'spacing',
			[
				'label' => __( 'Spacing', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'size' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-navigation-menu__title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'style_menu',
			[
				'label' => __( 'Menu Item', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography_menu',
				'selector' => '{{WRAPPER}} .indostio-navigation-menu__menu li a',
			]
		);
		
		$this->add_control(
			'menu_item_padding',
			[
				'label'      => esc_html__( 'Menu Item Padding', 'indostio' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px'],
				'selectors'  => [
					'{{WRAPPER}} ul.menu > li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);

		$this->start_controls_tabs('style_button_tabs');

		$this->start_controls_tab(
			'tab_menu_normal',
			[
				'label' => __( 'Normal', 'indostio' ),
			]
		);

		$this->add_control(
			'menu_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.menu > li > a' => 'color: {{VALUE}};'
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_menu_hover',
			[
				'label' => __( 'Hover', 'indostio' ),
			]
		);

		$this->add_control(
			'menu_hover_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.menu > li > a:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} ul.menu > li > a:after' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'style_submenu',
			[
				'label' => __( 'SubMenus', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

	
		$this->end_controls_section();


	}

	/**
	 * Render icon box widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'container', 'class', 'indostio-navigation-menu__container' );
		$title_class = $settings['title_hidden'] == 'yes' ? 'title--hidden' : '';
		$this->add_render_attribute( 'title', 'class', ['indostio-navigation-menu__title', $title_class ] );
		$this->add_inline_editing_attributes( 'title' );
		$title = $settings['title'];

		$menu_items = $settings['menu_items'];
		$this->add_render_attribute( 'menu', 'class', ['menu', 'indostio-navigation-menu__menu'] );
		$menu_style = !empty( $settings['menu_stype'] ) ? $settings['menu_stype'] : 'column';
		?>
				<?php
				if ( ! empty( $settings['title'] ) ) {
					printf( '<div %1$s>%2$s</div>', $this->get_render_attribute_string( 'title' ), $title );
				}
				?>

				<?php
					if ( $settings['menu_type'] == "wordpress" ) {
						if ( empty( $settings['list_menu'] ) ) {
							return;
						}

						wp_nav_menu( array(
							'theme_location' 	=> '__no_such_location',
							'menu'           	=> $settings['list_menu'],
							'container'      	=> 'nav',
							'container_class'   => 'main-navigation menu-stye--' . $menu_style,
							'menu_class'     	=> 'menu indostio-navigation-menu__menu',
							'depth'          	=> 4,
						) );
					} else {
						?>
						<div class="main-navigation <?php echo 'menu-stye--' . $menu_style; ?>">
						<ul <?php echo $this->get_render_attribute_string( 'menu' ); ?>>
						<?php if ( ! empty ( $menu_items ) ) {
							foreach ( $menu_items as $item ) {
								if ( !empty( $item['title_menu'] ) ) {
									echo '<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-' . $item['_id'] . '">';
									echo '<a href="' . $item['link_menu']['url'] . '">' . $item['title_menu'] . '</a>';
									echo'</li>';
								}
							}
						}
						?>
						</ul>
						</div>
						<?php 
					}
				?>
		<?php

	}
}