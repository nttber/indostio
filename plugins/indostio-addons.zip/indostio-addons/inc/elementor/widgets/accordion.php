<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Icons_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Accordion widget.
 */
class Accordion extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-accordion';
	}

	/**
	 * Get widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Indostio] Accordion', 'indostio' );
	}

	/**
	 * Get widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-accordion';
	}

	/**
	 * Get widget categories
	 *
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return string Widget categories
	 */
	public function get_categories() {
		return [ 'indostio' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'accordion', 'tabs', 'toggle', 'indostio' ];
	}

	/**
	 * Register accordion widget controls.
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Accordion', 'indostio' ),
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'tab_active',
			[
				'label'   => __( 'Active', 'indostio' ),
				'type'    => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'indostio' ),
				'label_on'  => __( 'On', 'indostio' ),
				'default'   => '',
			]
		);

		$repeater->add_control(
			'tab_title',
			[
				'label' => __( 'Title', 'indostio' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Accordion Title', 'indostio' ),
				'dynamic' => [
					'active' => true,
				],
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'tab_content',
			[
				'label' => __( 'Description', 'indostio' ),
				'type' => Controls_Manager::WYSIWYG,
				'default' => __( 'Accordion Content', 'indostio' ),
				'show_label' => false,
			]
		);

		$this->add_control(
			'tabs',
			[
				'label' => __( 'List', 'indostio' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'tab_title' => __( 'Accordion #1', 'indostio' ),
						'tab_content' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'indostio' ),
					],
					[
						'tab_title' => __( 'Accordion #2', 'indostio' ),
						'tab_content' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'indostio' ),
					],
				],
				'title_field' => '{{{ tab_title }}}',
			]
		);

		$this->add_control(
			'title_html_tag',
			[
				'label' => __( 'Title HTML Tag', 'indostio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
				],
				'default' => 'div',
				'separator' => 'before',
			]
		);
		
		$this->add_control(
			'icon',
			[
				'label' => __( 'Icon', 'indostio' ),
				'type' => Controls_Manager::ICONS,
				'default' => [],
			]
		);

		$this->add_control(
			'selected_icon',
			[
				'label' => __( 'Active Icon', 'indostio' ),
				'type' => Controls_Manager::ICONS,
				'default' => [],
			]
		);

		$this->add_control(
			'icon_position',
			[
				'label'                => esc_html__( 'Icon Position', 'indostio' ),
				'type'                 => Controls_Manager::CHOOSE,
				'label_block'          => false,
				'options'              => [
					'left'   => [
						'title' => esc_html__( 'Left', 'indostio' ),
						'icon'  => 'eicon-h-align-left',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'indostio' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'prefix_class' => 'indostio-accordion__icon-position--',
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_accordion',
			[
				'label' => __( 'Accordion', 'indostio' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'heading_items',
			[
				'label' => __( 'Items', 'indostio' ),
				'type' => Controls_Manager::HEADING,
			]
		);


		$this->add_responsive_control(
			'items_margin',
			[
				'label' => __( 'Spacing Bottom', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					]
				],
				'default' => [],
				'selectors' => [
					'{{WRAPPER}} .indostio-accordion__item' => 'margin-bottom: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .indostio-accordion__item:last-child' => 'margin-bottom: 0',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'content_item_border',
				'label' => esc_html__( 'Border', 'indostio' ),
				'selector' => '{{WRAPPER}} .indostio-accordion__title',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'content_box_shadow',
				'label' => __( 'Box Shadow Active', 'indostio' ),
				'selector' => '{{WRAPPER}} .indostio-accordion__item.indostio-tab--active',
			]
		);

		$this->add_control(
			'heading_title',
			[
				'label' => __( 'Title', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'title_padding',
			[
				'label'      => esc_html__( 'Padding', 'indostio' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .indostio-accordion__title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'.indostio-rtl-smart {{WRAPPER}} .indostio-accordion__title a' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-accordion__title, {{WRAPPER}} .indostio-accordion__title a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .indostio-accordion__title',
			]
		);

		$this->add_control(
			'heading_content',
			[
				'label' => __( 'Description', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => esc_html__( 'Padding', 'indostio' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .indostio-accordion__content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'.indostio-rtl-smart {{WRAPPER}} .indostio-accordion__content' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_spacing',
			[
				'label' => __( 'Spacing', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					]
				],
				'default' => [],
				'selectors' => [
					'{{WRAPPER}} .indostio-accordion__content' => 'margin-top: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'content_bg_color',
			[
				'label' => __( 'Background Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-accordion__content' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'content_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-accordion__content' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .indostio-accordion__content',
			]
		);

		$this->add_control(
			'heading_icon',
			[
				'label' => __( 'Icon', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'icon_padding',
			[
				'label'      => esc_html__( 'Padding', 'indostio' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .indostio-accordion__icons' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label' => __( 'Size', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					]
				],
				'default' => [],
				'selectors' => [
					'{{WRAPPER}} .indostio-accordion__icon' => 'font-size: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'icon_border_color',
			[
				'label' => __( 'Border Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-accordion__icons' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->start_controls_tabs(
			'style_tabs_icon'
		);

		$this->start_controls_tab(
			'style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'indostio' ),
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-accordion__icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => esc_html__( 'Active', 'indostio' ),
			]
		);

		$this->add_control(
			'icon_active_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-accordion__selected-icon' => 'color: {{VALUE}};',
				],
			]
		);
		

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Render accordion widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$id_int = substr( $this->get_id_int(), 0, 3 );
		?>
		<div class="indostio-accordion" role="tablist">
			<?php
			foreach ( $settings['tabs'] as $index => $item ) :
				$tab_count = $index + 1;

				$tab_title_setting_key = $this->get_repeater_setting_key( 'tab_title', 'tabs', $index );
				$tab_content_setting_key = $this->get_repeater_setting_key( 'tab_content', 'tabs', $index );
				$active_class =  $item['tab_active'] == 'yes' ? "indostio-tab--active" : '';

				$this->add_render_attribute( $tab_title_setting_key, [
					'id' => 'indostio-tab-title-' . $id_int . $tab_count,
					'class' => [ 'indostio-accordion__title', $active_class ],
					'data-tab' => $tab_count,
					'role' => 'tab',
					'aria-controls' => 'indostio-tab-content-' . $id_int . $tab_count,
				] );

				$this->add_render_attribute( $tab_content_setting_key, [
					'id' => 'indostio-tab-content-' . $id_int . $tab_count,
					'class' => [ 'indostio-accordion__content', 'clearfix', $active_class ],
					'data-tab' => $tab_count,
					'role' => 'tabpanel',
					'aria-labelledby' => 'indostio-tab-title-' . $id_int . $tab_count,
				] );


				$icon = '';
				$selected_icon = '';
				if( ! empty( $settings['icon']['value'] ) ) {
					$icon = Icons_Manager::try_get_icon_html( $settings['icon'], [ 'aria-hidden' => 'true' ] );
				} else {
					$icon = '<svg width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.66406 0.621094L6.96094 1.28906C6.78516 1.46484 6.78516 1.74609 6.96094 1.88672L12.4102 7.33594H0.421875C0.175781 7.33594 0 7.54688 0 7.75781V8.74219C0 8.98828 0.175781 9.16406 0.421875 9.16406H12.4102L6.96094 14.6484C6.78516 14.7891 6.78516 15.0703 6.96094 15.2461L7.66406 15.9141C7.80469 16.0898 8.08594 16.0898 8.26172 15.9141L15.6094 8.56641C15.7852 8.39062 15.7852 8.14453 15.6094 7.96875L8.26172 0.621094C8.08594 0.445312 7.80469 0.445312 7.66406 0.621094Z" fill="currentColor"/></svg>';
				}

				if( ! empty( $settings['selected_icon']['value'] ) ) {
					$selected_icon = Icons_Manager::try_get_icon_html( $settings['selected_icon'], [ 'aria-hidden' => 'true' ] );
				} else {
					$selected_icon = '<svg width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.5039 8.07422L14.8359 7.37109C14.6602 7.19531 14.3789 7.19531 14.2383 7.37109L8.78906 12.8203V0.796875C8.78906 0.585938 8.57812 0.375 8.36719 0.375H7.38281C7.13672 0.375 6.96094 0.585938 6.96094 0.796875V12.8203L1.47656 7.37109C1.33594 7.19531 1.05469 7.19531 0.878906 7.37109L0.210938 8.07422C0.0351562 8.21484 0.0351562 8.49609 0.210938 8.67188L7.55859 16.0195C7.73438 16.1953 7.98047 16.1953 8.15625 16.0195L15.5039 8.67188C15.6797 8.49609 15.6797 8.21484 15.5039 8.07422Z" fill="currentColor"/></svg>';
				}

				$this->add_inline_editing_attributes( $tab_content_setting_key, 'advanced' );
				?>
				<div class="indostio-accordion__item <?php echo esc_attr( $active_class ); ?>">
					<<?php echo $settings['title_html_tag']; ?> <?php echo $this->get_render_attribute_string( $tab_title_setting_key ); ?>>
						<div class="indostio-accordion__icons">
							<span class="indostio-accordion__icon indostio-svg-icon">
								<?php echo \Elementor\Utils::print_unescaped_internal_string($icon); ?>
							</span>
							<span class="indostio-accordion__selected-icon indostio-svg-icon">
								<?php echo \Elementor\Utils::print_unescaped_internal_string($selected_icon); ?>
							</span>
						</div>
						<a class="indostio-accordion__title-text" href="#indostio-tab-content-<?php echo $id_int . $tab_count; ?>"><?php echo $item['tab_title']; ?></a>
					</<?php echo $settings['title_html_tag']; ?>>
					<div <?php echo $this->get_render_attribute_string( $tab_content_setting_key ); ?>><?php echo $this->parse_text_editor( $item['tab_content'] ); ?></div>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}
}
