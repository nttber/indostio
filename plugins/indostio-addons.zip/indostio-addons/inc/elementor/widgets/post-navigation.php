<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Indostio\Addons\Helper;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor heading widget.
 *
 * Elementor widget that displays an eye-catching headlines.
 *
 * @since 1.0.0
 */
class Post_Navigation extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve heading widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-post-navigation';
	}

	/**
	 * Get widget title
	 *
	 * Retrieve heading widget title
	 *
	 * @return string Widget title
	 */
	public function get_title() {
		return __( '[Indostio] Post Navigation', 'indostio' );
	}

	/**
	 * Get widget icon
	 *
	 * Retrieve heading widget icon
	 *
	 * @return string Widget icon
	 */
	public function get_icon() {
		return 'eicon-post-navigation';
	}

	/**
	 * Get widget categories
	 *
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return string Widget categories
	 */
	public function get_categories() {
		return [ 'indostio' ];
	}

	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'navigation', 'post', 'indostio' ];
	}

	/**
	 * Register heading widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'indostio' ),
			]
		);

		$this->add_control(
			'title_heading',
			[
				'label' => __( 'Title', 'motta-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'disable_title',
			[
				'label'        => __( 'Disable Title', 'indostio' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'indostio' ),
				'label_on'  => __( 'On', 'indostio' ),
				'return_value' => 'yes',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .nav-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .nav-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'read_more_heading',
			[
				'label' => __( 'Read More', 'motta-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'disable_read_more',
			[
				'label'        => __( 'Disable Read More', 'indostio' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'indostio' ),
				'label_on'  => __( 'On', 'indostio' ),
				'return_value' => 'yes',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'read_more_typography',
				'selector' => '{{WRAPPER}} .meta-read-more',
			]
		);

		$this->add_control(
			'read_more_color',
			[
				'label' => esc_html__( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .meta-read-more' => 'color: {{VALUE}};',
				],
			]
		);

		
		$this->add_control(
			'icon_heading',
			[
				'label' => __( 'Icon', 'motta-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'enable_icon',
			[
				'label'        => __( 'Enable Icon', 'indostio' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'indostio' ),
				'label_on'  => __( 'On', 'indostio' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .indostio-grid-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render heading widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$next_post = get_next_post(false, '', 'indostio_service_cat');
		$prev_post = get_previous_post(false, '', 'indostio_service_cat');

		if ( ! $next_post && ! $prev_post ) {
			return;
		}
		?>

		<nav class="navigation post-navigation" role="navigation">
			<div class="nav-links">
				<?php if ( $prev_post ) : ?>
					<a class="nav-previous" href="<?php echo esc_url( get_permalink( $prev_post ) )  ?>">
						<?php
						if ( has_post_thumbnail( $prev_post ) ) {
							echo '<span class="post-thumbnail">';
							echo get_the_post_thumbnail( $prev_post, 'indostio-post-thumbnail-small' );
							echo \Indostio\Addons\Helper::get_svg( 'left-mini' );
							echo '</span>';
						}
						?>
						<span class="nav-title">
							<?php
							if( $settings['disable_title'] != 'yes' ) {
								echo sprintf( '<div class="meta meta-title">%s</div>', esc_html( $prev_post->post_title ) );
							}
							if( $settings['disable_read_more'] != 'yes' ) {
								echo sprintf( '<div class="meta meta-date meta-read-more">%s%s</div>', esc_html__('Read More', 'indostio'), \Indostio\Addons\Helper::get_svg( 'arrow' ) );
							}
							?>
						</span>
					</a>
				<?php else : ?>
					<span class="nav-previous">
					</span>
				<?php endif; ?>
				<?php if( $settings['enable_icon'] ) { ?>
					<span class="indostio-svg-icon indostio-grid-icon"><svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="3.5" cy="3.5" r="3.5" fill="currentColor"/><circle cx="3.5" cy="17.5" r="3.5" fill="currentColor"/><circle cx="17.5" cy="17.5" r="3.5" fill="currentColor"/><circle cx="17.5" cy="3.5" r="3.5" fill="currentColor"/></svg></span>
				<?php } ?>
				<?php if ( $next_post ) :?>
					<a class="nav-next" href="<?php echo esc_url( get_permalink( $next_post ) )  ?>">
						<span class="nav-title">
							<?php
							if( $settings['disable_title'] != 'yes' ) {
								echo sprintf( '<div class="meta meta-title">%s</div>', esc_html( $next_post->post_title ) );
							}
							if( $settings['disable_read_more'] != 'yes' ) {
								echo sprintf( '<div class="meta meta-date meta-read-more">%s%s</div>', esc_html__('Read More', 'indostio'), \Indostio\Addons\Helper::get_svg( 'arrow' ) );
							}
							?>
						</span>

						<?php
							if ( has_post_thumbnail( $next_post ) ) {
								echo '<span class="post-thumbnail">';
								echo get_the_post_thumbnail( $next_post, 'indostio-post-thumbnail-small' );
								echo \Indostio\Addons\Helper::get_svg( 'right-mini' );
								echo '</span>';
							}
							?>
					</a>
				<?php else : ?>
					<span class="nav-next">
					</span>
				<?php endif; ?>
			</div>
		</nav>
		<?php
	}
}