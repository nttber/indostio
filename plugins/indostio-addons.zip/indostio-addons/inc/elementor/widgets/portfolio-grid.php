<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Stack;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Indostio\Addons\Helper;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Icon Box widget
 */
class Portfolio_Grid extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-portfolio-grid';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Indostio] Portfolio Grid', 'indostio' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return ['indostio'];
	}

	public function get_script_depends() {
		return [
			'imagesLoaded',
			'isotope',
			'indostio-frontend'
		];
	}

	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'portfolio grid', 'portfolio', 'grid', 'indostio' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_portfolio_grid',
			[ 'label' => __( 'Portfolio Grid', 'indostio' ) ]
		);

		$this->add_control(
			'limit',
			[
				'label'     => __( 'Total', 'indostio' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => -1,
				'max'       => 100,
				'step'      => 1,
				'default'   => 12,
			]
		);

		$this->add_responsive_control(
			'columns',
			[
				'label'              => esc_html__( 'Columns', 'indostio' ),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 1,
				'max'                => 6,
				'step'				 => 1,
				'default'            => 3,
				'tablet_default' => 2,
				'mobile_default' => 1,
				'separator'          => 'after',
				'selectors' => [
					'{{WRAPPER}} .indostio-portfolio-grid__item' => 'max-width: calc( 100% / {{VALUE}} ); flex: 0 0 calc( 100% / {{VALUE}} );',
				],
			]
		);

		$this->add_control(
			'category',
			[
				'label'    => __( 'Category', 'indostio' ),
				'type'     => Controls_Manager::SELECT2,
				'options'  => \Indostio\Addons\Elementor\Utils::get_terms_options('indostio_portfolio_cat'),
				'default'  => '',
				'multiple' => true,
			]
		);

		$this->add_control(
			'orderby',
			[
				'label'      => esc_html__( 'Order By', 'indostio' ),
				'type'       => Controls_Manager::SELECT,
				'options'    => [
					'date'       => esc_html__( 'Date', 'indostio' ),
					'name'       => esc_html__( 'Name', 'indostio' ),
					'id'         => esc_html__( 'Ids', 'indostio' ),
					'rand' 		=> esc_html__( 'Random', 'indostio' ),
				],
				'default'    => 'date',
			]
		);

		$this->add_control(
			'order',
			[
				'label'      => esc_html__( 'Order', 'indostio' ),
				'type'       => Controls_Manager::SELECT,
				'options'    => [
					''     => esc_html__( 'Default', 'indostio' ),
					'ASC'  => esc_html__( 'Ascending', 'indostio' ),
					'DESC' => esc_html__( 'Descending', 'indostio' ),
				],
				'default'    => '',
			]
		);

		$this->add_control(
			'pagination',
			[
				'label'   => esc_html__( 'Pagination', 'indostio' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'none'     => esc_html__( 'None', 'indostio' ),
					'numberic' => esc_html__( 'Numberic', 'indostio' ),
				],
				'default'            => 'none',
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'image',
				'default'   => 'full',
				'separator' => 'before',
			]
		);


		$this->end_controls_section();

		// Style
		$this->start_controls_section(
			'section_style_portfolio_grid',
			[
				'label' => __( 'Portfolio Grid', 'indostio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'portfolio_grid_filter',
			[
				'label'   => __( 'Show Categories Filter', 'indostio' ),
				'type'    => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'indostio' ),
				'label_on'  => __( 'On', 'indostio' ),
				'default'   => 'yes',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$classes = [
			'indostio-portfolio-grid'
		];

		$this->add_render_attribute( 'wrapper', 'class', $classes );

		$output = array();
		$cate_filter = '';

		$args = array(
			'post_type'              => 'indostio_portfolio',
			'posts_per_page'         => $settings['limit'],
			'orderby'     			 => $settings['orderby'],
			'ignore_sticky_post'    => 1,
			'suppress_filters'       => false,
		
		);

		if ($settings['order'] != ''){
			$args['order'] = $settings['order'];
		}
		if ( $settings['category'] ) {
			$args['tax_query'] = array( 
				array(
				'taxonomy' => 'indostio_portfolio_cat',
				'field' => 'slug',
				'terms' => $settings['category'],
				'include_children' => false,
				) 
			);
		}

		if ( isset( $_GET['porfolio-page'] ) ) {
			$args['paged'] = isset( $_GET['porfolio-page'] ) ? absint( $_GET['porfolio-page'] ) : 1;
		}

		$portfolio = new \WP_Query( $args );

		if ( ! $portfolio->have_posts() ) {
			return '';
		}

		$index = 0;
		$cats = array();
		while ( $portfolio->have_posts() ) : $portfolio->the_post();
			$portfolio_url = array();

			$image = '';

			$portfolio_url['url'] = esc_url(get_permalink());
			$portfolio_url['is_external'] = $portfolio_url['nofollow'] = '';

			$key_img = 'img_'.$index;

			$portfolio_thumbnail_id = get_post_thumbnail_id( get_the_ID() );

			if ( $portfolio_thumbnail_id ) {

				$image_src = wp_get_attachment_image_src( $portfolio_thumbnail_id );

				$settings['image'] = array(
					'url' => $image_src ? $image_src[0] : '',
					'id'  => $portfolio_thumbnail_id
				);

				$image = Group_Control_Image_Size::get_attachment_image_html( $settings );
			}

			$output[] = sprintf(
				'<div class="%s">
					<a href="%s" class="indostio-portfolio-grid__link">
						<div class="indostio-portfolio-grid__image">%s%s</div>
						<div class="indostio-portfolio-grid__title">%s%s</div>
					</a>
				</div>',
				esc_attr( implode( ' ', get_post_class('indostio-portfolio-grid__item') ) ),
				esc_url( get_permalink() ),
				$image,
				\Indostio\Addons\Helper::get_svg('arrow-right'),
				get_the_title(),
				\Indostio\Addons\Helper::get_svg('arrow-right')

			);
			if( $settings['portfolio_grid_filter'] == 'yes' ) {
				$post_categories = wp_get_post_terms(get_the_ID(), 'indostio_portfolio_cat');
				if ( ! is_wp_error( $post_categories ) &&  $post_categories ) {
					foreach ($post_categories as $cat) {
						if (empty($cats[$cat->term_id])) {
							$cats[$cat->term_id] = true;
							$cate_filter .= sprintf('<li><a href="#" class="" data-filter=".indostio_portfolio_cat-%s">%s</a></li>', esc_attr($cat->slug), esc_html($cat->name));
						}
					}
				}
			}

		$index ++;
		endwhile;

		wp_reset_postdata();
		if( !empty( $cate_filter ) ) {
			echo '<ul class="indostio-portfolio-grid__cats">';
			echo '<li><a href="#" class="active" data-filter="*">' . esc_html__('Show All', 'indostio') . '</a></li>';
			echo $cate_filter;
			echo '</ul>';
		}
		echo sprintf(
			'<div %s>%s</div>',
			$this->get_render_attribute_string( 'wrapper' ),
			implode( '', $output )
		);

		$paginated = ! $portfolio->get( 'no_found_rows' );
		$current_page = $paginated ? (int) max( 1, $portfolio->get( 'paged', 1 ) ) : 1;

		if ( $settings['pagination'] == 'numberic' && $portfolio->max_num_pages > 1 ) {
			self::get_pagination( $portfolio->max_num_pages, $current_page );
		}
	}

	/**
	 * Products pagination.
	 */
	public static function get_pagination( $total_pages, $current_page ) {
		echo '<nav class="navigation indostio-pagination">';
		echo paginate_links(
			array( // WPCS: XSS ok.
				'base'      => esc_url_raw( add_query_arg( 'porfolio-page', '%#%', false ) ),
				'format'    => '?porfolio-page=%#%',
				'add_args'  => false,
				'current'   => max( 1, $current_page ),
				'total'     => $total_pages,
				'prev_text' => '<span class="indostio-svg-icon"><svg width="9" height="15" viewBox="0 0 9 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.318359 7.33667C0.0546875 7.60034 0.0546875 7.96948 0.318359 8.23315L6.48828 14.3503C6.75195 14.614 7.17383 14.614 7.38477 14.3503L7.75391 13.9812C8.01758 13.7175 8.01758 13.3484 7.75391 13.0847L2.375 7.75854L7.80664 2.48511C8.01758 2.22144 8.01758 1.85229 7.80664 1.58862L7.38477 1.21948C7.17383 0.955811 6.75195 0.955811 6.48828 1.21948L0.318359 7.33667Z" fill="currentColor"/></svg></span>',
				'next_text' => '<span class="indostio-svg-icon"><svg width="9" height="15" viewBox="0 0 9 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.68164 7.33667C8.94531 7.60034 8.94531 7.96948 8.68164 8.23315L2.51172 14.3503C2.24805 14.614 1.82617 14.614 1.61523 14.3503L1.24609 13.9812C0.982422 13.7175 0.982422 13.3484 1.24609 13.0847L6.625 7.75854L1.19336 2.48511C0.982422 2.22144 0.982422 1.85229 1.19336 1.58862L1.61523 1.21948C1.82617 0.955811 2.24805 0.955811 2.51172 1.21948L8.68164 7.33667Z" fill="currentColor"/></svg></span>',
				'type'      => 'plain',
			)
		);
		echo '</nav>';
	}
}