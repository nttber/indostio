<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Indostio\Addons\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor Image Box Grid widget.
 *
 * Elementor widget that displays an eye-catching headlines.
 *
 * @since 1.0.0
 */
class Testimonial_Carousel extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Image Box widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-testimonial-carousel';
	}

	/**
	 * Get widget title
	 *
	 * Retrieve Image Box widget title
	 *
	 * @return string Widget title
	 */
	public function get_title() {
		return __( '[Indostio] Testimonial Carousel', 'indostio' );
	}

	/**
	 * Get widget icon
	 *
	 * Retrieve Image Box widget icon
	 *
	 * @return string Widget icon
	 */
	public function get_icon() {
		return 'eicon-testimonial-carousel';
	}

	/**
	 * Get widget categories
	 *
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return string Widget categories
	 */
	public function get_categories() {
		return [ 'indostio' ];
	}

	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'testimonial carousel', 'carousel', 'testimonial', 'indostio' ];
	}


	/**
	 * Register heading widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->section_content();
		$this->section_style();
	}

	// Tab Content
	protected function section_content() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'indostio' ),
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'testimonial_content',
			[
				'label' => __( 'Content', 'indostio' ),
				'type' => Controls_Manager::TEXTAREA,
				'dynamic' => [
					'active' => true,
				],
				'rows' => '10',
				'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'indostio' ),
			]
		);


		$repeater->add_control(
			'testimonial_name',
			[
				'label' => __( 'Name', 'indostio' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'John Doe', 'indostio' ),
				'label_block' => true,
				'separator' => 'before',
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'testimonial_company',
			[
				'label' => __( 'Company/Title', 'indostio' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Company Name', 'indostio' ),
				'label_block' => true,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'testimonial_rating',
			[
				'label'   => esc_html__( 'Rating', 'indostio' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'0'    => __( 'None', 'indostio' ),
					'1'    => __( '1 Star', 'indostio' ),
					'2'    => __( '2 Stars', 'indostio' ),
					'3'    => __( '3 Stars', 'indostio' ),
					'4'    => __( '4 Stars', 'indostio' ),
					'5'    => __( '5 Stars', 'indostio' ),
				],
				'default'            => 5,
			]
		);

		$this->add_control(
			'testimonials',
			[
				'label'       => __( 'Testimonials', 'indostio' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ testimonial_name }}}',
				'default' => [
					[
						'testimonial_name'    => __( 'Name #1', 'indostio' ),
						'testimonial_company' => __( 'Company #1', 'indostio' ),
					],
					[
						'testimonial_name'    => __( 'Name #2', 'indostio' ),
						'testimonial_company' => __( 'Company #2', 'indostio' ),
					],
					[
						'testimonial_name'    => __( 'Name #3', 'indostio' ),
						'testimonial_company' => __( 'Company #3', 'indostio' ),
					],
					[
						'testimonial_name'    => __( 'Name #4', 'indostio' ),
						'testimonial_company' => __( 'Company #4', 'indostio' ),
					]
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'quoter_icon',
			[
				'label' => __( 'Quoter Icon', 'indostio' ),
				'type' => Controls_Manager::ICONS,
				'default' => [],
			]
		);

		$this->add_control(
			'name_company_display',
			[
				'label'   => esc_html__( 'Name and Company Display', 'indostio' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'row'             => esc_html__( 'Same Row', 'indostio' ),
					'rows'             => esc_html__( '2 Rows', 'indostio' ),
				],
				'default'            => 'row',
			]
		);

		$this->end_controls_section();

		$this->section_content_carousel();
	}

	protected function section_content_carousel() {
		$this->start_controls_section(
			'section_products_carousel',
			[
				'label' => __( 'Carousel Settings', 'indostio' ),
			]
		);

		$this->add_responsive_control(
			'slides_to_show',
			[
				'label'              => esc_html__( 'Slides to show', 'indostio' ),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 1,
				'max'                => 10,
				'default'            => 1,
				'frontend_available' => true,
				'separator'          => 'before',
			]
		);

		$this->add_responsive_control(
			'slides_to_scroll',
			[
				'label'              => esc_html__( 'Slides to scroll', 'indostio' ),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 1,
				'max'                => 10,
				'default'            => 1,
				'frontend_available' => true,
			]
		);

		$this->add_responsive_control(
			'navigation',
			[
				'label'   => esc_html__( 'Navigation', 'indostio' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'dots'             => esc_html__( 'Dots', 'indostio' ),
					'none'             => esc_html__( 'None', 'indostio' ),
				],
				'default'            => 'dots',
				'toggle'             => false,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'     => __( 'Autoplay', 'indostio' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'indostio' ),
				'label_on'  => __( 'On', 'indostio' ),
				'default'   => 'yes',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'autoplay_speed',
			[
				'label'   => __( 'Autoplay Speed', 'indostio' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3000,
				'min'     => 100,
				'step'    => 100,
				'frontend_available' => true,
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'pause_on_hover',
			[
				'label'   => __( 'Pause on Hover', 'indostio' ),
				'type'    => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'indostio' ),
				'label_on'  => __( 'On', 'indostio' ),
				'default'   => 'yes',
				'frontend_available' => true,
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'speed',
			[
				'label'       => __( 'Animation Speed', 'indostio' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 800,
				'min'         => 100,
				'step'        => 50,
				'frontend_available' => true,
			]
		);

		$this->end_controls_section();
	}

	// Tab Style
	protected function section_style() {
		$this->section_style_general();
		$this->section_style_item();
		$this->section_style_carousel();
	}

	protected function section_style_general() {
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => __( 'Content', 'indostio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'                => esc_html__( 'Alignment', 'indostio' ),
				'type'                 => Controls_Manager::CHOOSE,
				'options'              => [
					'left'   => [
						'title' => esc_html__( 'Left', 'indostio' ),
						'icon' 	=> 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'indostio' ),
						'icon' 	=> 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'indostio' ),
						'icon' 	=> 'fa fa-align-right',
					],
				],
				'default'              => '',
			]
		);

		$this->add_responsive_control(
			'space_between',
			[
				'label' => __( 'Gap', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'default' => [
					'size' => 75
				],
				'frontend_available' => true,
			]
		);

		$this->end_controls_section();
	}

	protected function section_style_item() {
		$this->start_controls_section(
			'section_style_item',
			[
				'label' => __( 'Testimonial Item', 'indostio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'content_item_padding',
			[
				'label'      => esc_html__( 'Padding', 'indostio' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .indostio-testimonial__item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'.indostio-rtl-smart {{WRAPPER}} .indostio-testimonial__item' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'content_item_content_heading',
			[
				'label' => esc_html__( 'Content', 'indostio' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'content_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'indostio' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .indostio-testimonial__content' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'content_item_content_color',
			[
				'label'     => esc_html__( 'Color', 'indostio' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .indostio-testimonial__content' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_item_content_typo',
				'selector' => '{{WRAPPER}} .indostio-testimonial__content',
			]
		);

		$this->add_responsive_control(
			'content_item_content_padding',
			[
				'label'     => __( 'Padding Bottom', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 200,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-testimonial__content' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_item_content_margin',
			[
				'label'     => __( 'Margin Bottom', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 200,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-testimonial__content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'content_item_name_heading',
			[
				'label' => esc_html__( 'Name', 'indostio' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'content_item_name_color',
			[
				'label'     => esc_html__( 'Color', 'indostio' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .indostio-testimonial__name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_item_name_typo',
				'selector' => '{{WRAPPER}} .indostio-testimonial__name',
			]
		);


		$this->add_control(
			'content_item_company_heading',
			[
				'label' => esc_html__( 'Company', 'indostio' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'content_item_company_color',
			[
				'label'     => esc_html__( 'Color', 'indostio' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .indostio-testimonial__company' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_item_company_typo',
				'selector' => '{{WRAPPER}} .indostio-testimonial__company',
			]
		);


		$this->add_control(
			'content_item_rating_heading',
			[
				'label' => esc_html__( 'Rating', 'indostio' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'content_item_rating_color',
			[
				'label'     => esc_html__( 'Color', 'indostio' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .indostio-testimonial__rating .user-rating' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function section_style_carousel() {
		$this->start_controls_section(
			'section_style',
			[
				'label'     => __( 'Carousel', 'indostio' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		// Dots
		$this->add_control(
			'dots_style_heading',
			[
				'label' => esc_html__( 'Dots', 'indostio' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'dots_position',
			[
				'label' => __( 'Position', 'indostio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'static' => __( 'Static', 'indostio' ),
					'absolute' => __( 'Absolute', 'indostio' ),
				],
				'default' => 'static',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullets' => 'position: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'dots_position_right',
			[
				'label'     => __( 'Right', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 500,
						'min' => -500,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullets' => 'right: {{SIZE}}{{UNIT}};left:auto;',
				],
				'condition' => [
					'dots_position' => 'absolute',
				],
			]
		);

		$this->add_responsive_control(
			'dots_position_bottom',
			[
				'label'     => __( 'Bottom', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 500,
						'min' => -500,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullets' => 'Bottom: {{SIZE}}{{UNIT}};left:auto;',
				],
				'condition' => [
					'dots_position' => 'absolute',
				],
			]
		);
		
		$this->add_responsive_control(
			'dots_padding',
			[
				'label'      => esc_html__( 'Padding', 'indostio' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .swiper-pagination-bullets' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'dots_bg_color',
			[
				'label'     => esc_html__( 'BackgroundColor', 'indostio' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullets' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'dots_color',
			[
				'label'     => esc_html__( 'Color', 'indostio' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullet:before' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'dots_active_color',
			[
				'label'     => esc_html__( 'Active Color', 'indostio' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullet-active' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .swiper-pagination-bullet-active:before' => 'background-color: {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'sliders_dots_vertical_spacing',
			[
				'label'     => esc_html__( 'Spacing', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 1000,
						'min' => 0,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .indostio-testimonial-carousel--elementor .swiper-pagination' => 'margin-top: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'dots_position' => 'static',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render heading widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$nav        = $settings['navigation'];
		$nav_tablet = empty( $settings['navigation_tablet'] ) ? $nav : $settings['navigation_tablet'];
		$nav_mobile = empty( $settings['navigation_mobile'] ) ? $nav : $settings['navigation_mobile'];

		$classes = [
			'indostio-testimonial-carousel--elementor',
			'indostio-carousel--elementor',
			'indostio-swiper-carousel-elementor',
			'indostio-carousel--swiper',
			'navigation-' . $nav,
			'navigation-tablet-' . $nav_tablet,
			'navigation-mobile-' . $nav_mobile,
			'indostio-testimonial-carousel--align-' . $settings['alignment'],
			'indostio-testimonial-carousel--footer-' . $settings['name_company_display'],
		];

		$this->add_render_attribute( 'wrapper', 'class', $classes );

		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<div class="indostio-testimonial__list swiper-container">
				<div class="indostio-testimonial__inner swiper-wrapper">
					<?php
					foreach( $settings['testimonials'] as $index => $slide ) {
						$wrapper_key = $this->get_repeater_setting_key( 'slide_wrapper', 'testimonial', $index );
						$name_key    = $this->get_repeater_setting_key( 'name', 'testimonial', $index );
						$company_key = $this->get_repeater_setting_key( 'company', 'testimonial', $index );
						$desc_key    = $this->get_repeater_setting_key( 'desc', 'testimonial', $index );
						$rating_key    = $this->get_repeater_setting_key( 'rating', 'testimonial', $index );

						$this->add_render_attribute( $wrapper_key, 'class', [ 'indostio-testimonial__item', 'swiper-slide' ] );
						$this->add_render_attribute( $name_key, 'class', 'indostio-testimonial__name' );
						$this->add_render_attribute( $company_key, 'class', 'indostio-testimonial__company' );
						$this->add_render_attribute( $desc_key, 'class', 'indostio-testimonial__content' );
						$this->add_render_attribute( $rating_key, 'class', [ 'indostio-testimonial__rating', 'star-rating' ] );

						$name 		= $slide['testimonial_name'] ? '<div ' . $this->get_render_attribute_string( $name_key ) . '>'. esc_html( $slide['testimonial_name'] ) .'</div>' : '';
						$content 	= $slide['testimonial_content'] ? '<div ' . $this->get_render_attribute_string( $desc_key ) . '>'. wp_kses_post( $slide['testimonial_content'] ) .'</div>' : '';
						$rating 	= $slide['testimonial_rating'] ? '<div ' . $this->get_render_attribute_string( $rating_key ) . '>'. $this->star_rating_html( $slide['testimonial_rating'] ) .'</div>' : '';
						$company 	= $slide['testimonial_company'] ? '<div ' . $this->get_render_attribute_string( $company_key ) . '>'. $slide['testimonial_company'] .'</div>' : '';
						?>
						<div <?php $this->print_render_attribute_string( $wrapper_key ); ?>>
							<?php echo $rating; ?>
							<?php echo $content; ?>
							<div class="indostio-testimonial__footer">
								<?php
								if( ! empty( $settings['quoter_icon'] ) && ! empty( $settings['quoter_icon']['value'] ) ) {
									echo '<div class="indostio-svg-icon">';
										\Elementor\Icons_Manager::render_icon( $settings['quoter_icon'], [ 'aria-hidden' => 'true' ] );
									echo '</div>';
								} else {
								?>
								<div class="indostio-svg-icon">
									<svg width="34" height="27" viewBox="0 0 34 27" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M29.5312 11.875H26.25V11.4062C26.25 10.1172 27.2461 9.0625 28.5938 9.0625H29.0625C30.5859 9.0625 31.875 7.83203 31.875 6.25V3.4375C31.875 1.91406 30.5859 0.625 29.0625 0.625H28.5938C22.6172 0.625 17.8125 5.48828 17.8125 11.4062V22.6562C17.8125 25 19.6875 26.875 22.0312 26.875H29.5312C31.8164 26.875 33.75 25 33.75 22.6562V16.0938C33.75 13.8086 31.8164 11.875 29.5312 11.875ZM30.9375 22.6562C30.9375 23.4766 30.293 24.0625 29.5312 24.0625H22.0312C21.2109 24.0625 20.625 23.4766 20.625 22.6562V11.4062C20.625 7.01172 24.1992 3.4375 28.5938 3.4375H29.0625V6.25H28.5938C25.7227 6.25 23.4375 8.59375 23.4375 11.4062V14.6875H29.5312C30.293 14.6875 30.9375 15.332 30.9375 16.0938V22.6562ZM11.7188 11.875H8.4375V11.4062C8.4375 10.1172 9.43359 9.0625 10.7812 9.0625H11.25C12.7734 9.0625 14.0625 7.83203 14.0625 6.25V3.4375C14.0625 1.91406 12.7734 0.625 11.25 0.625H10.7812C4.80469 0.625 0 5.48828 0 11.4062V22.6562C0 25 1.875 26.875 4.21875 26.875H11.7188C14.0039 26.875 15.9375 25 15.9375 22.6562V16.0938C15.9375 13.8086 14.0039 11.875 11.7188 11.875ZM13.125 22.6562C13.125 23.4766 12.4805 24.0625 11.7188 24.0625H4.21875C3.39844 24.0625 2.8125 23.4766 2.8125 22.6562V11.4062C2.8125 7.01172 6.38672 3.4375 10.7812 3.4375H11.25V6.25H10.7812C7.91016 6.25 5.625 8.59375 5.625 11.4062V14.6875H11.7188C12.4805 14.6875 13.125 15.332 13.125 16.0938V22.6562Z" fill="currentColor"/></svg>
								</div>
								<?php } ?>
								<?php echo $name; ?>
								<?php echo $company; ?>
							</div>
						</div>
						<?php
					}
					?>
				</div>
			</div>
			<div class="swiper-pagination"></div>
		</div>
		<?php
	}

	public function star_rating_html( $count ) {
		$html = '<span class="max-rating rating-stars">'
		        . \Indostio\Addons\Helper::get_svg( 'star' )
		        . \Indostio\Addons\Helper::get_svg( 'star' )
		        . \Indostio\Addons\Helper::get_svg( 'star' )
		        . \Indostio\Addons\Helper::get_svg( 'star' )
		        . \Indostio\Addons\Helper::get_svg( 'star' )
		        . '</span>';
		$html .= '<span class="user-rating rating-stars" style="width:' . ( ( $count / 5 ) * 100 ) . '%">'
				. \Indostio\Addons\Helper::get_svg( 'star' )
				. \Indostio\Addons\Helper::get_svg( 'star' )
				. \Indostio\Addons\Helper::get_svg( 'star' )
				. \Indostio\Addons\Helper::get_svg( 'star' )
				. \Indostio\Addons\Helper::get_svg( 'star' )
		         . '</span>';

		$html .= '<span class="screen-reader-text">';

		$html .= '</span>';

		return $html;
	}

}