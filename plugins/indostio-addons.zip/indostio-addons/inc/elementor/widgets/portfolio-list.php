<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Stack;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Indostio\Addons\Helper;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Icon Box widget
 */
class Portfolio_List extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-portfolio-list';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Indostio] Portfolio List', 'indostio' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-post-list';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return ['indostio'];
	}


	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'portfolio list', 'portfolio', 'list', 'indostio' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_portfolio_list',
			[ 'label' => __( 'Portfolio List', 'indostio' ) ]
		);

		$this->add_control(
			'limit',
			[
				'label'     => __( 'Total', 'indostio' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => -1,
				'max'       => 100,
				'step'      => 1,
				'default'   => 12,
			]
		);

		$this->add_control(
			'category',
			[
				'label'    => __( 'Category', 'indostio' ),
				'type'     => Controls_Manager::SELECT2,
				'options'  => \Indostio\Addons\Elementor\Utils::get_terms_options('indostio_portfolio_cat'),
				'default'  => '',
				'multiple' => true,
			]
		);

		$this->add_control(
			'orderby',
			[
				'label'      => esc_html__( 'Order By', 'indostio' ),
				'type'       => Controls_Manager::SELECT,
				'options'    => [
					'date'       => esc_html__( 'Date', 'indostio' ),
					'name'       => esc_html__( 'Name', 'indostio' ),
					'id'         => esc_html__( 'Ids', 'indostio' ),
					'rand' 		=> esc_html__( 'Random', 'indostio' ),
				],
				'default'    => 'date',
			]
		);

		$this->add_control(
			'order',
			[
				'label'      => esc_html__( 'Order', 'indostio' ),
				'type'       => Controls_Manager::SELECT,
				'options'    => [
					''     => esc_html__( 'Default', 'indostio' ),
					'ASC'  => esc_html__( 'Ascending', 'indostio' ),
					'DESC' => esc_html__( 'Descending', 'indostio' ),
				],
				'default'    => '',
			]
		);

		$this->add_control(
			'pagination',
			[
				'label'   => esc_html__( 'Pagination', 'indostio' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'none'     => esc_html__( 'None', 'indostio' ),
					'numberic' => esc_html__( 'Numberic', 'indostio' ),
				],
				'default'            => 'none',
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'image',
				'default'   => 'full',
				'separator' => 'before',
			]
		);


		$this->end_controls_section();

	}

	/**
	 * Render widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$classes = [
			'indostio-portfolio-list'
		];

		$this->add_render_attribute( 'wrapper', 'class', $classes );

		$output = array();

		$args = array(
			'post_type'              => 'indostio_portfolio',
			'posts_per_page'         => $settings['limit'],
			'orderby'     			 => $settings['orderby'],
			'ignore_sticky_post'    => 1,
			'suppress_filters'       => false,
		
		);

		if ($settings['order'] != ''){
			$args['order'] = $settings['order'];
		}
		if ( $settings['category'] ) {
			$args['tax_query'] = array( 
				array(
				'taxonomy' => 'indostio_portfolio_cat',
				'field' => 'slug',
				'terms' => $settings['category'],
				'include_children' => false,
				) 
			);
		}

		if ( isset( $_GET['porfolio-page'] ) ) {
			$args['paged'] = isset( $_GET['porfolio-page'] ) ? absint( $_GET['porfolio-page'] ) : 1;
		}

		$portfolio = new \WP_Query( $args );

		if ( ! $portfolio->have_posts() ) {
			return '';
		}

		$index = 0;
		while ( $portfolio->have_posts() ) : $portfolio->the_post();
			$portfolio_url = array();

			$image = '';
			$content = '';
			$portfolio_url['url'] = esc_url(get_permalink());
			$portfolio_url['is_external'] = $portfolio_url['nofollow'] = '';

			$key_img = 'img_'.$index;

			$portfolio_thumbnail_id = get_post_thumbnail_id( get_the_ID() );

			if ( $portfolio_thumbnail_id ) {

				$image_src = wp_get_attachment_image_src( $portfolio_thumbnail_id );

				$settings['image'] = array(
					'url' => $image_src ? $image_src[0] : '',
					'id'  => $portfolio_thumbnail_id
				);

				$image = Group_Control_Image_Size::get_attachment_image_html( $settings );
			}
			$post_categories = wp_get_post_terms(get_the_ID(), 'indostio_portfolio_cat');
			if ( ! is_wp_error( $post_categories ) &&  $post_categories ) {
				$content .= sprintf('<a href="%s" class="indostio-portfolio-list__cat">%s</a>', esc_url(get_term_link($post_categories[0]->term_id, 'indostio_portfolio_cat')), $post_categories[0]->name);
			}
			$icon = '<span class="indostio-svg-icon"><svg width="106" height="107" viewBox="0 0 106 107" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M70.1504 32.2899L70.8575 32.997L72.5646 31.2899H70.1504V32.2899ZM74.1417 36.2812L75.1417 36.2784L75.1349 33.8737L73.4346 35.5741L74.1417 36.2812ZM74.2591 78.1897L75.2591 78.1897L75.2591 78.1869L74.2591 78.1897ZM25.3636 28.6508L25.3636 30.2943L27.3636 30.2943V28.6508L25.3636 28.6508ZM25.3636 30.2943C25.3636 31.1208 25.657 31.8823 26.2141 32.4394C26.7713 32.9966 27.5328 33.2899 28.3593 33.2899L28.3593 31.2899C28.0119 31.2899 27.7756 31.1724 27.6283 31.0252C27.4811 30.878 27.3636 30.6417 27.3636 30.2943L25.3636 30.2943ZM28.3593 33.2899L70.1504 33.2899V31.2899L28.3593 31.2899L28.3593 33.2899ZM69.4433 31.5828L25.4217 75.6044L26.836 77.0186L70.8575 32.997L69.4433 31.5828ZM25.4217 75.6044C24.1719 76.8542 24.3655 78.7797 25.4217 79.836L26.836 78.4217C26.4835 78.0693 26.4423 77.4123 26.836 77.0186L25.4217 75.6044ZM25.4217 79.836L26.5957 81.0099L28.0099 79.5957L26.836 78.4217L25.4217 79.836ZM26.5957 81.0099C27.8079 82.2221 29.615 82.2221 30.8272 81.0099L29.413 79.5957C28.9818 80.0269 28.4411 80.0269 28.0099 79.5957L26.5957 81.0099ZM30.8272 81.0099L74.8488 36.9883L73.4346 35.5741L29.413 79.5957L30.8272 81.0099ZM73.1417 36.284L73.2591 78.1925L75.2591 78.1869L75.1417 36.2784L73.1417 36.284ZM73.2591 78.1897C73.2591 79.0162 73.5524 79.7777 74.1096 80.3349C74.6667 80.892 75.4282 81.1854 76.2547 81.1854V79.1854C75.9073 79.1854 75.671 79.0679 75.5238 78.9207C75.3766 78.7734 75.2591 78.5371 75.2591 78.1897H73.2591ZM76.2547 81.1854H77.8982V79.1854H76.2547V81.1854ZM77.8982 81.1854C78.7247 81.1854 79.4862 80.892 80.0433 80.3349C80.6004 79.7778 80.8938 79.0162 80.8938 78.1897H78.8938C78.8938 78.5371 78.7763 78.7734 78.6291 78.9207C78.4819 79.0679 78.2456 79.1854 77.8982 79.1854V81.1854ZM80.8938 78.1897V28.6508H78.8938V78.1897H80.8938ZM80.8938 28.6508C80.8938 27.8243 80.6004 27.0628 80.0433 26.5057C79.4862 25.9486 78.7247 25.6552 77.8982 25.6552V27.6552C78.2456 27.6552 78.4819 27.7727 78.6291 27.9199C78.7763 28.0671 78.8938 28.3034 78.8938 28.6508H80.8938ZM77.8982 25.6552L28.3593 25.6552L28.3593 27.6552L77.8982 27.6552V25.6552ZM28.3593 25.6552C27.5328 25.6552 26.7712 25.9486 26.2141 26.5057C25.657 27.0628 25.3636 27.8243 25.3636 28.6508L27.3636 28.6508C27.3636 28.3034 27.4811 28.0671 27.6283 27.9199C27.7756 27.7727 28.0119 27.6552 28.3593 27.6552L28.3593 25.6552Z" fill="currentColor"/></svg></span>';
			$content .= sprintf('<a href="%s" class="indostio-portfolio-list__title">%s</a>', esc_url( get_permalink() ), get_the_title());
			$content .= sprintf('<a href="%s" class="indostio-portfolio-list__button">%s%s</a>', esc_url( get_permalink() ), esc_html__('Read More', 'indostio'), \Indostio\Addons\Helper::get_svg('arrow'));
			$output[] = sprintf(
				'<div class="%s">
					<div class="indostio-portfolio-list__content">
					%s
					</div>
					<a href="%s" class="indostio-portfolio-list__image">%s%s</a>
				</div>',
				esc_attr( implode( ' ', get_post_class('indostio-portfolio-list__item') ) ),
				$content,
				esc_url( get_permalink() ),
				$image,
				$icon
			);

		$index ++;
		endwhile;

		wp_reset_postdata();
		echo sprintf(
			'<div %s>%s</div>',
			$this->get_render_attribute_string( 'wrapper' ),
			implode( '', $output )
		);

		$paginated = ! $portfolio->get( 'no_found_rows' );
		$current_page = $paginated ? (int) max( 1, $portfolio->get( 'paged', 1 ) ) : 1;

		if ( $settings['pagination'] == 'numberic' && $portfolio->max_num_pages > 1 ) {
			self::get_pagination( $portfolio->max_num_pages, $current_page );
		}
	}

	/**
	 * Products pagination.
	 */
	public static function get_pagination( $total_pages, $current_page ) {
		echo '<nav class="navigation indostio-pagination">';
		echo paginate_links(
			array( // WPCS: XSS ok.
				'base'      => esc_url_raw( add_query_arg( 'porfolio-page', '%#%', false ) ),
				'format'    => '?porfolio-page=%#%',
				'add_args'  => false,
				'current'   => max( 1, $current_page ),
				'total'     => $total_pages,
				'prev_text' => '<span class="indostio-svg-icon"><svg width="9" height="15" viewBox="0 0 9 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.318359 7.33667C0.0546875 7.60034 0.0546875 7.96948 0.318359 8.23315L6.48828 14.3503C6.75195 14.614 7.17383 14.614 7.38477 14.3503L7.75391 13.9812C8.01758 13.7175 8.01758 13.3484 7.75391 13.0847L2.375 7.75854L7.80664 2.48511C8.01758 2.22144 8.01758 1.85229 7.80664 1.58862L7.38477 1.21948C7.17383 0.955811 6.75195 0.955811 6.48828 1.21948L0.318359 7.33667Z" fill="currentColor"/></svg></span>',
				'next_text' => '<span class="indostio-svg-icon"><svg width="9" height="15" viewBox="0 0 9 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.68164 7.33667C8.94531 7.60034 8.94531 7.96948 8.68164 8.23315L2.51172 14.3503C2.24805 14.614 1.82617 14.614 1.61523 14.3503L1.24609 13.9812C0.982422 13.7175 0.982422 13.3484 1.24609 13.0847L6.625 7.75854L1.19336 2.48511C0.982422 2.22144 0.982422 1.85229 1.19336 1.58862L1.61523 1.21948C1.82617 0.955811 2.24805 0.955811 2.51172 1.21948L8.68164 7.33667Z" fill="currentColor"/></svg></span>',
				'type'      => 'plain',
			)
		);
		echo '</nav>';
	}
}