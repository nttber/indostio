<?php
namespace Indostio\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Indostio\Addons\Helper;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor heading widget.
 *
 * Elementor widget that displays an eye-catching headlines.
 *
 * @since 1.0.0
 */
class Special_Text extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve heading widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'indostio-special-text';
	}

	/**
	 * Get widget title
	 *
	 * Retrieve heading widget title
	 *
	 * @return string Widget title
	 */
	public function get_title() {
		return __( '[Indostio] Special Text', 'indostio' );
	}

	/**
	 * Get widget icon
	 *
	 * Retrieve heading widget icon
	 *
	 * @return string Widget icon
	 */
	public function get_icon() {
		return 'eicon-t-letter';
	}

	/**
	 * Get widget categories
	 *
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return string Widget categories
	 */
	public function get_categories() {
		return [ 'indostio' ];
	}

	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'heading', 'special', 'text', 'indostio' ];
	}

	/**
	 * Register heading widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'indostio' ),
			]
		);

		$this->add_control(
			'text_type',
			[
				'label' => __( 'Text Type', 'indostio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'icon' => __( 'Icon', 'indostio' ),
					'image' => __( 'Text & Image', 'indostio' ),
				],
				'default' => 'icon',
			]
		);

		$this->add_control(
			'icon',
			[
				'label' => __( 'Icon', 'indostio' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fa fa-star',
					'library' => 'fa-solid',
				],
				'condition' => [
					'text_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'image',
			[
				'label' => __( 'Choose Image', 'indostio' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
				],
				'condition' => [
					'text_type' => 'image',
				],
				'selectors'  => [
					'{{WRAPPER}} .indostio-special-text' => 'background-image: url("{{URL}}");',
				],
			]
		);

		$this->add_responsive_control(
			'background_position',
			[
				'label'     => esc_html__( 'Background Position', 'indostio' ),
				'type'      => Controls_Manager::SELECT,
				'responsive' => true,
				'options'   => [
					''              => esc_html__( 'Default', 'indostio' ),
					'left top'      => esc_html__( 'Left Top', 'indostio' ),
					'left center'   => esc_html__( 'Left Center', 'indostio' ),
					'left bottom'   => esc_html__( 'Left Bottom', 'indostio' ),
					'right top'     => esc_html__( 'Right Top', 'indostio' ),
					'right center'  => esc_html__( 'Right Center', 'indostio' ),
					'right bottom'  => esc_html__( 'Right Bottom', 'indostio' ),
					'center top'    => esc_html__( 'Center Top', 'indostio' ),
					'center center' => esc_html__( 'Center Center', 'indostio' ),
					'center bottom' => esc_html__( 'Center Bottom', 'indostio' ),
					'initial' 		=> esc_html__( 'Custom', 'indostio' ),
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .indostio-special-text' => 'background-position: {{VALUE}};',
				],
				'condition' => [
					'text_type' => 'image',
				],
			]
		);

		$this->add_control(
			'text',
			[
				'label' => __( 'Text', 'indostio' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => '',
				'condition' => [
					'text_type' => 'image',
				],
			]
		);
		

		$this->end_controls_section();

		// Style before Title
		$this->start_controls_section(
			'section_style_content',
			[
				'label'     => __( 'Content', 'indostio' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => esc_html__( 'Padding', 'indostio' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .indostio-special-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'__width',
			[
				'label' => esc_html__( 'Width', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'range' => [
					'px' => [
						'min' => 6,
					],
					'%' => [
						'min' => 6,
					],
					'vw' => [
						'min' => 6,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-special-text'=>'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'__height',
			[
				'label' => esc_html__( 'Height', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'range' => [
					'px' => [
						'min' => 6,
					],
					'%' => [
						'min' => 6,
					],
					'vw' => [
						'min' => 6,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .indostio-special-text'=>'height: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_responsive_control(
			'align',
			[
				'label' => __( 'Alignment', 'indostio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'indostio' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'indostio' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'indostio' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .indostio-special-text' => 'text-align:{{VALUE}}',
				],
			]
		);
		$this->add_control(
			'border_primary_color',
			[
				'label' => __( 'Border Primary Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-special-text' => '--id-special-text-bc-primary: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'border_secondary_color',
			[
				'label' => __( 'Border Secondary Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-special-text' => '--id-special-text-bc-secondary: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'icon_heading',
			[
				'label' => __( 'Icon', 'indostio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'text_type' => 'icon',
				],
			]
		);
		$this->add_control(
			'icon_color',
			[
				'label' => __( 'Icon Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-special-text__icon' => 'color: {{VALUE}};',
				],
				'condition' => [
					'text_type' => 'icon',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label' => __( 'Size', 'indostio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					]
				],
				'default' => [],
				'selectors' => [
					'{{WRAPPER}} .indostio-special-text__icon' => 'font-size: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'text_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .indostio-special-text' => 'color: {{VALUE}};',
				],
				'condition' => [
					'text_type' => 'image',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'selector' => '{{WRAPPER}} .indostio-special-text',
				'condition' => [
					'text_type' => 'image',
				],
			]
		);
		

		$this->end_controls_section();

	}

	/**
	 * Render heading widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'wrapper', 'class', [ 'indostio-special-text', 'indostio-special-text-type--' .  $settings['text_type']] );

		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
				<?php 
				if ( 'icon' == $settings['text_type'] ) {
					echo '<div class="indostio-special-text__icon indostio-svg-icon">';
						\Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] );
					echo '</div>';
				} else {
					echo '<div class="indostio-special-text__image">';
						echo $settings['text'];
					echo '</div>';
				} ?>
			</div>
		<?php
	}
}