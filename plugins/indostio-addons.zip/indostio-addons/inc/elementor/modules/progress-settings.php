<?php
namespace Indostio\Addons\Elementor\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Core\Base\Module;
use Elementor\Controls_Manager;

class Progress_Settings extends Module {
	/**
	 * Get module name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'progress-settings';
	}

	/**
	 * Module constructor.
	 */
	public function __construct() {
		add_action( 'elementor/element/progress/section_progress_style/before_section_end', [ $this, 'register_percent_controls' ] );
	}

	/**
	 * @param $element    Controls_Stack
	 */
	public function register_percent_controls( $element ) {
		$element->add_control(
			'heading_percentage',
			[
				'label' => __( 'Percentage', 'indostio' ),
				'type' => Controls_Manager::HEADING,
			]
		);

		$element->add_control(
			'percentage_top',
			[
				'label'     => __( 'Top', 'indostio' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 200,
						'min' => -200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-progress-percentage' => 'transform: translateY({{SIZE}}{{UNIT}});',
				],
			]
		);

		$element->add_control(
			'percentage_color',
			[
				'label' => __( 'Color', 'indostio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-progress-percentage' => 'color: {{VALUE}};',
				],
			]
		);

		$element->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'percentage_typography',
				'selector' => '{{WRAPPER}} .elementor-progress-percentage',
			]
		);

	}

}