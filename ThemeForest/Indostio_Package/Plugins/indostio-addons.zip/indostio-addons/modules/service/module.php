<?php
/**
 * Indostio Addons Modules functions and definitions.
 *
 * @package Indostio
 */

namespace Indostio\Addons\Modules\Service;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Addons Modules
 */
class Module {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		$this->includes();
		add_action('init', array( $this, 'actions'));
	}

	/**
	 * Includes files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function includes() {
		\Indostio\Addons\Auto_Loader::register( [
			'Indostio\Addons\Modules\Service\Settings'    	=> INDOSTIO_ADDONS_DIR . 'modules/service/settings.php',
			'Indostio\Addons\Modules\Service\Post_Type'    => INDOSTIO_ADDONS_DIR . 'modules/service/post-type.php',
		] );
	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function actions() {
		\Indostio\Addons\Modules\Service\Post_Type::instance();

		if( is_admin() ) {
			\Indostio\Addons\Modules\Service\Settings::instance();
		}

	}

}
