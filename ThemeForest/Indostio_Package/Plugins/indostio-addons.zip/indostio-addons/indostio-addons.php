<?php
/**
 * Plugin Name: Indostio Addons
 * Plugin URI: http://steelthemes.com/plugins/indostio-addons.zip
 * Description: Extra elements for Elementor. It was built for Indostio theme.
 * Version: 1.0.0
 * Author: SteelThemes
 * Author URI: http://steelthemes.com
 * License: GPL2+
 * Text Domain: indostio
 * Domain Path: /lang/
 */
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

if ( ! defined( 'INDOSTIO_ADDONS_VER' ) ) {
	define( 'INDOSTIO_ADDONS_VER', '1.0.0' );
}

if ( ! defined( 'INDOSTIO_ADDONS_DIR' ) ) {
	define( 'INDOSTIO_ADDONS_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'INDOSTIO_ADDONS_URL' ) ) {
	define( 'INDOSTIO_ADDONS_URL', plugin_dir_url( __FILE__ ) );
}

require_once INDOSTIO_ADDONS_DIR . 'plugin.php';

\Indostio\Addons::instance();