<?php
add_action( 'wp_enqueue_scripts', 'indostio_child_enqueue_scripts', 20 );

function indostio_child_enqueue_scripts() {
    wp_enqueue_style( 'indostio-child-style', get_stylesheet_uri() );
}

add_filter('indostio_get_option', 'indostio_child_get_option', 20, 2);
function indostio_child_get_option($value, $name) {
    if( get_the_ID() == 52 ) {
        if( $name == 'primary_color' ) {
            $value = '#cb0000';
        } 
    } elseif( get_the_ID() == 1936 ) {
        if( $name == 'primary_color' ) {
            $value = '#F7C600';
        } elseif( $name == 'primary_text_color' ) {
            $value = '#000';
        } 
    }

    return $value;
}