jQuery( function( $ ) {
	'use strict';

	// Show/hide settings for post format when choose post format
	var $format = $( '#post-formats-select' ).find( 'input.post-format' ),
		$formatBox = $( '#post-format-settings' ),
		$box = $( '#display-settings' );

	$format.on( 'change', function () {
		var type = $format.filter( ':checked' ).val();

		handlePostFormatChanges( type );
	} );
	$format.filter( ':checked' ).trigger( 'change' );

	/**
	 * Handle post format change event.
	 */
	function handlePostFormatChanges( format ) {
		$formatBox.hide();
		if ( $formatBox.find( '.rwmb-field' ).hasClass( format ) ) {
			$formatBox.show();
		}

		$formatBox.find( '.rwmb-field' ).slideUp();
		$formatBox.find( '.' + format ).slideDown();
	}

	// Toggle spacing fields
	$( '#indostio_page_header_top_spacing, #indostio_page_header_bottom_spacing' ).on( 'change', function( event ) {
		if ( 'custom' === event.target.value ) {
			$( this ).closest( '.rwmb-field' ).next( '.page-header-custom-spacing' ).show();
		} else {
			$( this ).closest( '.rwmb-field' ).next( '.page-header-custom-spacing' ).hide();
		}
	} ).trigger('change');

		// Toggle spacing fields
		$( '#indostio_content_top_spacing, #indostio_content_bottom_spacing' ).on( 'change', function( event ) {
			if ( 'custom' === event.target.value ) {
				$( this ).closest( '.rwmb-field' ).next( '.custom-spacing' ).show();
			} else {
				$( this ).closest( '.rwmb-field' ).next( '.custom-spacing' ).hide();
			}
		} ).trigger('change');

} );
