<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Indostio
 */
$has_sidebar = apply_filters( 'indostio_get_sidebar', false );

if( ! $has_sidebar ) {
	return;
}

if( is_single() ) {
	$sidebar = 'single-sidebar';
} else {
	$sidebar = 'blog-sidebar';
}

if ( \Indostio\Helper::is_catalog() ) {
	$sidebar = 'catalog-sidebar';
}

if ( ! is_active_sidebar( $sidebar ) ) {
	return;
}
$sidebar_class = apply_filters( 'indostio_primary_sidebar_classes', $sidebar );
?>

<aside class="widget-area primary-sidebar <?php echo esc_attr( $sidebar_class ) ?>">
	<?php dynamic_sidebar( $sidebar ); ?>
</aside><!-- #primary -->