<?php
/**
 * Template part for displaying post navigation
 *
 * @package Indostio
 */

$next_post = get_next_post();
$prev_post = get_previous_post();

if ( ! $next_post && ! $prev_post ) {
	return;
}
?>

<nav class="navigation post-navigation" role="navigation">
	<div class="nav-links">
		<?php if ( $prev_post ) : ?>
			<a class="nav-previous" href="<?php echo esc_url( get_permalink( $prev_post ) )  ?>">
				<?php
				if ( has_post_thumbnail( $prev_post ) ) {
					echo '<span class="post-thumbnail">';
					echo get_the_post_thumbnail( $prev_post, 'indostio-post-thumbnail-small' );
					echo \Indostio\Icon::get_svg( 'left-mini' );
					echo '</span>';
				}
				?>
				<span class="nav-title">
					<?php
					echo sprintf( '<div class="meta meta-title">%s</div>', esc_html( $prev_post->post_title ) );
					echo sprintf( '<div class="meta meta-date">%s%s</div>', Indostio\Icon::get_svg( 'calendar' ), esc_html( get_the_date() ) );
					?>
				</span>
			</a>
		<?php endif; ?>
		<?php if ( $next_post ) :?>
			<a class="nav-next" href="<?php echo esc_url( get_permalink( $next_post ) )  ?>">
				<span class="nav-title">
					<?php
					echo sprintf( '<div class="meta meta-title">%s</div>', esc_html( $next_post->post_title ) );
					echo sprintf( '<div class="meta meta-date">%s%s</div>', Indostio\Icon::get_svg( 'calendar' ), esc_html( get_the_date() ) );
					?>
				</span>

				<?php
					if ( has_post_thumbnail( $next_post ) ) {
						echo '<span class="post-thumbnail">';
						echo get_the_post_thumbnail( $next_post, 'indostio-post-thumbnail-small' );
						echo \Indostio\Icon::get_svg( 'right-mini' );
						echo '</span>';
					}
					?>
			</a>
		<?php endif; ?>
	</div>
</nav>