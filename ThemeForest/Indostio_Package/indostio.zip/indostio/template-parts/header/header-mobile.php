<?php
/**
 * Template part for displaying header mobile.
 *
 * @package Indostio
 */

$elementor_instance = \Elementor\Plugin::instance();
$header_mobile_id = isset( $args['header_mobile_id'] ) ? $args['header_mobile_id'] : '';
$sticky_header_mobile_id = isset( $args['sticky_header_mobile_id'] ) ? $args['sticky_header_mobile_id'] : '';
?>

<div class="site-header__mobile">
	<?php echo ! empty($header_mobile_id) ? '<div class="header-main-mobile">' . $elementor_instance->frontend->get_builder_content_for_display( intval( $header_mobile_id) ) . '</div>' : ''; ?>
	<?php echo ! empty($sticky_header_mobile_id) ? '<div class="sticky-header">' . $elementor_instance->frontend->get_builder_content_for_display( intval( $sticky_header_mobile_id) ) . '</div>' : ''; ?>
</div>