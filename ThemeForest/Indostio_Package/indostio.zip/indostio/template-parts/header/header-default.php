<?php
/**
 * Template part for displaying header v1.
 *
 * @package Indostio
 */

?>


<div class="container header-container">
	<div class="header-left header-item">
		<?php echo \Indostio\Icon::get_svg('logo'); ?>
	</div>
	<div class="header-right header-item">
		<nav id="site-navigation" class="main-navigation primary-nav">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary-menu',
					'container'      => false
				)
			);
			?>
		</nav>
		<div class="header-item_panel">
			<a href="#" class="header-item_panel--icon">
				<span class="indostio-svg-icon"><svg width="24" height="24" aria-hidden="true" viewBox="0 0 27 32"><path d="M0 6.667h26.667v2.667h-26.667v-2.667z"></path><path d="M0 14.667h26.667v2.667h-26.667v-2.667z"></path><path d="M0 22.667h26.667v2.667h-26.667v-2.667z"></path></svg></span>			
			</a>
			<div class="header-item_panel__backdrop"></div>
			<div class="header-item_panel__content">
			<?php echo \Indostio\Icon::get_svg('close', 'header-item-close-icon'); ?>
			<?php 
			wp_nav_menu( 
				array(
				'theme_location' => 'primary-menu',
				'container'      	=> 'nav',
				'container_class'   => '',
				'menu_class'     	=> 'menu indostio-sidebar__menu',
				'depth'          	=> 2,
			) );		
			?>
			</div>
		</div>

	</div>
</div>
