<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Indostio
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="entry-thumbnail">
		<?php the_post_thumbnail(); ?>
	</div>
	<div class="entry-content">
		<?php the_content(); ?>
		<?php
		wp_link_pages( array(
			'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'indostio' ),
			'after'  => '</div>',
		) );
		?>
	</div>
	<?php if( has_tag() != false || ! empty( \Indostio\Helper::get_option('post_sharing') )  ) { ?>
		<footer class="entry-footer">
		<?php \Indostio\Blog\Post::tags(); ?>
		<?php \Indostio\Blog\Post::share(); ?>
		</footer>
	<?php } ?>
</article>
