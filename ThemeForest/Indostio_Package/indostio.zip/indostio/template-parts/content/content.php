<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Indostio
 */
$classes = is_search() ? 'post' : '';
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?>>
	<?php \Indostio\Blog\Post::thumbnail(); ?>
	<div class="entry-summary">
		<?php \Indostio\Blog\Post::category(); ?>
		<?php \Indostio\Blog\Post::title(); ?>
		<div class="entry-metas">
			<?php \Indostio\Blog\Post::author(); ?>
			<?php \Indostio\Blog\Post::date(); ?>
			<?php \Indostio\Blog\Post::comment(); ?>
		</div>
		<?php \Indostio\Blog\Post::excerpt(); ?>
		<?php \Indostio\Blog\Post::button(); ?>
	</div>
</article>
