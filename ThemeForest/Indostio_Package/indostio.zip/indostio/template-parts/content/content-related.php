<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Indostio
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php \Indostio\Blog\Post::thumbnail(); ?>
	<?php \Indostio\Blog\Post::title(); ?>
	<div class="entry-meta">
		
	</div>
</article>