<?php
/**
 * Template part for displaying portfolio content
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Indostio
 */
$get_image = wp_get_attachment_image( get_post_thumbnail_id( get_the_ID() ), 'indostio-portfolio-thumbnail');
$get_image .= \Indostio\Icon::get_svg('arrow-right');
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('indostio-portfolio-grid__item'); ?>>
	<a href="<?php echo get_permalink(); ?>" class="indostio-portfolio-grid__link">
		<div class="indostio-portfolio-grid__image"><?php echo $get_image; ?></div>
		<div class="indostio-portfolio-grid__title"><?php echo get_the_title();?> <?php echo \Indostio\Icon::get_svg('arrow-right'); ?></div>
	</a>
</article>
