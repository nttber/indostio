<?php
/**
 * Template part for displaying page header.
 *
 * @package Indostio
 */

?>


<div class="page-header">
<div class="indostio-container">
<div class="page-header__inner">
<div class="page-header__image"></div>
<div class="page-header__content">
<div class="container">
<?php \Indostio\Page_Header::title() ?>
<?php \Indostio\Page_Header::breadcrumb() ?>
</div>
</div>
</div>
</div>
</div>