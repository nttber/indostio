<?php
/**
 * Template part for displaying post header.
 *
 * @package Indostio
 */

?>


<div class="page-header post-header">
<div class="indostio-container">
<div class="page-header__inner hentry">
<div class="page-header__image"></div>
<div class="page-header__content entry-header">
<div class="container">
<?php \Indostio\Blog\Post::category(); ?>
		<?php \Indostio\Blog\Post::single_title('h1'); ?>
		<div class="entry-metas">
			<?php \Indostio\Blog\Post::author(); ?>
			<?php \Indostio\Blog\Post::date(); ?>
			<?php \Indostio\Blog\Post::comment(); ?>
		</div>
</div>
</div>
</div>
</div>
</div>