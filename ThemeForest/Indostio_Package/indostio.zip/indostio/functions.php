<?php
/**
 * Functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Indostio
 */

require_once get_template_directory() . '/inc/theme.php';

\Indostio\Theme::instance()->init();