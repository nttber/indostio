<?php
/**
 * Header functions and definitions.
 *
 * @package Indostio
 */

namespace Indostio;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Header initial
 *
 */
class Header {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	protected static $instance = null;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

		add_action( 'indostio_header', array( $this, 'show_header' ) );

		add_action( 'indostio_after_site_content_open', array( $this, 'open_site_content_container' ) );
		add_action( 'indostio_before_site_content_close', array( $this, 'close_site_content_container' ), 30 );

		add_filter('body_class', array( $this, 'classes' ));
	}

	/**
	 * Body Classes
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public function classes($classes) {
		if( \Indostio\Helper::is_service_page() && ! is_search() ) {
			$classes[] = 'indostio-service-page';
		}

		if( \Indostio\Helper::is_team_page() && ! is_search() ) {
			$classes[] = 'indostio-team-page';
		}

		if( \Indostio\Helper::is_portfolio_page() && ! is_search() ) {
			$classes[] = 'indostio-portfolio-page';
		}

		if( get_post_meta(get_the_ID(), 'indostio_header_background', true) == 'transparent' ) {
			$classes[] = 'indostio-header-transparent';
		}
		
		return $classes;
	}

	/**
	 * Enqueue scripts and styles.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function enqueue_scripts() {
		wp_enqueue_style( 'indostio-fonts', $this->get_fonts_url(), array(), '20230301' );

		wp_register_style( 'indostio-swiper', get_template_directory_uri() . '/assets/css/swiper.css');

		$style_file = is_rtl() ? 'style-rtl.css' : 'style.css';
		wp_enqueue_style( 'indostio', apply_filters( 'indostio_get_style_directory_uri', get_template_directory_uri() ) . '/' . $style_file, array('indostio-swiper'), '20221220' );

		do_action( 'indostio_after_enqueue_style' );
		
		/**
		 * Register and enqueue scripts
		 */

		wp_enqueue_script( 'html5shiv', get_template_directory_uri() . '/assets/js/plugins/html5shiv.min.js', array(), '3.7.2' );
		wp_script_add_data( 'html5shiv', 'conditional', 'lt IE 9' );

		wp_enqueue_script( 'respond', get_template_directory_uri() . '/assets/js/plugins/respond.min.js', array(), '1.4.2' );
		wp_script_add_data( 'respond', 'conditional', 'lt IE 9' );

		wp_register_script( 'swiper', get_template_directory_uri() . '/assets/js/plugins/swiper.min.js', array( 'jquery' ), '5.3.8', true );

		$debug = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		wp_enqueue_script( 'indostio', get_template_directory_uri() . '/assets/js/scripts.js', array(
			'jquery',
			'swiper',
			'imagesloaded',
		), '20230301', true );

		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}

		$indostio_data = array(
			'direction'            => is_rtl() ? 'true' : 'false',
		);

		$indostio_data = apply_filters( 'indostio_wp_script_data', $indostio_data );

		wp_localize_script(
			'indostio', 'indostioData', $indostio_data
		);

		$this->enqueue_header_style();

	}

	/**
	 * Get font url
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public static function get_fonts_url() {
		$fonts_url = '';

		/* Translators: If there are characters in your language that are not
		* supported by Montserrat, translate this to 'off'. Do not translate
		* into your own language.
		*/
		if ( 'off' !== _x( 'on', 'Manrope font: on or off', 'indostio' ) ) {
			$font_families[] = 'Manrope:400,500,600,700,800';
		}

		if ( ! empty( $font_families ) ) {
			$query_args = array(
				'family' => urlencode( implode( '|', $font_families ) ),
				'subset' => urlencode( 'latin,latin-ext' ),
			);

			$fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
		}

		return esc_url_raw( $fonts_url );
	}

		/**
	 * Display the site header
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */

	 public function show_header() {
		$header_id = \Indostio\Helper::get_header_layout();
		if ( class_exists( 'Elementor\Plugin' ) && ! empty( $header_id ) ) {
			$header_mobile_id = \Indostio\Helper::get_header_mobile_layout();
			$header_mobile_classes = empty($header_mobile_id) ? 'show-on-mobile' : '';
			$args = array();
			$args['header_id'] = $header_id;
			$args['header_classes'] = $header_mobile_classes;
			$args['sticky_header_id'] = \Indostio\Helper::get_sticky_header();
			get_template_part( 'template-parts/header/header', 'desktop', $args );

			if( ! empty($header_mobile_id) ) {
				$args['header_mobile_id'] = $header_mobile_id;
				$args['sticky_header_mobile_id'] = \Indostio\Helper::get_sticky_header_mobile();
				get_template_part( 'template-parts/header/header', 'mobile', $args );
			}
			
		} else {
			get_template_part( 'template-parts/header/header', 'default' );
		}

	}

	/**
	 * Enqueue styles and scripts.
	 */
	public function enqueue_header_style() {
		$header_id = \Indostio\Helper::get_header_layout();
		$this->enqueue_style_by_id( $header_id );

		$sticky_header = \Indostio\Helper::get_sticky_header();
		$this->enqueue_style_by_id( $sticky_header );

		$header_mobile_id = \Indostio\Helper::get_header_mobile_layout();
		$this->enqueue_style_by_id( $header_mobile_id );

		$sticky_header_mobile = \Indostio\Helper::get_sticky_header_mobile();
		$this->enqueue_style_by_id( $sticky_header_mobile );
	}

	/**
	 * Enqueue styles and scripts.
	 */
	public function enqueue_style_by_id($post_id) {
		if ( ! empty( $post_id ) ) {
			$css_file = '';
			if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
				$css_file = new \Elementor\Core\Files\CSS\Post( $post_id );
			} elseif ( class_exists( '\Elementor\Post_CSS_File' ) ) {
				$css_file = new \Elementor\Post_CSS_File( $post_id );
			}
			if( $css_file ) {
				$css_file->enqueue();
			}
		}
	}

	/**
	 * Print the open tags of site content container
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function open_site_content_container() {
		if( Helper::is_built_with_elementor() ) {
			return;
		}
		$classes = '';
		echo '<div class="container clearfix '. esc_attr( $classes ) .'">';
	}

	/**
	 * Print the close tags of site content container
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function close_site_content_container() {
		if( Helper::is_built_with_elementor() ) {
			return;
		}
		echo '</div>';
	}


}
