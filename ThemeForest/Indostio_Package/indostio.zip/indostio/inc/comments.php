<?php
/**
 * Comment functions and definitions.
 *
 * @package Indostio
 */

namespace Indostio;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Comments initial
 *
 */
class Comments {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	protected static $instance = null;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter( 'comment_form_default_fields', array( $this, 'comment_form_fields' ) );
	}

	/**
	 * Custom fields comment form
	 *
	 * @since  1.0
	 *
	 * @return  array  $fields
	 */
	public function comment_form_fields() {
		global $commenter, $aria_req;

		$comment_author = isset($commenter['comment_author']) ? $commenter['comment_author'] : '';
		$comment_author_email = isset($commenter['comment_author_email']) ? $commenter['comment_author_email'] : '';
		$comment_author_url = isset($commenter['comment_author_url']) ? $commenter['comment_author_url'] : '';

		$fields = array(
			'author' => '<p class="comment-form-author">' .
			            '<input id ="author" placeholder="' . esc_attr__( 'Name', 'indostio' ) . ' " name="author" type="text" required value="' . esc_attr( $comment_author ) .
			            '" size    ="30"' . $aria_req . ' /></p>',

			'email' => '<p class="comment-form-email">' .
			           '<input id ="email" placeholder="' . esc_attr__( 'Email', 'indostio' ) . '" name="email" type="email" required value="' . esc_attr( $comment_author_email ) .
			           '" size    ="30"' . $aria_req . ' /></p>',

		);

		return $fields;
	}
}
