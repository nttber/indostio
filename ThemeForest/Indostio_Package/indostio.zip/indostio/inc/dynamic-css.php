<?php
/**
 * Style functions and definitions.
 *
 * @package Indostio
 */

namespace Indostio;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Style initial
 *
 * @since 1.0.0
 */
class Dynamic_CSS {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	protected static $instance = null;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'indostio_after_enqueue_style', array( $this, 'add_static_css' ) );
	}

	/**
	 * Get get style data
	 *
	 * @since  1.0.0
	 *
	 * @return string
	 */
	public function add_static_css() {
		$parse_css = $this->primary_color_static_css();
		$parse_css .= $this->header_mobile_static_css();
		$parse_css .= $this->page_header_static_css();
		if( is_singular('post') ) {
			$parse_css .= $this->post_header_static_css();
		} elseif( Helper::is_blog() || is_search() ) {
			$parse_css .= $this->blog_header_static_css();
		} elseif( is_page() ) {
			$parse_css .= $this->page_static_css();
		}
		wp_add_inline_style( 'indostio', apply_filters( 'indostio_inline_style', $parse_css ) );
	}

	/**
	 * Get Color Scheme style data
	 *
	 * @since  1.0.0
	 *
	 * @return string
	 */
	protected function primary_color_static_css() {
		$color_style = '';
		$primary_color = Helper::get_option('primary_color_custom') ? Helper::get_option('primary_color_custom_color') : Helper::get_option('primary_color');
		if( $primary_color != '#FF5E14' ) {
			$color_style .= '--id-background-color-primary:' . $primary_color . ';';
			$color_style .= '--id-color-primary:' . $primary_color . ';';
			$color_style .= '--id-border-color-primary:' . $primary_color . ';';
			$color_style .= '--id-color-hover-primary:' . $primary_color . ';';
		}

		$primary_text_color = Helper::get_option('primary_text_color');
		if( $primary_text_color == 'light' ) {
			$primary_text_color = '#ffffff';
		} elseif( $primary_text_color == 'dark' ) {
			$primary_text_color = '#000000';
		} elseif( $primary_text_color == 'custom' ) {
			$primary_text_color = Helper::get_option('primary_text_color_custom');
		}
		if( $primary_text_color != '#ffffff' ) {
			$color_style .= '--id-background-text-color-primary:' . $primary_text_color . ';';
		}
	
		if( $color_style ) {
			$color_style = 'body{'. $color_style .'}';
		}

		return $color_style;

	}


	/**
	 * Header mobile static css
	 *
	 * @since  1.0.0
	 *
	 * @return string
	 */
	protected function header_mobile_static_css() {
		$static_css = '';

		$header_breakpoint = Helper::get_option( 'header_mobile_breakpoint' );
		$header_breakpoint = ! empty( $header_breakpoint ) ? $header_breakpoint : '1199';

		if ( intval( $header_breakpoint ) ) {
			$static_css .= '@media (max-width: '. $header_breakpoint .'px) { .site-header__mobile { display: block; } }';
			$static_css .= '@media (max-width: '. $header_breakpoint .'px) { .site-header__desktop { display: none; } }';
		}

		return $static_css;
	}

	/**
	 * Get Blog style data
	 *
	 * @since  1.0.0
	 *
	 * @return string
	 */
	protected function blog_header_static_css() {
		if( ! empty(Helper::get_option( 'disable_blog_header' )) ) {
			return;
		}
		$color_style = '';
		$image = Helper::get_option('blog_header_image');
		if( !empty($image) ) {
			$color_style .= '.page-header .page-header__image{background-image:url(' . esc_url($image) .')}';
		}

		$spacing_top = Helper::get_option('blog_header_spacing_top');
		if( $spacing_top != '176' ) {
			$color_style .= '.page-header .page-header__inner{padding-top:' . $spacing_top .'px}';
		}

		$spacing_bottom = Helper::get_option('blog_header_spacing_bottom');
		if( $spacing_bottom != '176' ) {
			$color_style .= '.page-header .page-header__inner{padding-bottom:' . $spacing_bottom .'px}';
		}

		return $color_style;

	}


	/**
	 * Get Post style data
	 *
	 * @since  1.0.0
	 *
	 * @return string
	 */
	protected function post_header_static_css() {
		$color_style = '';
		$image = Helper::get_option('post_header_image');
		if( !empty($image) ) {
			$color_style .= '.post-header .page-header__image{background-image:url(' . esc_url($image) .')}';
		}

		$spacing_top = Helper::get_option('post_header_spacing_top');
		if( $spacing_top != '176' ) {
			$color_style .= '.post-header {--indostio-page-header-top:' . $spacing_top .'px}';
		}

		$spacing_bottom = Helper::get_option('post_header_spacing_bottom');
		if( $spacing_bottom != '176' ) {
			$color_style .= '.post-header {--indostio-page-header-bottom:' . $spacing_bottom .'px}';
		}

		return $color_style;

	}

	/**
	 * Get Page style data
	 *
	 * @since  1.0.0
	 *
	 * @return string
	 */
	protected function page_header_static_css() {
		if( ! empty(Helper::get_option( 'disable_page_header' )) ) {
			return;
		}
		$color_style = '';
		$image = Helper::get_option('page_header_image');
		$get_id = Helper::get_post_ID();
		$custom_image_id = get_post_meta( $get_id, 'page_header_image', true );
		$custom_image = $custom_image_id ? wp_get_attachment_image_src( $custom_image_id, 'full' ) : '';
		$image = $custom_image ? $custom_image[0] : $image;
		if( !empty($image) ) {
			$color_style .= '.page-header .page-header__image{background-image:url(' . esc_url($image) .')}';
		}

		$spacing_top = Helper::get_option('page_header_spacing_top');
		$custom_spacing_top = get_post_meta( $get_id, 'indostio_page_header_top_spacing', true );
		if( $custom_spacing_top == 'no' ) {
			$spacing_top = '0';
		} elseif( $custom_spacing_top == 'custom' ) {
			$spacing_top = get_post_meta( $get_id, 'indostio_page_header_top_padding', true );
		}
		if( $spacing_top != '176' ) {
			$color_style .= '.page-header .page-header__inner{padding-top:' . $spacing_top .'px}';
		}

		$spacing_bottom = Helper::get_option('page_header_spacing_bottom');
		$custom_spacing_bottom = get_post_meta( $get_id, 'indostio_page_header_bottom_spacing', true );
		if( $custom_spacing_bottom == 'no' ) {
			$spacing_bottom = '0';
		} elseif( $custom_spacing_bottom == 'custom' ) {
			$spacing_bottom = get_post_meta( $get_id, 'indostio_page_header_bottom_padding', true );
		}
		if( $spacing_bottom != '176' ) {
			$color_style .= '.page-header .page-header__inner{padding-bottom:' . $spacing_bottom .'px}';
		}

		return $color_style;

	}

	/**
	 * Page static css
	 *
	 * @since  1.0.0
	 *
	 * @return string
	 */
	protected function page_static_css() {
		$static_css = '';

		if( Helper::is_portfolio_page() ) {
			return $static_css;
		}

		$content_top = get_post_meta( Helper::get_post_ID(), 'indostio_content_top_spacing', true );
		$top = '';
		if( $content_top == 'custom' ) {
			$top = get_post_meta( Helper::get_post_ID(), 'indostio_content_top_padding', true );
		} elseif( $content_top == 'no' ) {
			$top = '0';
		}

		if ( $content_top != 'default' &&  $top != '' ) {
			$static_css .= '.site-content { padding-top: ' . $top . 'px; }';
		}

		$content_bottom = get_post_meta( Helper::get_post_ID(), 'indostio_content_bottom_spacing', true );
		$bottom = '';
		if( $content_bottom == 'custom' ) {
			$bottom = get_post_meta( Helper::get_post_ID(), 'indostio_content_bottom_padding', true );
		}  elseif( $content_top == 'no' ) {
			$bottom = '0';
		}

		if ( $content_bottom != 'default' &&  $bottom != '' ) {
			$static_css .= '.site-content { padding-bottom: ' . $bottom . 'px; }';
		}

		return $static_css;
	}
	
}
