<?php
/**
 * Indostio helper functions and definitions.
 *
 * @package Indostio
 */

namespace Indostio;

use Indostio\Theme;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Indostio Helper initial
 *
 */
class Helper {
	/**
	 * Post ID
	 *
	 * @var $post_id
	 */
	protected static $post_id = null;

		/**
	 * Post ID
	 *
	 * @var $is_build_elementor
	 */
	protected static $is_build_elementor = null;

	/**
	 * Header Layout
	 *
	 * @var $header_layout
	 */
	protected static $header_layout = null;

	/**
	 * Sticky Header
	 *
	 * @var $sticky_header
	 */
	protected static $sticky_header = null;

		/**
	 * Footer layout
	 *
	 * @var $footer_layout
	 */
	protected static $footer_layout = null;


	/**
	 * Header Mobile Layout
	 *
	 * @var $header_mobile_layout
	 */
	protected static $header_mobile_layout = null;

	/**
	 * Sticky Header Mobile
	 *
	 * @var $sticky_header_mobile
	 */
	protected static $sticky_header_mobile = null;


	/**
	 * Get theme option
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public static function get_option( $name ) {
		return Options::instance()->get_option( $name );
	}

	/**
	 * Check is catalog
	 *
	 * @since 1.0.0
	 *
	 * @return boolean
	 */
	public static function is_catalog() {
		if ( function_exists( 'is_shop' ) && ( is_shop() || is_product_category() || is_product_tag() || is_tax( 'product_brand' ) || is_tax( 'product_collection' ) || is_tax( 'product_condition' ) ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Check is blog
	 *
	 * @since 1.0.0
	 *
	 * @return boolean
	 */
	public static function is_blog() {
		if ( ( is_archive() || is_author() || is_category() || is_home() || is_tag() ) && 'post' == get_post_type() ) {
			return true;
		}

		return false;
	}

	/**
	 * Check service page
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function is_service_page($page_id = '') {
		$page_id = empty($page_id) ? get_the_ID() : $page_id;
		if( get_option( 'service_page_id'  ) == $page_id) {
			return true;
		}

		return false;
	}

	/**
	 * Check team page
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function is_team_page($page_id = '') {
		$page_id = empty($page_id) ? get_the_ID() : $page_id;
		if( get_option( 'team_page_id'  ) == $page_id) {
			return true;
		}

		return false;
	}

	/**
	 * Check portfolio page
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function is_portfolio_page($page_id = '') {
		$page_id = empty($page_id) ? get_the_ID() : $page_id;
		if( get_option( 'portfolio_page_id'  ) == $page_id) {
			return true;
		}

		return false;
	}

	/**
	 * Get Post ID
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public static function get_post_ID() {
		if( isset( self::$post_id ) ) {
			return self::$post_id;
		}

		if ( self::is_catalog() ) {
			self::$post_id = intval( get_option( 'woocommerce_shop_page_id' ) );
		} elseif ( self::is_blog() ) {
			self::$post_id = intval( get_option( 'page_for_posts' ) );
		} else {
			self::$post_id = get_the_ID();
		}

		return self::$post_id;
	}


	/**
	 * Get Header Layout
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public static function get_header_layout() {
		if( isset( self::$header_layout ) ) {
			return self::$header_layout;
		}

		if( is_page() ) {
			self::$header_layout = get_post_meta( get_the_ID(), 'header_layout', true );
			
		}
		self::$header_layout = ! empty( self::$header_layout ) ? self::$header_layout : \Indostio\Helper::get_option( 'header_layout' );
		return self::$header_layout;
	}

	/**
	 * Get Sticky Header
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public static function get_sticky_header() {
		if( isset( self::$sticky_header ) ) {
			return self::$sticky_header;
		}

		self::$sticky_header =  \Indostio\Helper::get_option( 'sticky_header_layout' );
		return self::$sticky_header;
	}

	/**
	 * Get Post ID
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public static function get_header_mobile_layout() {
		if( isset( self::$header_mobile_layout ) ) {
			return self::$header_mobile_layout;
		}

		if( is_page() ) {
			self::$header_mobile_layout = get_post_meta( get_the_ID(), 'header_mobile_layout', true );
			
		}
		self::$header_mobile_layout = ! empty( self::$header_mobile_layout ) ? self::$header_mobile_layout : \Indostio\Helper::get_option( 'header_mobile_layout' );
		
		return self::$header_mobile_layout;
	}

	/**
	 * Get Sticky Header Mobile
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public static function get_sticky_header_mobile() {
		if( isset( self::$sticky_header_mobile ) ) {
			return self::$sticky_header_mobile;
		}

		self::$sticky_header_mobile =  \Indostio\Helper::get_option( 'sticky_header_mobile_layout' );
		return self::$sticky_header_mobile;
	}

	
	/**
	 * Get Post ID
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public static function get_footer_layout() {
		if( isset( self::$footer_layout ) ) {
			return self::$footer_layout;
		}

		if( is_page() ) {
			self::$footer_layout = get_post_meta( get_the_ID(), 'footer_layout', true );
			
		}
		self::$footer_layout = ! empty( self::$footer_layout ) ? self::$footer_layout : \Indostio\Helper::get_option( 'footer_layout' );
		return self::$footer_layout;
	}


	/**
	 * Content limit
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public static function get_content_limit( $num_words, $more = "&hellip;", $content = '' ) {
		$content = empty( $content ) ? get_the_excerpt() : $content;

		// Strip tags and shortcodes so the content truncation count is done correctly
		$content = strip_tags(
			strip_shortcodes( $content ), apply_filters(
				'indostio_content_limit_allowed_tags', '<script>,<style>'
			)
		);

		// Remove inline styles / scripts
		$content = trim( preg_replace( '#<(s(cript|tyle)).*?</\1>#si', '', $content ) );

		// Truncate $content to $max_char
		$content = wp_trim_words( $content, $num_words );

		if ( $more ) {
			return sprintf(
				'<p>%s <a href="%s" class="more-link" title="%s">%s</a></p>',
				$content,
				get_permalink(),
				sprintf( esc_html__( 'Continue reading &quot;%s&quot;', 'indostio' ), the_title_attribute( 'echo=0' ) ),
				esc_html( $more )
			);
		} else {
			return sprintf( '<p>%s</p>', $content );
		}

	}

	/**
	 * Get an array of posts.
	 *
	 * @static
	 * @access public
	 *
	 * @param array $args Define arguments for the get_posts function.
	 *
	 * @return array
	 */
	public static function customizer_get_posts( $args ) {
		if ( ! is_admin() ) {
			return;
		}

		if ( is_string( $args ) ) {
			$args = add_query_arg(
				array(
					'suppress_filters' => false,
				)
			);
		} elseif ( is_array( $args ) && ! isset( $args['suppress_filters'] ) ) {
			$args['suppress_filters'] = false;
		}

		$args['posts_per_page'] = - 1;

		$posts = get_posts( $args );

		// Properly format the array.
		$items    = array();
		$items[0] = esc_html__( 'Select an item', 'indostio' );
		foreach ( $posts as $post ) {
			$items[ $post->ID ] = $post->post_title;
		}
		wp_reset_postdata();

		return $items;

	}

	public static function the_posts_navigation() {
		the_posts_pagination(
			array(
				'before_page_number' =>'',
				'mid_size'           => 1,
				'prev_text'          => '<span class="indostio-svg-icon"><svg width="9" height="15" viewBox="0 0 9 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.318359 7.33667C0.0546875 7.60034 0.0546875 7.96948 0.318359 8.23315L6.48828 14.3503C6.75195 14.614 7.17383 14.614 7.38477 14.3503L7.75391 13.9812C8.01758 13.7175 8.01758 13.3484 7.75391 13.0847L2.375 7.75854L7.80664 2.48511C8.01758 2.22144 8.01758 1.85229 7.80664 1.58862L7.38477 1.21948C7.17383 0.955811 6.75195 0.955811 6.48828 1.21948L0.318359 7.33667Z" fill="currentColor"/></svg></span>',
				'next_text'          => '<span class="indostio-svg-icon"><svg width="9" height="15" viewBox="0 0 9 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.68164 7.33667C8.94531 7.60034 8.94531 7.96948 8.68164 8.23315L2.51172 14.3503C2.24805 14.614 1.82617 14.614 1.61523 14.3503L1.24609 13.9812C0.982422 13.7175 0.982422 13.3484 1.24609 13.0847L6.625 7.75854L1.19336 2.48511C0.982422 2.22144 0.982422 1.85229 1.19336 1.58862L1.61523 1.21948C1.82617 0.955811 2.24805 0.955811 2.51172 1.21948L8.68164 7.33667Z" fill="currentColor"/></svg></span>',
				'class'              => 'indostio-pagination',
			),
		);
	}

		/**
	 * Check is built with elementor
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function is_built_with_elementor() {
		if( isset( self::$is_build_elementor )  ) {
			return self::$is_build_elementor;
		}
		if( ! class_exists('\Elementor\Plugin') ) {
			self::$is_build_elementor = false;
		} else {
			$document = \Elementor\Plugin::$instance->documents->get( get_the_ID() );
			if ( (is_page() || is_singular('indostio_service') || is_singular('indostio_team') || is_singular('indostio_portfolio') ) && $document && $document->is_built_with_elementor() ) {
				self::$is_build_elementor = true;
			}
		}

		return self::$is_build_elementor;
	}

}
