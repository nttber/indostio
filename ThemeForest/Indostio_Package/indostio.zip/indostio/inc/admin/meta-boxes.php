<?php
/**
 * Meta boxes functions
 *
 * @package Indostio
 */

namespace Indostio\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Meta boxes initial
 *
 */
class Meta_Boxes {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	protected static $instance = null;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter( 'rwmb_meta_boxes', array( $this, 'register_meta_boxes' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'meta_box_scripts' ) );
	}

	/**
	 * Enqueue scripts
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function meta_box_scripts( $hook ) {
		if ( in_array( $hook, array( 'post.php', 'post-new.php' ) ) ) {
			wp_enqueue_script( 'indostio-meta-boxes', get_template_directory_uri() . '/assets/js/backend/meta-boxes.js', array( 'jquery' ), '20201012', true );
		}
	}



	/**
	 * Registering meta boxes
	 *
	 * @since 1.0.0
	 *
	 * Using Meta Box plugin: http://www.deluxeblogtips.com/meta-box/
	 *
	 * @see http://www.deluxeblogtips.com/meta-box/docs/define-meta-boxes
	 *
	 * @param array $meta_boxes Default meta boxes. By default, there are no meta boxes.
	 *
	 * @return array All registered meta boxes
	 */
	public function register_meta_boxes( $meta_boxes ) {
		// Page
		$meta_boxes[] = $this->register_display_settings();

		return $meta_boxes;
	}

	/**
	 * Register header settings
	 *
	 * @since 1.0.0
	 *
	 * @return array
	 */
	public function register_display_settings() {
		if( isset($_GET['post']) && $_GET['post'] == get_option('page_for_posts') ) {
			return;
		}

		if( isset($_GET['post']) && $_GET['post'] == get_option('woocommerce_shop_page_id') ) {
			return;
		}

		if( isset($_GET['post']) && \Indostio\Helper::is_service_page(intval($_GET['post'])) ) {
			return;
		}

		if( isset($_GET['post']) && \Indostio\Helper::is_team_page(intval($_GET['post'])) ) {
			return;
		}

		if( isset($_GET['post']) && \Indostio\Helper::is_portfolio_page(intval($_GET['post'])) ) {
			return;
		}
	
		return array(
			'id'       => 'display-settings',
			'title'    => esc_html__( 'Display Settings', 'indostio' ),
			'pages'    => array( 'page' ),
			'context'  => 'normal',
			'priority' => 'high',
			'fields'   => array(
				array(
					'name' => esc_html__( 'Header', 'indostio' ),
					'id'   => 'heading_site_header',
					'class' => 'header-heading',
					'type' => 'heading',
				),
				array(
					'name'    => esc_html__( 'Header Section', 'indostio' ),
					'id'      => 'header_layout',
					'type'    => 'select',
					'options' => \Indostio\Helper::customizer_get_posts( array( 'post_type' => 'indostio_header' ) ),
				),
				array(
					'name'    => esc_html__( 'Header Mobile Section', 'indostio' ),
					'id'      => 'header_mobile_layout',
					'type'    => 'select',
					'options' => \Indostio\Helper::customizer_get_posts( array( 'post_type' => 'indostio_header' ) ),
				),
				array(
					'name'    => esc_html__( 'Header Background', 'indostio' ),
					'id'      => 'indostio_header_background',
					'class'   => 'header-background-color hidden',
					'type'    => 'select',
					'options' => array(
						''     => esc_html__( 'Default', 'indostio' ),
						'transparent' => esc_html__( 'Transparent', 'indostio' ),
					),
				),
				array(
					'name' => esc_html__( 'Footer', 'indostio' ),
					'id'   => 'heading_site_footer',
					'class' => 'footer-heading',
					'type' => 'heading',
				),
				array(
					'name'    => esc_html__( 'Footer Section', 'indostio' ),
					'id'      => 'footer_layout',
					'type'    => 'select',
					'options' => \Indostio\Helper::customizer_get_posts( array( 'post_type' => 'indostio_footer' ) ),
				),
				array(
					'name' => esc_html__( 'Page Header', 'indostio' ),
					'id'   => 'heading_site_page_header',
					'class' => 'page-header-heading',
					'type' => 'heading',
				),
				array(
					'name' => esc_html__( 'Hide Page Header', 'indostio' ),
					'id'   => 'indostio_hide_page_header',
					'type' => 'checkbox',
					'std'  => false,
				),
				array(
					'name'  => esc_html__( 'Hide Title', 'indostio' ),
					'id'    => 'indostio_hide_title',
					'type'  => 'checkbox',
					'std'   => false,
					'class' => 'page-header-hide-title',
				),
				array(
					'name'  => esc_html__( 'Hide Breadcrumb', 'indostio' ),
					'id'    => 'indostio_hide_breadcrumb',
					'type'  => 'checkbox',
					'std'   => false,
					'class' => 'page-header-hide-breadcrumb',
				),
				array(	
					'name' 				=> esc_html__( 'Background Image', 'indostio' ),
					'id'   				=> 'page_header_image',
					'type' 				=> 'image_advanced',
					'force_delete'     	=> false,
					'max_file_uploads' 	=> 1,
					'max_status'       	=> false,
					'image_size'       	=> 'thumbnail',
				),
				array(
					'name'    => esc_html__( 'Top Spacing', 'indostio' ),
					'id'      => 'indostio_page_header_top_spacing',
					'type'    => 'select',
					'options' => array(
						'default' => esc_html__( 'Default', 'indostio' ),
						'no'      => esc_html__( 'No spacing', 'indostio' ),
						'custom'  => esc_html__( 'Custom', 'indostio' ),
					),
				),
				array(
					'name'       => '&nbsp;',
					'id'         => 'indostio_page_header_top_padding',
					'class'      => 'page-header-custom-spacing hidden',
					'type'       => 'slider',
					'suffix'     => esc_html__( ' px', 'indostio' ),
					'js_options' => array(
						'min' => 0,
						'max' => 500,
					),
					'std'        => '',
				),
				array(
					'name'    => esc_html__( 'Bottom Spacing', 'indostio' ),
					'id'      => 'indostio_page_header_bottom_spacing',
					'type'    => 'select',
					'options' => array(
						'default' => esc_html__( 'Default', 'indostio' ),
						'no'      => esc_html__( 'No spacing', 'indostio' ),
						'custom'  => esc_html__( 'Custom', 'indostio' ),
					),
				),
				array(
					'name'       => '&nbsp;',
					'id'         => 'indostio_page_header_bottom_padding',
					'class'      => 'page-header-custom-spacing hidden',
					'type'       => 'slider',
					'suffix'     => esc_html__( ' px', 'indostio' ),
					'js_options' => array(
						'min' => 0,
						'max' => 500,
					),
					'std'        => '',
				),
				array(
					'name' => esc_html__( 'Content', 'indostio' ),
					'id'   => 'heading_content',
					'class' => 'content-heading',
					'type' => 'heading',
				),
				array(
					'name'    => esc_html__( 'Content Top Spacing', 'indostio' ),
					'id'      => 'indostio_content_top_spacing',
					'type'    => 'select',
					'options' => array(
						'default' => esc_html__( 'Default', 'indostio' ),
						'no'      => esc_html__( 'No spacing', 'indostio' ),
						'custom'  => esc_html__( 'Custom', 'indostio' ),
					),
				),
				array(
					'name'       => '&nbsp;',
					'id'         => 'indostio_content_top_padding',
					'class'      => 'custom-spacing hidden',
					'type'       => 'slider',
					'suffix'     => esc_html__( ' px', 'indostio' ),
					'js_options' => array(
						'min' => 0,
						'max' => 300,
					),
					'std'        => '80',
				),
				array(
					'name'    => esc_html__( 'Content Bottom Spacing', 'indostio' ),
					'id'      => 'indostio_content_bottom_spacing',
					'type'    => 'select',
					'options' => array(
						'default' => esc_html__( 'Default', 'indostio' ),
						'no'      => esc_html__( 'No spacing', 'indostio' ),
						'custom'  => esc_html__( 'Custom', 'indostio' ),
					),
				),
				array(
					'name'       => '&nbsp;',
					'id'         => 'indostio_content_bottom_padding',
					'class'      => 'custom-spacing hidden',
					'type'       => 'slider',
					'suffix'     => esc_html__( ' px', 'indostio' ),
					'js_options' => array(
						'min' => 0,
						'max' => 300,
					),
					'std'        => '80',
				),
			),
		);
	}
}
