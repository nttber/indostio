<?php
/**
 * Header functions and definitions.
 *
 * @package Indostio
 */

namespace Indostio;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Header initial
 *
 */
class Footer {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	protected static $instance = null;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'indostio_footer', array( $this, 'show_footer' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

		add_action( 'indostio_after_footer', array( $this, 'gotop_button' ) );

	}

	/**
	 * Enqueue scripts and styles.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function enqueue_scripts() {
		$this->enqueue_footer_style();

	}

		/**
	 * Display the site footer
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */

	 public function show_footer() {
		$footer_id = \Indostio\Helper::get_footer_layout();
		if ( class_exists( 'Elementor\Plugin' ) && ! empty( $footer_id ) ) {
			$elementor_instance = \Elementor\Plugin::instance();
			echo sprintf(
				'<div class="footer-main">%s</div>',
				$elementor_instance->frontend->get_builder_content_for_display( intval( $footer_id) )
			);
		}

	}

	/**
	 * Enqueue styles and scripts.
	 */
	public function enqueue_footer_style() {
		$footer_id = \Indostio\Helper::get_footer_layout();
		if ( ! empty( $footer_id ) ) {
			$css_file = '';
			if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
				$css_file = new \Elementor\Core\Files\CSS\Post( $footer_id );
			} elseif ( class_exists( '\Elementor\Post_CSS_File' ) ) {
				$css_file = new \Elementor\Post_CSS_File( $footer_id );
			}
			if( $css_file ) {
				$css_file->enqueue();
			}
		}
		
	}

	/**
	 * Add this back-to-top button to footer
	 *
	 * @since 1.0.0
	 *
	 * @return  void
	 */
	public function gotop_button() {
		if ( apply_filters( 'indostio_get_back_to_top', \Indostio\Helper::get_option( 'backtotop' ) ) ) {
			echo '<a href="#page" id="gotop">' . \Indostio\Icon::get_svg( 'pr-arrow' ) . '</a>';
		}
	}


}
