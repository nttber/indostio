<?php
/**
 * Indostio init
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Indostio
 */

namespace Indostio;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Indostio theme init
 */
final class Theme {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance = null;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		require_once get_template_directory() . '/inc/autoload.php';
		if ( is_admin() ) {
			require_once get_template_directory() . '/inc/libs/tgm-plugin-activation.php';
		}
	}

	/**
	 * Hooks to init
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function init() {
		// Before init action.
		do_action( 'before_indostio_init' );
// Setup
		add_action( 'after_setup_theme', array( $this, 'setup_theme' ) );
		add_action( 'after_setup_theme', array( $this, 'setup_content_width' ), 0 );
		add_action( 'widgets_init', array( $this, 'widgets_init' ) );
		add_action( 'init', array( $this, 'loads' ), 50);
		add_action( 'template_redirect', array( $this, 'load_post_types' ) );
		if( class_exists('WooCommerce')  ) {
			\Indostio\WooCommerce::instance();
		}
		Admin::instance();
		// Init action.
		do_action( 'after_indostio_init' );

	}

		/**
	 * Hooks to loads
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function loads() {
		Options::instance();

		// Header
		Header::instance();

		// Page Header
		Page_Header::instance();

		// Footer
		Footer::instance();

		// Blog
		Blog::instance();

		// Dynamic CSS
		Dynamic_CSS::instance();

		// Comments
		Comments::instance();

	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function load_post_types() {
		if(is_singular('indostio_service')) {
			\Indostio\Services\Single_Service::instance();
		}

		if( 'indostio_service' == get_query_var('post_type') || is_tax('indostio_service_cat') || \Indostio\Helper::is_service_page() ) {
			if( ! is_search() ) {
				\Indostio\Services\Page_Header::instance();
			}
		}

		if(is_singular('indostio_team')) {
			\Indostio\Team\Single_Member::instance();
		}

		if( 'indostio_team' == get_query_var('post_type') || is_tax('indostio_team_cat') || \Indostio\Helper::is_service_page() ) {
			if( ! is_search() ) {
				\Indostio\Team\Page_Header::instance();
			}
		}

		if(is_singular('indostio_portfolio')) {
			\Indostio\Portfolio\Single_Portfolio::instance();
		}

		if( 'indostio_portfolio' == get_query_var('post_type') || is_tax('indostio_portfolio_cat') || \Indostio\Helper::is_portfolio_page() ) {
			if( ! is_search() ) {
				\Indostio\Portfolio\Page_Header::instance();
			}
		}

	}
	/**
	 * Setup theme
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function setup_theme() {
		/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on indostio, use a find and replace
	 * to change  'indostio' to the name of your theme in all the template files.
	 */
		load_theme_textdomain( 'indostio', get_template_directory() . '/lang' );

		// Theme supports
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );
		add_theme_support( 'customize-selective-refresh-widgets' );

		add_editor_style( 'assets/css/editor-style.css' );

		// Load regular editor styles into the new block-based editor.
		add_theme_support( 'editor-styles' );

		// Load default block styles.
		add_theme_support( 'wp-block-styles' );

		add_theme_support( 'post-formats', array( 'gallery', 'video' ) );

		// Add support for responsive embeds.
		add_theme_support( 'responsive-embeds' );

		add_theme_support( 'align-wide' );

		add_theme_support( 'align-full' );

		// Enable support for common post formats
		add_theme_support( 'post-formats', array( 'gallery', 'video' ) );

		add_image_size( 'indostio-post-thumbnail', 1170, 775, true );
		add_image_size( 'indostio-post-thumbnail-small', 115, 110, true );
		add_image_size( 'indostio-portfolio-thumbnail', 370, 270, true );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'primary-menu'    	=> esc_html__( 'Primary Menu', 'indostio' ),
		) );

	}

	/**
	 * Set the $content_width global variable used by WordPress to set image dimennsions.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function setup_content_width() {
		$GLOBALS['content_width'] = apply_filters( 'indostio_content_width', 640 );
	}

	/**
	 * Register widget area.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function widgets_init() {
		$sidebars = array(
			'blog-sidebar' => esc_html__( 'Blog Sidebar', 'indostio' ),
			'single-sidebar' => esc_html__( 'Single Sidebar', 'indostio' ),
			'service-sidebar' => esc_html__( 'Service Sidebar', 'indostio' ),
			'menu-sidebar' => esc_html__( 'Menu Sidebar', 'indostio' ),
		);

		// Register sidebars
		foreach ( $sidebars as $id => $name ) {
			register_sidebar(
				array(
					'name'          => $name,
					'id'            => $id,
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget'  => '</div>',
					'before_title'  => '<h2 class="widget-title">',
					'after_title'   => '</h2>',
				)
			);
		}

	}
}
