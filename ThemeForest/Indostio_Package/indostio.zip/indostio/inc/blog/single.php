<?php
/**
 * Single functions and definitions.
 *
 * @package Indostio
 */

namespace Indostio\Blog;
use Indostio\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Single initial
 */
class Single {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	protected static $instance = null;

	/**
	 * $post
	 *
	 * @var $post
	 */
	protected $post = null;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		$this->post     = new \Indostio\Blog\Post();
		$this->init();
	}

	/**
	 * Init
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function init() {
		// Body Class
		add_filter( 'body_class', array( $this, 'body_classes' ) );

		add_filter( 'indostio_site_layout', array( $this, 'content_layout' ));

		// Sidebar
		add_filter('indostio_get_sidebar', array( $this, 'sidebar' ));

		if (Helper::get_option('post_author_box') ) {
			add_action( 'indostio_after_post_content', array( $this, 'author_info' ), 20 );
		}

		if (Helper::get_option('post_navigation') ) {
			add_action( 'indostio_after_post_content', array( $this, 'navigation' ), 40 );
		}

	}

		/**
	 * Classes Body
	 * @since 1.0.0
	 *
	 * @param $classes
	 * @return $classes
	 */
	public function body_classes( $classes ) {
		$classes[] = $this->content_layout('');

		return $classes;
	}

	/**
	 * Get site layout
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public function content_layout($layout) {
		if ( ! is_active_sidebar( 'single-sidebar' ) ) {
			$layout = 'no-sidebar';
		} else {
			$layout = Helper::get_option( 'post_layout' );
		}

		return $layout;
	}

	/**
	 * Get Sidebar
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public function sidebar() {
		if ( ! is_active_sidebar( 'single-sidebar' ) ) {
			return false;
		} elseif( Helper::get_option( 'post_layout' ) == 'no-sidebar') {
			return false;
		}

		return true;

	}

		/**
	 * Meta author description
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function author_info() {
		get_template_part( 'template-parts/post/biography');
	}

	/**
	 * Meta post navigation
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */

	 public function navigation() {
		get_template_part( 'template-parts/post/post', 'navigation');
	}
}
