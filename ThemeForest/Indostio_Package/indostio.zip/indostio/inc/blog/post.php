<?php
/**
 * Indostio Blog Post functions and definitions.
 *
 * @package Indostio
 */

namespace Indostio\Blog;

use Indostio;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Indostio Post
 *
 */
class Post {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	protected static $instance = null;


	/**
	 * $fields
	 *
	 * @var $fields
	 */
	protected static $fields = [];

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
	}


	/**
	 * Get entry thumbmail
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function thumbnail() {
		if ( ! has_post_thumbnail() ) {
			return;
		}
		$size = 'indostio-post-thumbnail';
		$size = apply_filters('indostio_get_post_thumbnail_size', $size);

		$get_image = wp_get_attachment_image( get_post_thumbnail_id( get_the_ID() ), $size);

		if ( empty( $get_image ) ) {
			return;
		}

		echo sprintf(
			'<a class="post-thumbnail" href="%s" aria-hidden="true" tabindex="-1">%s%s</a>',
			esc_url( get_permalink() ),
			$get_image,
			self::get_format_icon()
		);
	}

	/**
	 * Get format
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function get_format_icon() {
		$icon = '';
		switch ( get_post_format() ) {
			case 'video':
				$icon = \Indostio\Icon::get_svg( 'video', 'post-format-icon icon-video' );
				break;

			case 'gallery':
				$icon = \Indostio\Icon::get_svg( 'gallery', 'post-format-icon icon-gallery' );
				break;
		}

		return $icon;
	}

	/**
	 * Get post image
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function image() {
		if ( ! has_post_thumbnail() ) {
			return;
		}
		$html = '';
		switch ( get_post_format() ) {
			case 'gallery':
				$images = get_post_meta( get_the_ID(), 'images' );

				if ( empty( $images ) ) {
					break;
				}

				$gallery = array();
				foreach ( $images as $image ) {
					$gallery[] = wp_get_attachment_image( $image, 'full', null, array( 'class' => 'swiper-slide' ) );
				}
				$html .= sprintf( '<div class="entry-thumbnail entry-gallery swiper-container"><div class="swiper-wrapper">%s</div><div class="swiper-pagination swiper-pagination--background swiper-pagination--light"></div>%s%s</div>',
							implode( '', $gallery ),
							\Indostio\Icon::get_svg( 'left', 'swiper-button swiper-button-prev' ),
							\Indostio\Icon::get_svg( 'right', 'swiper-button swiper-button-next' )
						);
				break;

			case 'video':
				$video = get_post_meta( get_the_ID(), 'video', true );
				if ( ! $video ) {
					break;
				}

				// If URL: show oEmbed HTML
				if ( filter_var( $video, FILTER_VALIDATE_URL ) ) {
					if ( $oembed = @wp_oembed_get( $video, array( 'width' => 1140 ) ) ) {
						$html .= '<div class="entry-thumbnail entry-video">' . $oembed . '</div>';
					} else {
						$atts = array(
							'src'   => $video,
							'width' => 1140,
						);

						if ( has_post_thumbnail() ) {
							$atts['poster'] = get_the_post_thumbnail_url( get_the_ID(), 'full' );
						}
						$html .= '<div class="entry-thumbnail entry-video">' . wp_video_shortcode( $atts ) . '</div>';
					}
				} // If embed code: just display
				else {
					$html .= '<div class="entry-thumbnail entry-video">' . $video . '</div>';
				}
				break;

			default:
				$html = '<div class="entry-thumbnail">' . get_the_post_thumbnail( get_the_ID(), 'full' ) . '</div>';

				break;
		}

		echo apply_filters( __FUNCTION__, $html, get_post_format() );
	}


	/**
	 * Get entry title
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function title($tag = 'h2') {
		the_title( '<'.$tag.' class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></'.$tag.'>' );
	}

	/**
	 * Get entry title
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function single_title($tag = 'h2') {
		the_title( '<'.$tag.' class="entry-title">', '</'.$tag.'>' );
	}

	/**
	 * Get category
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function category() {
		echo '<div class="entry-category">';
		the_category( ', ' );
		echo '</div>';
	}


	/**
	 * Meta author
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function author() {
		$author_id = get_post_field( 'post_author', get_the_ID() );
		$author_name = get_the_author_meta( 'display_name', $author_id );
		$byline = sprintf(
		/* translators: %s: post author. */
			esc_html_x( 'By %s', 'post author', 'indostio' ),
			'<a class="entry-author__url" href="' . esc_url( get_author_posts_url( $author_id ) ) . '">' . esc_html( $author_name ) . '</a>'
		);

		echo sprintf( '<div class="entry-meta entry-meta__author">%s%s</div>', \Indostio\Icon::get_svg('author'), $byline );
	}

	/**
	 * Meta date
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function date() {
		echo sprintf( '<div class="entry-meta entry-meta__date">%s%s</div>',\Indostio\Icon::get_svg('calendar'), esc_html( get_the_date() ) );
	}

	/**
	 * Meta comment
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function comment() {
		echo sprintf('<div class="entry-meta entry-meta__comments">%s%s (%s)</div>', \Indostio\Icon::get_svg( 'comment' ), esc_html__('Comments', 'indostio'), get_comments_number());
	}

	/**
	 * Get Excerpt
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function excerpt() {
		$length = \Indostio\Helper::get_option('blog_length');
		self::get_excerpt($length);
	}

	/**
	 * Get Excerpt
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function get_excerpt($length) {
		echo '<div class="entry-excerpt">';

		echo \Indostio\Helper::get_content_limit( $length, '' );

		echo '</div>';
	}

	/**
	 * Readmore button
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function button() {
		echo sprintf( '<div class="entry-read-more"><a class="indostio-button-secondary" href="%s">%s%s</a></div>', get_permalink(), esc_html__( 'Learn More', 'indostio' ), \Indostio\Icon::get_svg( 'arrow' ) );
	}

	/**
	 * Meta tag
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function tags() {
		if ( has_tag() == false ) {
			return;
		}
		if ( has_tag() ) :
			the_tags( '<div class="entry-tags"><span class="entry-tags__label">'. esc_html__('Tags', 'indostio') . '</span>', ' ', '</div>' );
		endif;
	}

	/**
	 * Get entry share social
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function share() {
		if( empty( \Indostio\Helper::get_option('post_sharing') ) ) {
			return;
		}
		echo '<div class="entry-meta__share">';
		echo sprintf( '<div class="entry-share__label">%s</div>', esc_html__('Share', 'indostio'));
		self::share_link();
		echo '</div>';
	}

	/**
	 * Share social
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function share_link() {
		if ( ! class_exists( '\Indostio\Addons\Helper' ) && ! method_exists( '\Indostio\Addons\Helper','share_link' )) {
			return;
		}
		$args = array();
		$args['whatsapp_number'] = \Indostio\Helper::get_option('post_sharing_whatsapp_number');
		$socials = (array) \Indostio\Helper::get_option( 'post_sharing_socials' );
		if ( ( ! empty( $socials ) ) ) {
			$output = array();

			foreach ( $socials as $social => $value ) {
				$output[] = \Indostio\Addons\Helper::share_link( $value, $args );
			}
			echo sprintf( '<div class="post__socials-share">%s</div>', implode( '', $output ) );
		};
	}

}
