<?php
/**
 * Archive functions and definitions.
 *
 * @package Indostio
 */

namespace Indostio\Blog;

use Indostio\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Archive initial
 *
 */
class Posts {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	protected static $instance = null;

	/**
	 * $Post
	 *
	 * @var $post
	 */
	protected $post = null;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		$this->post     		= new \Indostio\Blog\Post();
		$this->load_sections();
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function load_sections() {
		// Blog content layout
		add_filter('indostio_site_layout', array( $this, 'layout' ));

		// Sidebar
		add_filter('indostio_get_sidebar', array( $this, 'sidebar' ));

		// Body Class
		add_filter( 'body_class', array( $this, 'body_classes' ) );

		// Post Class
		add_filter( 'post_class', array( $this, 'post_classes' ), 10, 3 );
	}


	/**
	 * Layout
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function layout($layout) {
		if( is_active_sidebar('blog-sidebar') ){
			$layout = 'content-sidebar';
		} else {
			$layout = Helper::get_option( 'blog_layout' );
		}

		return $layout;
	}

	/**
	 * Get Sidebar
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public function sidebar() {
		if ( ! is_active_sidebar( 'blog-sidebar' ) ) {
			return false;
		} elseif( Helper::get_option( 'blog_layout' ) == 'no-sidebar') {
			return false;
		}

		return true;

	}

	/**
	 * Classes Body
	 * @since 1.0.0
	 *
	 * @param $classes
	 * @return $classes
	 */
	public function body_classes( $classes ) {
		$classes[] = $this->layout('');

		if( Helper::is_blog() ) {
			$classes[] = 'indostio-blog-page';
		}

		return $classes;
	}

	/**
	 * Add a class of blog layout to posts
	 *
	 * @param array $classes
	 * @param array $class
	 * @param int   $post_id
	 *
	 * @return mixed
	 */
	public function post_classes( $classes, $class, $post_id ) {
		if ( ! is_search() || 'post' == get_post_type( $post_id ) || ! is_main_query() || 'page' == get_post_type( $post_id ) ) {
			return $classes;
		}

		$classes[] = 'hentry';

		return $classes;
	}
}
