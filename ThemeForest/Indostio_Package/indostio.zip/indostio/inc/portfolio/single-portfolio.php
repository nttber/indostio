<?php
/**
 * Service functions and definitions.
 *
 * @package Indostio
 */

namespace Indostio\Portfolio;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Service initial
 *
 */
class Single_Portfolio {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	protected static $instance = null;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter('indostio_template_part_content_single', array($this, 'template_part_content_single'));
	}

	/**
	 * Template part content single
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function template_part_content_single() {
		return 'portfolio';
	}

}
