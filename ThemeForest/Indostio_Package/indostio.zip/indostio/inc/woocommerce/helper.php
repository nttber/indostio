<?php
/**
 * Indostio helper functions and definitions.
 *
 * @package Indostio
 */

namespace Indostio\WooCommerce;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Indostio Helper initial
 *
 */
class Helper {

}
