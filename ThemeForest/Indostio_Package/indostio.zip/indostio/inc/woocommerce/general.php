<?php
/**
 * Woocommerce Setup functions and definitions.
 *
 * @package Indostio
 */

namespace Indostio\WooCommerce;

use Indostio\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Woocommerce initial
 *
 */
class General {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	protected static $instance = null;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'scripts' ), 20 );
		add_action( 'widgets_init', array( $this, 'woocommerce_widgets_register' ) );

		add_filter('indostio_get_page_header_elements', array( $this, 'page_header_elements' ) );

		remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
		add_filter('woocommerce_show_page_title', '__return_false');

		add_filter('indostio_get_sidebar', array( $this, 'sidebar' ), 20 );

		add_filter( 'body_class', array( $this, 'body_classes' ) );

		add_action('woocommerce_before_quantity_input_field', array($this, 'quantity_icon_decrease'));
		add_action('woocommerce_after_quantity_input_field', array($this, 'quantity_icon_increase'));

		add_filter( 'woocommerce_upsells_total', array( $this, 'upsells_total' ) );

		add_filter( 'woocommerce_output_related_products_args', array(
			$this,
			'get_related_products_args'
		) );
	}

	/**
	 * WooCommerce specific scripts & stylesheets.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function scripts() {
		$style_file =  'woocommerce.css';
		wp_enqueue_style( 'indostio-woocommerce-style', apply_filters( 'indostio_get_style_directory_uri', get_template_directory_uri() ) . '/' . $style_file, array(),  '20220522' );

		$parse_css = apply_filters( 'indostio_wc_inline_style', false );
		if( $parse_css ) {
			wp_add_inline_style( 'indostio-woocommerce-style', $parse_css );
		}

		wp_enqueue_script( 'wc-cart-fragments' );
	}


	/**
	 * Register widget areas.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function woocommerce_widgets_register() {
		register_sidebar( array(
			'name'          => esc_html__( 'Catalog Sidebar', 'indostio' ),
			'id'            => 'catalog-sidebar',
			'description'   => esc_html__( 'Add sidebar for the catalog page', 'indostio' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>'
		) );

	}

	/**
	 * Page header elmenents
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public function sidebar($sidebar) {
		if( \Indostio\Helper::is_catalog() && is_active_sidebar( 'catalog-sidebar' ) ) {
			$sidebar = true;
		}

		return $sidebar;
	}

	/**
	 * Layout
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function layout($layout) {
		if( \Indostio\Helper::is_catalog() && is_active_sidebar( 'catalog-sidebar' ) ) {
			$layout = 'content-sidebar';
		}

		return $layout;
	}

	/**
	 * Classes Body
	 * @since 1.0.0
	 *
	 * @param $classes
	 * @return $classes
	 */
	public function body_classes( $classes ) {
		$classes[] = $this->layout('');

		if( \Indostio\Helper::is_catalog() ) {
			$classes[] = 'indostio-catalog-page';
		}

		return $classes;
	}


	/**
	 * Get Sidebar
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public function page_header_elements($item) {
		if( \Indostio\Helper::is_catalog() || is_singular('product') || is_cart() || is_checkout() ) {
			if( empty(Helper::get_option( 'disable_shop_page_header' )) ) {
				$item = (array) Helper::get_option( 'page_header_shop_els' );
			} else {
				$item = array();
			}
		}

		return $item;
	}


	/**
	 * Quantity Decrease Icon
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function quantity_icon_decrease() {
		echo \Indostio\Icon::get_svg( 'minus', 'indostio-qty-button decrease', 'ui' );
	}

		/**
	 * Quantity Increase Icon
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function quantity_icon_increase() {
		echo \Indostio\Icon::get_svg( 'plus', 'indostio-qty-button increase', 'ui' );
	}

		/**
	 * Change limit upsell
	 *
	 * @return void
	 */
	public function upsells_total( $limit ) {
		return 4;
	}

	/**
	 * Change Related products args
	 *
	 * @since 1.0.0
	 *
	 * @return array
	 */
	public function get_related_products_args( $args ) {
		$args = array(
			'posts_per_page' => 4,
			'columns'        => 4,
			'orderby'        => 'rand',
		);

		return $args;
	}


}