<?php
/**
 * WooCommerce Customizer functions and definitions.
 *
 * @package indostio
 */

namespace Indostio\WooCommerce;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * The indostio WooCommerce Customizer class
 */
class Customizer {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	protected static $instance = null;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter( 'indostio_customize_panels', array( $this, 'get_customize_panels' ) );
		add_filter( 'indostio_customize_sections', array( $this, 'get_customize_sections' ) );
		add_filter( 'indostio_customize_settings', array( $this, 'get_customize_settings' ) );
	}

	/**
	 * Adds theme options panels of WooCommerce.
	 *
	 * @since 1.0.0
	 *
	 * @param array $panels Theme options panels.
	 *
	 * @return array
	 */
	public function get_customize_panels( $panels ) {
		$panels['woocommerce'] = array(
			'priority' => 50,
			'title'    => esc_html__( 'Woocommerce', 'indostio' ),
		);

		return $panels;
	}

	/**
	 * Adds theme options sections of WooCommerce.
	 *
	 * @since 1.0.0
	 *
	 * @param array $sections Theme options sections.
	 *
	 * @return array
	 */
	public function get_customize_sections( $sections ) {
		// Page Header
		$sections['shop'] = array(
			'title'    => esc_html__( 'Shop', 'indostio' ),
			'capability'  => 'edit_theme_options',
		);

		return $sections;
	}

	/**
	 * Adds theme options of WooCommerce.
	 *
	 * @since 1.0.0
	 *
	 * @param array $fields Theme options fields.
	 *
	 * @return array
	 */
	public function get_customize_settings( $settings ) {
		// Page Header
		$settings['shop'] = array(
			'disable_shop_page_header'             => array(
				'type'        => 'toggle',
				'label'       => esc_html__('Disable Page Header', 'indostio'),
				'description' => esc_html__('Disable a page header for the shop page below the site header', 'indostio'),
				'default'     => false,
				'priority'    => 10,
			),
			'page_header_shop_image'           => array(
				'type'            => 'image',
				'label'           => esc_html__( 'Page Header Background', 'indostio' ),
				'default'         => '',
			),
			'page_header_shop_els' => array(
				'type'     => 'multicheck',
				'label'    => esc_html__('Page Header Elements', 'indostio'),
				'default'  => array('title', 'breadcrumb'),
				'priority' => 10,
				'choices'  => array(
					'breadcrumb' => esc_html__('BreadCrumb', 'indostio'),
					'title'      => esc_html__('Title', 'indostio'),
				),
				'description'     => esc_html__('Select which elements you want to show.', 'indostio'),

			),
			'page_header_shop_spacing_top' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Top', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header .page-header__inner',
						'property' => 'padding-top',
						'units'    => 'px',
					),
				),
			),
			'page_header_shop_spacing_bottom' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Bottom', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header .page-header__inner',
						'property' => 'padding-bottom',
						'units'    => 'px',
					),
				),
			),
			'catalog_nav_hr'  => array(
				'type'    => 'custom',
				'default' => '<hr>',
			),
			'catalog_sidebar' => array(
				'type'            => 'select',
				'label'           => esc_html__( 'Sidebar', 'indostio' ),
				'description'     => esc_html__( 'Go to appearance > widgets find to catalog sidebar to edit your sidebar', 'indostio' ),
				'default'         => 'sidebar-content',
				'choices'         => array(
					'content-sidebar' => esc_html__( 'Right Sidebar', 'indostio' ),
					'sidebar-content' => esc_html__( 'Left Sidebar', 'indostio' ),
					'no-sidebar'      => esc_html__( 'No Sidebar', 'indostio' ),
				),
			),
		);

		return $settings;
	}
}
