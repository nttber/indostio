<?php
/**
 * Style functions and definitions.
 *
 * @package Indostio
 */

namespace Indostio\WooCommerce;

use Indostio\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


class Dynamic_CSS {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	protected static $instance = null;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'indostio_wc_inline_style', array( $this, 'add_static_css' ) );
	}

	/**
	 * Get get style data
	 *
	 * @since  1.0.0
	 *
	 * @return string
	 */
	public function add_static_css( $parse_css ) {
		if( \Indostio\Helper::is_catalog() || is_singular('product') ) {
			if( ! empty(Helper::get_option( 'disable_shop_page_header' )) ) {
				return $parse_css;
			}

			$image = Helper::get_option('page_header_shop_image');
			if( !empty($image) ) {
				$parse_css .= '.page-header .page-header__image{background-image:url(' . esc_url($image) .')}';
			}

			$spacing_top = Helper::get_option('page_header_shop_spacing_top');
			if( $spacing_top != '176' ) {
				$parse_css .= '.page-header .page-header__inner{padding-top:' . $spacing_top .'px}';
			}

			$spacing_bottom = Helper::get_option('page_header_shop_spacing_bottom');
			if( $spacing_bottom != '176' ) {
				$parse_css .= '.page-header .page-header__inner{padding-bottom:' . $spacing_bottom .'px}';
			}
		}
		return $parse_css;
	}

}
