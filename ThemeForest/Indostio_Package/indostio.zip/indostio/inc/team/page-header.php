<?php
/**
 * Team Page Header functions and definitions.
 *
 * @package Indostio
 */

 namespace Indostio\Team;

 use Indostio\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Service initial
 *
 */
class Page_Header {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	protected static $instance = null;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter('indostio_get_page_header_elements', array( $this, 'page_header_elements' ) );
		add_filter('indostio_inline_style', array( $this, 'page_header_inline_style' ) );
	}

	/**
	 * Page header elmenents
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public function page_header_elements($item) {
		if( is_singular('indostio_team') ) {
			if( empty(Helper::get_option( 'disable_single_member_page_header' )) ) {
				$item = (array) Helper::get_option( 'page_header_single_member_els' );
			} else {
				$item = array();
			}
		} else {
			if( empty(Helper::get_option( 'disable_team_page_header' )) ) {
				$item = (array) Helper::get_option( 'page_header_team_els' );
			} else {
				$item = array();
			}
		}

		return $item;
	}

	/**
	 * Get Page Header style data
	 *
	 * @since  1.0.0
	 *
	 * @return string
	 */
	public function page_header_inline_style($color_style) {
		if( is_singular('indostio_team') ) {
			if( ! empty(Helper::get_option( 'disable_single_member_page_header' )) ) {
				return $color_style;
			} 

			$image = Helper::get_option('page_header_single_member_image');
			if( !empty($image) ) {
				$color_style .= '.page-header .page-header__image{background-image:url(' . esc_url($image) .')}';
			}

			$spacing_top = Helper::get_option('page_header_single_member_spacing_top');
			if( $spacing_top != '176' ) {
				$color_style .= '.page-header .page-header__inner{padding-top:' . $spacing_top .'px}';
			}

			$spacing_bottom = Helper::get_option('page_header_single_member_spacing_bottom');
			if( $spacing_bottom != '176' ) {
				$color_style .= '.page-header .page-header__inner{padding-bottom:' . $spacing_bottom .'px}';
			}
		} else {
			if( ! empty(Helper::get_option( 'disable_team_page_header' )) ) {
				return $color_style;
			}

			$image = Helper::get_option('page_header_team_image');
			if( !empty($image) ) {
				$color_style .= '.page-header .page-header__image{background-image:url(' . esc_url($image) .')}';
			}

			$spacing_top = Helper::get_option('page_header_team_spacing_top');
			if( $spacing_top != '176' ) {
				$color_style .= '.page-header .page-header__inner{padding-top:' . $spacing_top .'px}';
			}

			$spacing_bottom = Helper::get_option('page_header_team_spacing_bottom');
			if( $spacing_bottom != '176' ) {
				$color_style .= '.page-header .page-header__inner{padding-bottom:' . $spacing_bottom .'px}';
			}
		}
		

		return $color_style;

	}

}
