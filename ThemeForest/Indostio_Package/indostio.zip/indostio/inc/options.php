<?php

/**
 * Theme Options
 *
 * @package Indostio
 */

namespace Indostio;

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

class Options {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	protected static $instance = null;

	/**
	 * $indostio_customize
	 *
	 * @var $indostio_customize
	 */
	protected static $indostio_customize = null;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if (is_null(self::$instance)) {
			self::$instance = new self();
		}

		return self:: $instance;
	}

	/**
	 * The class constructor
	 *
	 * @since 1.0.0
	 *
	 */
	public function __construct() {
		add_filter('indostio_customize_config', array($this, 'customize_settings'));
		self::$indostio_customize = Customizer::instance();
	}

	/**
	 * This is a short hand function for getting setting value from customizer
	 *
	 * @since 1.0.0
	 *
	 * @param string $name
	 *
	 * @return bool|string
	 */
	public function get_option($name) {
		global $indostio_customize, $indostio_options;

		if ( isset( $indostio_options[ $name ] ) && ! is_customize_preview() ) {
			$value = $indostio_options[ $name ];
		} elseif ( is_object( $indostio_customize ) ) {
			$value = $indostio_customize->get_option( $name );
		} else {
			$value = get_theme_mod( $name );
			$value = false !== $value ? $value : $this->get_option_default( $name );
		}

		$indostio_options[ $name ] = $value;

		return apply_filters('indostio_get_option', $value, $name);
	}


	/**
	 * Get default option values
	 *
	 * @param string $name Option name.
	 *
	 * @return mixed
	 */
	function get_option_default( $name ) {
		global $indostio_customize;

		if ( is_object( $indostio_customize ) ) {
			return $indostio_customize->get_option_default( $name );
		}

		$config   = $this->customize_settings();
		$settings = array_reduce( $config['settings'], 'array_merge', array() );


		if ( ! isset( $settings[ $name ] ) ) {
			return false;
		}

		return isset( $settings[ $name ]['default'] ) ? $settings[ $name ]['default'] : false;
	}



	/**
	 * Get customize settings
	 *
	 * @since 1.0.0
	 *
	 * @return array
	 */
	public function customize_settings() {
		$panels = array(
			'general'    => array(
				'priority' => 10,
				'title'    => esc_html__( 'General', 'indostio' ),
			),
			'blog'       => array(
				'priority' => 30,
				'title'    => esc_html__( 'Blog', 'indostio' ),
			),
			'pages'       => array(
				'priority' => 40,
				'title'    => esc_html__( 'Pages', 'indostio' ),
			),
			'services'       => array(
				'priority' => 50,
				'title'    => esc_html__( 'Services', 'indostio' ),
			),
			'team'       => array(
				'priority' => 50,
				'title'    => esc_html__( 'Team', 'indostio' ),
			),
			'portfolio'       => array(
				'priority' => 50,
				'title'    => esc_html__( 'Portfolio', 'indostio' ),
			),
			'mobile' => array(
				'priority'   => 90,
				'title'      => esc_html__('Mobile', 'indostio'),
			),
		);

		$sections = array(
			'backtotop' => array(
				'title'    => esc_html__( 'Back To Top', 'indostio' ),
				'panel'    => 'general',
			),
			'styling' => array(
				'priority' => 10,
				'title'    => esc_html__('Styling', 'indostio'),
				'capability'  => 'edit_theme_options',
			),
			'header' => array(
				'priority' => 10,
				'title'    => esc_html__('Header', 'indostio'),
				'capability'  => 'edit_theme_options',
				'priority' => 10,
			),
			'footer'      => array(
				'title'    => esc_html__( 'Footer', 'indostio' ),
				'capability'  => 'edit_theme_options',
				'priority' => 20,
			),
			'blog'      => array(
				'title'    => esc_html__( 'Blog', 'indostio' ),
				'panel'    => 'blog',
			),
			'blog_header'      => array(
				'title'    => esc_html__( 'Blog Header', 'indostio' ),
				'panel'    => 'blog',
			),
			'single_post'       => array(
				'title'    => esc_html__( 'Single Post', 'indostio' ),
				'panel'    => 'blog',
			),
			'post_header'       => array(
				'title'    => esc_html__( 'Post Header', 'indostio' ),
				'panel'    => 'blog',
			),
			'page_header'      => array(
				'title'    => esc_html__( 'Page Header', 'indostio' ),
				'panel'    => 'pages',
			),
			'services'      => array(
				'title'    => esc_html__( 'Services', 'indostio' ),
				'panel'    => 'services',
			),
			'single_service'       => array(
				'title'    => esc_html__( 'Single Service', 'indostio' ),
				'panel'    => 'services',
			),
			'team'      => array(
				'title'    => esc_html__( 'Team', 'indostio' ),
				'panel'    => 'team',
			),
			'single_member'       => array(
				'title'    => esc_html__( 'Single Member', 'indostio' ),
				'panel'    => 'team',
			),
			'portfolio'      => array(
				'title'    => esc_html__( 'Portfolio', 'indostio' ),
				'panel'    => 'portfolio',
			),
			'single_portfolio'       => array(
				'title'    => esc_html__( 'Single Portfolio', 'indostio' ),
				'panel'    => 'portfolio',
			),
			'header_mobile'        => array(
				'title'    => esc_html__( 'Header', 'indostio' ),
				'panel'    => 'mobile',
			),

		);

		// Back To Top.
		$settings['backtotop'] = array(
			'backtotop'    => array(
				'type'        => 'toggle',
				'label'       => esc_html__( 'Back To Top', 'indostio' ),
				'description' => esc_html__( 'Check this to show back to top.', 'indostio' ),
				'default'     => true,
			),
		);

		$settings['styling'] = array(
			'primary_color_title'  => array(
				'type'  => 'custom',
				'label' => esc_html__( 'Primary Color', 'indostio' ),
			),
			'primary_color'        => array(
				'type'            => 'color-palette',
				'default'         => '#FF5E14',
				'choices'         => array(
					'colors' => array(
						'#FF5E14',
						'#CB0000',
						'#F7C600',
					),
					'style'  => 'round',
				),
				'active_callback' => array(
					array(
						'setting'  => 'primary_color_custom',
						'operator' => '!=',
						'value'    => true,
					),
				),
			),
			'primary_color_custom' => array(
				'type'      => 'checkbox',
				'label'     => esc_html__( 'Pick my favorite color', 'indostio' ),
				'default'   => false,

			),
			'primary_color_custom_color'  => array(
				'type'            => 'color',
				'label'           => esc_html__( 'Custom Color', 'indostio' ),
				'default'         => '#3449ca',
				'active_callback' => array(
					array(
						'setting'  => 'primary_color_custom',
						'operator' => '==',
						'value'    => true,
					),
				),
			),
			'primary_text_color'             => array(
				'type'        => 'select',
				'default'     => false,
				'label'       => esc_html__('Text on Primary Color', 'indostio'),
				'default'         => 'light',
				'choices'         => array(
					'light' 	=> esc_html__( 'Light', 'indostio' ),
					'dark' 	    => esc_html__( 'Dark', 'indostio' ),
					'custom'  	=> esc_html__( 'Custom', 'indostio' ),
				),
			),
			'primary_text_color_custom'  => array(
				'type'            => 'color',
				'label'           => esc_html__( 'Custom Color', 'indostio' ),
				'default'         => '#fff',
				'active_callback' => array(
					array(
						'setting'  => 'primary_text_color',
						'operator' => '==',
						'value'    => 'custom',
					),
				),
			),
		);
		// Header layout settings.
		$settings['header'] = array(
			'header_layout' => array(
				'type'            => 'select',
				'label'           => esc_html__( 'Header Layout', 'indostio' ),
				'choices'         => Helper::customizer_get_posts( array( 'post_type' => 'indostio_header' ) ),
			),
			'sticky_header_layout' => array(
				'type'            => 'select',
				'label'           => esc_html__( 'Sticky Header', 'indostio' ),
				'choices'         => Helper::customizer_get_posts( array( 'post_type' => 'indostio_header' ) ),
			),
		);

		// Footer layout settings.
		$settings['footer'] = array(
			'footer_layout' => array(
				'type'            => 'select',
				'label'           => esc_html__( 'Footer Layout', 'indostio' ),
				'description'     => esc_html__( 'Select a prebuilt footer present', 'indostio' ),
				'choices'         => Helper::customizer_get_posts( array( 'post_type' => 'indostio_footer' ) ),
			),
		);

		// Blog Archive
		$settings['blog'] = array(
			'blog_layout'                 => array(
				'type'        => 'select',
				'label'       => esc_html__( 'Blog Layout', 'indostio' ),
				'description' => esc_html__( 'The layout of blog page', 'indostio' ),
				'default'     => 'content-sidebar',
				'choices'     => array(
					'no-sidebar'      => esc_html__('No Sidebar', 'indostio'),
					'content-sidebar' => esc_html__('Right Sidebar', 'indostio'),
					'sidebar-content' => esc_html__('Left Sidebar', 'indostio'),
				),
			),
			'blog_length'              => array(
				'type'        => 'number',
				'label'       => esc_html__( 'Excerpt Length', 'indostio' ),
				'description' => esc_html__( 'The number of words of the post excerpt', 'indostio' ),
				'default'     => 30,
			),
		);

		// Blog Archive
		$settings['blog_header'] = array(
			'disable_blog_header'             => array(
				'type'        => 'toggle',
				'label'       => esc_html__('Disable Blog Header', 'indostio'),
				'description' => esc_html__('Disable a page header for the blog page below the site header', 'indostio'),
				'default'     => false,
				'priority'    => 10,
			),
			'blog_header_image'           => array(
				'type'            => 'image',
				'label'           => esc_html__( 'Blog Header Background', 'indostio' ),
				'default'         => '',
			),
			'blog_header_els' => array(
				'type'     => 'multicheck',
				'label'    => esc_html__('Blog Header Elements', 'indostio'),
				'default'  => array('title', 'breadcrumb'),
				'priority' => 10,
				'choices'  => array(
					'breadcrumb' => esc_html__('BreadCrumb', 'indostio'),
					'title'      => esc_html__('Title', 'indostio'),
				),
				'description'     => esc_html__('Select which elements you want to show.', 'indostio'),
				'active_callback' => array(
					array(
						'setting'  => 'blog_header',
						'operator' => '==',
						'value'    => true,
					),
				),

			),
			'blog_header_spacing_top' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Top', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header',
						'property' => 'padding-top',
						'units'    => 'px',
					),
				),
			),
			'blog_header_spacing_bottom' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Bottom', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header',
						'property' => 'padding-bottom',
						'units'    => 'px',
					),
				),
			),
		);

		// Blog single.
		$settings['post_header'] = array(
			'post_header_image'           => array(
				'type'            => 'image',
				'label'           => esc_html__( 'Post Header Background', 'indostio' ),
				'default'         => '',
			),
			'post_header_spacing_top' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Top', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.post-header',
						'property' => 'padding-top',
						'units'    => 'px',
					),
				),
			),
			'post_header_spacing_bottom' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Bottom', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.post-header',
						'property' => 'padding-bottom',
						'units'    => 'px',
					),
				),
			),
		);

		// Blog single.
		$settings['single_post'] = array(
			'post_layout'                 => array(
				'type'        => 'select',
				'label'       => esc_html__( 'Post Layout', 'indostio' ),
				'description' => esc_html__( 'The layout of single post', 'indostio' ),
				'default'     => 'no-sidebar',
				'choices'     => array(
					'no-sidebar'      => esc_html__('No Sidebar', 'indostio'),
					'content-sidebar' => esc_html__('Right Sidebar', 'indostio'),
					'sidebar-content' => esc_html__('Left Sidebar', 'indostio'),
				),
			),
			'post_author_box'      => array(
				'type'        => 'toggle',
				'label'       => esc_html__( 'Author Box', 'indostio' ),
				'description' => esc_html__( 'Display the post author box', 'indostio' ),
				'default'     => false,
			),
			'post_navigation'      => array(
				'type'        => 'toggle',
				'label'       => esc_html__( 'Post Navigation', 'indostio' ),
				'description' => esc_html__( 'Display the next and previous posts', 'indostio' ),
				'default'     => true,
			),
			'post_sharing'         => array(
				'type'        => 'toggle',
				'label'       => esc_html__( 'Post Sharing', 'indostio' ),
				'description' => esc_html__( 'Enable post sharing.', 'indostio' ),
				'default'     => false,
			),
			'post_sharing_socials' => array(
				'type'            => 'sortable',
				'description'     => esc_html__( 'Select social media for sharing posts', 'indostio' ),
				'default'         => array(
					'facebook',
					'twitter',
					'googleplus',
					'pinterest',
					'tumblr',
					'reddit',
					'telegram',
					'email',
				),
				'choices'         => array(
					'facebook'    => esc_html__( 'Facebook', 'indostio' ),
					'twitter'     => esc_html__( 'Twitter', 'indostio' ),
					'pinterest'   => esc_html__( 'Pinterest', 'indostio' ),
					'tumblr'      => esc_html__( 'Tumblr', 'indostio' ),
					'reddit'      => esc_html__( 'Reddit', 'indostio' ),
					'linkedin'    => esc_html__( 'Linkedin', 'indostio' ),
					'stumbleupon' => esc_html__( 'StumbleUpon', 'indostio' ),
					'digg'        => esc_html__( 'Digg', 'indostio' ),
					'telegram'    => esc_html__( 'Telegram', 'indostio' ),
					'whatsapp'    => esc_html__( 'WhatsApp', 'indostio' ),
					'vk'          => esc_html__( 'VK', 'indostio' ),
					'email'       => esc_html__( 'Email', 'indostio' ),
				),
				'active_callback' => array(
					array(
						'setting'  => 'post_sharing',
						'operator' => '==',
						'value'    => true,
					),
				),
			),
			'post_sharing_whatsapp_number' => array(
				'type'        => 'text',
				'description' => esc_html__( 'WhatsApp Phone Number', 'indostio' ),
				'active_callback' => array(
					array(
						'setting'  => 'post_sharing',
						'operator' => '==',
						'value'    => true,
					),
					array(
						'setting'  => 'post_sharing_socials',
						'operator' => 'contains',
						'value'    => 'whatsapp',
					),
				),
			),
		);

		// Blog Archive
		$settings['page_header'] = array(
			'disable_page_header'             => array(
				'type'        => 'toggle',
				'label'       => esc_html__('Disable Page Header', 'indostio'),
				'description' => esc_html__('Disable a page header for the page below the site header', 'indostio'),
				'default'     => false,
				'priority'    => 10,
			),
			'page_header_image'           => array(
				'type'            => 'image',
				'label'           => esc_html__( 'Page Header Background', 'indostio' ),
				'default'         => '',
			),
			'page_header_els' => array(
				'type'     => 'multicheck',
				'label'    => esc_html__('Page Header Elements', 'indostio'),
				'default'  => array('title', 'breadcrumb'),
				'priority' => 10,
				'choices'  => array(
					'breadcrumb' => esc_html__('BreadCrumb', 'indostio'),
					'title'      => esc_html__('Title', 'indostio'),
				),
				'description'     => esc_html__('Select which elements you want to show.', 'indostio'),
				'active_callback' => array(
					array(
						'setting'  => 'page_header',
						'operator' => '==',
						'value'    => true,
					),
				),

			),
			'page_header_spacing_top' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Top', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header',
						'property' => 'padding-top',
						'units'    => 'px',
					),
				),
			),
			'page_header_spacing_bottom' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Bottom', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header',
						'property' => 'padding-bottom',
						'units'    => 'px',
					),
				),
			),
		);

		// Services
		$settings['services'] = array(
			'disable_services_page_header'             => array(
				'type'        => 'toggle',
				'label'       => esc_html__('Disable Page Header', 'indostio'),
				'description' => esc_html__('Disable a page header for the services page below the site header', 'indostio'),
				'default'     => false,
				'priority'    => 10,
			),
			'page_header_services_image'           => array(
				'type'            => 'image',
				'label'           => esc_html__( 'Page Header Background', 'indostio' ),
				'default'         => '',
			),
			'page_header_services_els' => array(
				'type'     => 'multicheck',
				'label'    => esc_html__('Page Header Elements', 'indostio'),
				'default'  => array('title', 'breadcrumb'),
				'priority' => 10,
				'choices'  => array(
					'breadcrumb' => esc_html__('BreadCrumb', 'indostio'),
					'title'      => esc_html__('Title', 'indostio'),
				),
				'description'     => esc_html__('Select which elements you want to show.', 'indostio'),

			),
			'page_header_services_spacing_top' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Top', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header .page-header__inner',
						'property' => 'padding-top',
						'units'    => 'px',
					),
				),
			),
			'page_header_services_spacing_bottom' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Bottom', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header .page-header__inner',
						'property' => 'padding-bottom',
						'units'    => 'px',
					),
				),
			),
		);

		// Services
		$settings['single_service'] = array(
			'disable_single_service_page_header'             => array(
				'type'        => 'toggle',
				'label'       => esc_html__('Disable Page Header', 'indostio'),
				'description' => esc_html__('Disable a page header for the service page below the site header', 'indostio'),
				'default'     => false,
				'priority'    => 10,
			),
			'page_header_single_service_image'           => array(
				'type'            => 'image',
				'label'           => esc_html__( 'Page Header Background', 'indostio' ),
				'default'         => '',
			),
			'page_header_single_service_els' => array(
				'type'     => 'multicheck',
				'label'    => esc_html__('Page Header Elements', 'indostio'),
				'default'  => array('title', 'breadcrumb'),
				'priority' => 10,
				'choices'  => array(
					'breadcrumb' => esc_html__('BreadCrumb', 'indostio'),
					'title'      => esc_html__('Title', 'indostio'),
				),
				'description'     => esc_html__('Select which elements you want to show.', 'indostio'),

			),
			'page_header_single_service_spacing_top' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Top', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header .page-header__inner',
						'property' => 'padding-top',
						'units'    => 'px',
					),
				),
			),
			'page_header_single_service_spacing_bottom' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Bottom', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header .page-header__inner',
						'property' => 'padding-bottom',
						'units'    => 'px',
					),
				),
			),
		);

		// team
		$settings['team'] = array(
			'disable_team_page_header'             => array(
				'type'        => 'toggle',
				'label'       => esc_html__('Disable Page Header', 'indostio'),
				'description' => esc_html__('Disable a page header for the team page below the site header', 'indostio'),
				'default'     => false,
				'priority'    => 10,
			),
			'page_header_team_image'           => array(
				'type'            => 'image',
				'label'           => esc_html__( 'Page Header Background', 'indostio' ),
				'default'         => '',
			),
			'page_header_team_els' => array(
				'type'     => 'multicheck',
				'label'    => esc_html__('Page Header Elements', 'indostio'),
				'default'  => array('title', 'breadcrumb'),
				'priority' => 10,
				'choices'  => array(
					'breadcrumb' => esc_html__('BreadCrumb', 'indostio'),
					'title'      => esc_html__('Title', 'indostio'),
				),
				'description'     => esc_html__('Select which elements you want to show.', 'indostio'),

			),
			'page_header_team_spacing_top' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Top', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header .page-header__inner',
						'property' => 'padding-top',
						'units'    => 'px',
					),
				),
			),
			'page_header_team_spacing_bottom' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Bottom', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header .page-header__inner',
						'property' => 'padding-bottom',
						'units'    => 'px',
					),
				),
			),
		);

		// team
		$settings['single_member'] = array(
			'disable_single_member_page_header'             => array(
				'type'        => 'toggle',
				'label'       => esc_html__('Disable Page Header', 'indostio'),
				'description' => esc_html__('Disable a page header for the team page below the site header', 'indostio'),
				'default'     => false,
				'priority'    => 10,
			),
			'page_header_single_member_image'           => array(
				'type'            => 'image',
				'label'           => esc_html__( 'Page Header Background', 'indostio' ),
				'default'         => '',
			),
			'page_header_single_member_els' => array(
				'type'     => 'multicheck',
				'label'    => esc_html__('Page Header Elements', 'indostio'),
				'default'  => array('title', 'breadcrumb'),
				'priority' => 10,
				'choices'  => array(
					'breadcrumb' => esc_html__('BreadCrumb', 'indostio'),
					'title'      => esc_html__('Title', 'indostio'),
				),
				'description'     => esc_html__('Select which elements you want to show.', 'indostio'),

			),
			'page_header_single_member_spacing_top' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Top', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header .page-header__inner',
						'property' => 'padding-top',
						'units'    => 'px',
					),
				),
			),
			'page_header_single_member_spacing_bottom' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Bottom', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header .page-header__inner',
						'property' => 'padding-bottom',
						'units'    => 'px',
					),
				),
			),
		);

		// portfolio
		$settings['portfolio'] = array(
			'disable_portfolio_page_header'             => array(
				'type'        => 'toggle',
				'label'       => esc_html__('Disable Page Header', 'indostio'),
				'description' => esc_html__('Disable a page header for the portfolio page below the site header', 'indostio'),
				'default'     => false,
				'priority'    => 10,
			),
			'page_header_portfolio_image'           => array(
				'type'            => 'image',
				'label'           => esc_html__( 'Page Header Background', 'indostio' ),
				'default'         => '',
			),
			'page_header_portfolio_els' => array(
				'type'     => 'multicheck',
				'label'    => esc_html__('Page Header Elements', 'indostio'),
				'default'  => array('title', 'breadcrumb'),
				'priority' => 10,
				'choices'  => array(
					'breadcrumb' => esc_html__('BreadCrumb', 'indostio'),
					'title'      => esc_html__('Title', 'indostio'),
				),
				'description'     => esc_html__('Select which elements you want to show.', 'indostio'),

			),
			'page_header_portfolio_spacing_top' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Top', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header .page-header__inner',
						'property' => 'padding-top',
						'units'    => 'px',
					),
				),
			),
			'page_header_portfolio_spacing_bottom' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Bottom', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header .page-header__inner',
						'property' => 'padding-bottom',
						'units'    => 'px',
					),
				),
			),
		);

		// portfolio
		$settings['single_portfolio'] = array(
			'disable_single_portfolio_page_header'             => array(
				'type'        => 'toggle',
				'label'       => esc_html__('Disable Page Header', 'indostio'),
				'description' => esc_html__('Disable a page header for the portfolio page below the site header', 'indostio'),
				'default'     => false,
				'priority'    => 10,
			),
			'page_header_single_portfolio_image'           => array(
				'type'            => 'image',
				'label'           => esc_html__( 'Page Header Background', 'indostio' ),
				'default'         => '',
			),
			'page_header_single_portfolio_els' => array(
				'type'     => 'multicheck',
				'label'    => esc_html__('Page Header Elements', 'indostio'),
				'default'  => array('title', 'breadcrumb'),
				'priority' => 10,
				'choices'  => array(
					'breadcrumb' => esc_html__('BreadCrumb', 'indostio'),
					'title'      => esc_html__('Title', 'indostio'),
				),
				'description'     => esc_html__('Select which elements you want to show.', 'indostio'),

			),
			'page_header_single_portfolio_spacing_top' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Top', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header .page-header__inner',
						'property' => 'padding-top',
						'units'    => 'px',
					),
				),
			),
			'page_header_single_portfolio_spacing_bottom' => array(
				'type'      => 'slider',
				'label'     => esc_html__( 'Spacing Bottom', 'indostio' ),
				'transport' => 'postMessage',
				'default'   => '176',
				'choices'   => array(
					'min' => 0,
					'max' => 1000,
				),
				'js_vars'   => array(
					array(
						'element'  => '.page-header .page-header__inner',
						'property' => 'padding-bottom',
						'units'    => 'px',
					),
				),
			),
		);

		$settings['header_mobile'] = array(
			'header_mobile_breakpoint'              => array(
				'type'        => 'number',
				'label'       => esc_html__( 'Breakpoint (px)', 'indostio' ),
				'description' => esc_html__( 'Set a breakpoint where the mobile header displays and the desktop header is hidden.', 'indostio' ),
				'default'     => 1199,
				'choices'     => [
					'min'  => 991,
					'max'  => 1360,
					'step' => 1,
				],
			),
			'header_mobile_layout' => array(
				'type'            => 'select',
				'label'           => esc_html__( 'Header Layout', 'indostio' ),
				'description'     => esc_html__( 'Select a prebuilt header present', 'indostio' ),
				'choices'         => Helper::customizer_get_posts( array( 'post_type' => 'indostio_header' ) ),
			),
			'sticky_header_mobile_layout' => array(
				'type'            => 'select',
				'label'           => esc_html__( 'Sticky Header', 'indostio' ),
				'choices'         => Helper::customizer_get_posts( array( 'post_type' => 'indostio_header' ) ),
			),
		);

		return array(
			'theme'    => 'indostio',
			'panels'   => apply_filters( 'indostio_customize_panels', $panels ),
			'sections' => apply_filters( 'indostio_customize_sections', $sections ),
			'settings' => apply_filters( 'indostio_customize_settings', $settings ),
		);

	}

}
